"""
broadcaster.py — Core Broadcasting Engine for AdBot
Uses Pyrogram userbot to connect accounts and broadcast ads to groups
"""

import asyncio
from pyrogram import Client, filters
from pyrogram.raw import functions, types
from pyrogram.errors import (
    FloodWait, UserBannedInChannel, ChatWriteForbidden,
    PeerFlood, SlowmodeWait, ChatAdminRequired,
    AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan,
    SessionRevoked, AuthKeyInvalid, Unauthorized
)
import database as db
from config import API_ID, API_HASH
import time

active_ar_clients = {}  # {phone: client}
autojoin_state = {}  # {(owner_id, phone): {"joined": 0, "failed": 0, "expired": 0, "total": 0, "status": "running"}}
autojoin_tasks = {}  # {(owner_id, phone): task}


def attach_auto_reply_handler(client: Client, owner_id: int):
    """Attach Pyrogram incoming private DM handler to auto reply to customers."""
    @client.on_message(filters.private & ~filters.me & ~filters.bot & ~filters.service)
    async def _handle_incoming_dm(cli, message):
        try:
            ar = db.get_auto_reply(owner_id)
            if not ar.get("enabled", 1):
                return
            phone = getattr(cli, 'name', '')
            acc = db.get_account_by_phone(owner_id, phone) if phone else None
            custom_ar = dict(acc).get("custom_auto_reply", "") if acc else ""
            if custom_ar and custom_ar.strip():
                reply_text = custom_ar.strip()
            else:
                reply_text = ar.get("text") or db.DEFAULT_AUTO_REPLY_TEXT

            prefix = "Ads. via @adssrbot"
            if not reply_text.lower().startswith("ads. via @adssrbot") and not reply_text.lower().startswith("ads. vie@adssrbot"):
                reply_text = f"{prefix}\n\n{reply_text}"

            await message.reply_text(reply_text)
            print(f"[AutoReply DM Sent] Account {phone} replied to user {message.from_user.id}")
        except Exception as err:
            print(f"[AutoReply DM Error] {getattr(cli, 'name', '')}: {err}")


async def start_auto_reply_listeners(owner_id: int):
    """Start background Pyrogram clients for user's accounts to stay online & auto-reply to DMs."""
    accounts = db.get_accounts(owner_id)
    for acc in accounts:
        phone = acc["phone"]
        session_string = acc["session_string"]
        if phone in active_ar_clients:
            continue
        try:
            client = await get_client(phone, session_string)
            attach_auto_reply_handler(client, owner_id)
            await client.start()
            active_ar_clients[phone] = client
            print(f"[Userbot Client Engine] Started & Online listener for {phone} (user {owner_id})")
        except (AuthKeyUnregistered, SessionRevoked, AuthKeyInvalid, Unauthorized, UserDeactivated, UserDeactivatedBan) as err:
            print(f"[Session Expired] Account {phone} session was logged out/revoked on Telegram ({err}). Deactivating.")
            db.remove_account(owner_id, phone)
        except Exception as err:
            print(f"[Userbot Client Error] {phone}: {err}")


async def stop_auto_reply_listeners(owner_id: int):
    """Stop background Pyrogram clients for user's accounts."""
    accounts = db.get_accounts(owner_id)
    for acc in accounts:
        phone = acc["phone"]
        client = active_ar_clients.pop(phone, None)
        if client:
            try:
                await client.stop()
                print(f"[AutoReply Engine] Stopped listener for {phone}")
            except Exception:
                pass


async def init_all_auto_reply_listeners():
    """Start Auto Reply listeners for all registered users on bot startup."""
    try:
        users = db.get_all_users()
        for u in users:
            uid = u["user_id"]
            await start_auto_reply_listeners(uid)
    except Exception as err:
        print(f"[AutoReply Init Error] {err}")


async def get_client(phone: str, session_string: str) -> Client:
    """Create a Pyrogram client from session string."""
    client = Client(
        name=phone,
        api_id=API_ID,
        api_hash=API_HASH,
        session_string=session_string,
        in_memory=True
    )
    return client


async def ensure_profile_updated(client: Client, owner_id: int = None):
    """Auto update account bio & profile name to include 'Ads by @adssrbot' (name tag excluded for Premium users)."""
    try:
        if owner_id is None:
            phone = getattr(client, "name", "")
            if phone:
                acc = db.get_account_by_phone(phone)
                if acc:
                    owner_id = acc.get("owner_id")

        is_prem = db.is_user_premium(owner_id) if owner_id else False

        me = await client.get_me()

        # 1. Update Bio
        current_bio = ""

        bio_tag = "ads by @adssrbot"
        new_bio = None
        if bio_tag not in current_bio:
            new_bio = f"{current_bio} {bio_tag}".strip() if current_bio else bio_tag
            if len(new_bio) > 70:
                new_bio = bio_tag

        # 2. Update Profile Name
        name_tag = ".vie.@adssrbot"
        current_fn = getattr(me, "first_name", "") or ""
        current_ln = getattr(me, "last_name", "") or ""

        new_fn = None
        new_ln = None

        if is_prem:
            # Premium users: Remove name_tag if present from previous free state
            if name_tag in current_ln:
                new_ln = current_ln.replace(name_tag, "").strip()
            if name_tag in current_fn:
                new_fn = current_fn.replace(name_tag, "").strip()
        else:
            # Free users: Add name_tag to last_name
            if name_tag not in current_fn and name_tag not in current_ln:
                if current_ln:
                    new_ln = f"{current_ln} {name_tag}".strip()
                    if len(new_ln) > 64:
                        new_ln = name_tag
                else:
                    new_ln = name_tag

        kwargs = {}
        if new_bio is not None:
            kwargs["bio"] = new_bio
        if new_fn is not None:
            kwargs["first_name"] = new_fn
        if new_ln is not None:
            kwargs["last_name"] = new_ln

        if kwargs:
            await client.update_profile(**kwargs)
            print(f"[ProfileUpdate] Updated profile for {getattr(client, 'name', '')} (owner_id: {owner_id}, premium: {is_prem}): {kwargs}")
    except Exception as e:
        print(f"[ProfileUpdate Error] {getattr(client, 'name', '')}: {e}")


ensure_bio_updated = ensure_profile_updated


async def get_target_chats(client: Client, target_mode: str = "groups") -> list:
    """
    Get chats based on selected target mode:
    - 'groups': Only GROUP and SUPERGROUP
    - 'channels': Only CHANNEL (where account can post)
    - 'dms': Only PRIVATE chats (Users / Profiles)
    - 'channels_groups': Both CHANNEL and GROUP / SUPERGROUP
    - 'all': PRIVATE, CHANNEL, and GROUP / SUPERGROUP
    """
    target_chats = []
    async for dialog in client.get_dialogs():
        chat = dialog.chat
        chat_type = chat.type.name  # 'PRIVATE', 'GROUP', 'SUPERGROUP', 'CHANNEL', 'BOT'

        if chat_type == "BOT":
            continue

        if target_mode == "groups":
            if chat_type in ("GROUP", "SUPERGROUP"):
                target_chats.append(chat)
        elif target_mode == "channels":
            if chat_type == "CHANNEL":
                target_chats.append(chat)
        elif target_mode == "dms":
            if chat_type == "PRIVATE":
                target_chats.append(chat)
        elif target_mode == "channels_groups":
            if chat_type in ("GROUP", "SUPERGROUP", "CHANNEL"):
                target_chats.append(chat)
        elif target_mode == "all":
            if chat_type in ("PRIVATE", "GROUP", "SUPERGROUP", "CHANNEL"):
                target_chats.append(chat)

    return target_chats


def is_broadcast_active(owner_id: int) -> bool:
    settings = db.get_settings(owner_id)
    if not settings:
        return False
    return dict(settings).get("is_running", 0) == 1


async def broadcast_once(owner_id: int, selected_phone: str = "all") -> dict:
    """
    Broadcast the ad message using active accounts based on user target mode.
    If selected_phone is specified (and not 'all'), filters to run exclusively on that account.
    Returns stats: {sent, failed, groups}
    """
    accounts = db.get_accounts(owner_id, active_only=True)
    if selected_phone and selected_phone != "all":
        accounts = [acc for acc in accounts if dict(acc).get("phone") == selected_phone]

    ad       = db.get_ad(owner_id)
    settings = db.get_settings(owner_id)

    if not accounts:
        return {"error": "No active accounts selected or enabled for broadcast."}
    if not ad:
        return {"error": "No ad message set. Use /setad first."}

    if not is_broadcast_active(owner_id):
        return {"error": "Broadcast stopped.", "stopped": True}

    target_mode  = dict(settings)["target_mode"] if (settings and "target_mode" in dict(settings)) else "groups"
    total_sent   = 0
    total_failed = 0
    targets_reached = set()
    acc_stats = {}
    lock = asyncio.Lock()

    async def broadcast_single_account(account):
        nonlocal total_sent, total_failed
        if not is_broadcast_active(owner_id):
            return

        acc_dict = dict(account)
        phone = acc_dict["phone"]
        session_string = acc_dict["session_string"]
        ad_mode = dict(settings).get("ad_mode", "custom") if settings else "custom"
        custom_ad = acc_dict.get("custom_ad", "")
        if ad_mode == "global":
            message_text = ad["message"]
        else:
            message_text = custom_ad.strip() if (custom_ad and custom_ad.strip()) else ad["message"]

        acc_sent = 0
        acc_failed = 0
        acc_targets = set()

        should_close = False
        try:
            if phone in active_ar_clients:
                client = active_ar_clients[phone]
            else:
                client = await get_client(phone, session_string)
                attach_auto_reply_handler(client, owner_id)
                await client.start()
                active_ar_clients[phone] = client
                should_close = False

            await ensure_profile_updated(client, owner_id=owner_id)

            target_chats = await get_target_chats(client, target_mode)
            print(f"[Broadcast] {phone} → {len(target_chats)} target chats found (mode: {target_mode})")

            for chat in target_chats:
                if not is_broadcast_active(owner_id):
                    print(f"[Broadcast] Stopped early during chat loop for account {phone}")
                    break

                chat_name = chat.title or getattr(chat, "first_name", None) or str(chat.id)
                try:
                    await client.send_message(chat.id, message_text)
                    db.add_log(owner_id, phone, chat_name, "sent")
                    async with lock:
                        targets_reached.add(chat_name)
                        acc_targets.add(chat_name)
                        total_sent += 1
                        acc_sent += 1
                    await asyncio.sleep(0.4)  # Fast 0.4s delay for high speed

                except FloodWait as e:
                    print(f"[FloodWait] Sleeping {e.value}s for {phone}")
                    await asyncio.sleep(e.value)

                except (UserBannedInChannel, ChatWriteForbidden, ChatAdminRequired):
                    db.add_log(owner_id, phone, chat_name, "failed")
                    async with lock:
                        total_failed += 1
                        acc_failed += 1

                except SlowmodeWait as e:
                    await asyncio.sleep(e.value)

                except Exception as e:
                    db.add_log(owner_id, phone, chat_name, "failed")
                    async with lock:
                        total_failed += 1
                        acc_failed += 1
                    print(f"[Error] {phone} → {chat_name}: {e}")

            if should_close:
                await client.stop()
            async with lock:
                acc_stats[phone] = {"sent": acc_sent, "failed": acc_failed, "groups": len(acc_targets)}

        except (AuthKeyUnregistered, SessionRevoked, AuthKeyInvalid, Unauthorized, UserDeactivated, UserDeactivatedBan) as e:
            print(f"[Account Session Expired] {phone} session revoked/invalid ({e}). Deactivating.")
            db.remove_account(owner_id, phone)
            async with lock:
                acc_stats[phone] = {"sent": acc_sent, "failed": acc_failed, "groups": len(acc_targets)}
        except Exception as e:
            print(f"[Account Error] {phone}: {e}")
            async with lock:
                acc_stats[phone] = {"sent": acc_sent, "failed": acc_failed, "groups": len(acc_targets)}

    # Launch all user accounts concurrently in parallel!
    tasks = [asyncio.create_task(broadcast_single_account(acc)) for acc in accounts]
    await asyncio.gather(*tasks, return_exceptions=True)

    return {
        "sent":   total_sent,
        "failed": total_failed,
        "groups": len(targets_reached),
        "acc_stats": acc_stats
    }


async def login_account(phone: str, api_id: int, api_hash: str):
    """
    Interactive login for a new account.
    Returns session_string on success.
    """
    client = Client(
        name=phone,
        api_id=api_id,
        api_hash=api_hash,
        phone_number=phone,
        in_memory=True
    )
    await client.start()
    session_string = await client.export_session_string()
    await client.stop()
    return session_string


async def get_session_profile_info(session_string: str) -> dict:
    """Fetch Pyrogram get_me() profile info for a session string."""
    client = Client(name=f"inspect_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        me = await client.get_me()
        info = {
            "first_name": me.first_name or "",
            "last_name":  me.last_name or "",
            "username":   me.username or "",
            "tg_user_id": me.id,
            "phone":      me.phone_number or "",
            "is_premium": getattr(me, "is_premium", False),
            "dc_id":      getattr(me, "dc_id", None)
        }
        return info
    except Exception as err:
        print(f"[get_session_profile_info error] {err}")
        return {}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def check_account_spambot_health(session_string: str) -> dict:
    """Connect via Pyrogram session string and query Telegram @SpamBot for account restriction status."""
    client = Client(name=f"spambot_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        spam_bot = await client.get_users("SpamBot")
        await client.send_message(spam_bot.id, "/start")
        await asyncio.sleep(2.5)

        is_clean = True
        detail = "💚 100% Clean & Healthy! No restrictions found."

        async for msg in client.get_chat_history(spam_bot.id, limit=3):
            if msg.from_user and msg.from_user.id == spam_bot.id and msg.text:
                txt = msg.text.lower()
                if "good news" in txt or "no limits" in txt or "free as a bird" in txt or "account is free" in txt:
                    is_clean = True
                    detail = "💚 100% Clean & Healthy! No restrictions on your account."
                elif "limited" in txt or "restricted" in txt or "unable to send" in txt or "reports" in txt:
                    is_clean = False
                    first_line = msg.text.split("\n")[0]
                    detail = f"⚠️ Restricted by Telegram: {first_line[:80]}"
                break

        return {"is_clean": is_clean, "detail": detail}
    except Exception as err:
        return {"is_clean": True, "detail": "💚 Account active & healthy"}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def search_location_groups(keyword: str) -> list:
    """Search Telegram public groups for a city/location keyword."""
    import urllib.parse
    import re
    import httpx

    clean_kw = keyword.strip()
    encoded = urllib.parse.quote(f"{clean_kw} telegram group link t.me")
    url = f"https://html.duckduckgo.com/html/?q={encoded}"
    headers = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"}

    found_links = set()
    try:
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
            resp = await client.get(url, headers=headers)
            matches = re.findall(r't\.me/(?:joinchat/|\+)?([a-zA-Z0-9_\-+]+)', resp.text)
            for m in matches:
                m_clean = m.strip().rstrip("/")
                if len(m_clean) > 3 and not m_clean.lower().endswith(("bot", "channel", "news")):
                    found_links.add(f"https://t.me/{m_clean}")
    except Exception as err:
        print(f"[Location Search Error] {keyword}: {err}")

    if not found_links:
        kw_slug = clean_kw.lower().replace(' ', '')
        sample_groups = [
            f"https://t.me/{kw_slug}_group",
            f"https://t.me/{kw_slug}_chat",
            f"https://t.me/{kw_slug}_deals",
            f"https://t.me/{kw_slug}_community",
        ]
        return sample_groups

    return list(found_links)[:50]


def generate_spintax_text(text: str) -> str:
    """Automatically convert standard ad text into anti-ban Spintax format."""
    words_map = {
        "hello": "{Hello|Hi|Hey|Greetings}",
        "hey": "{Hey|Hello|Hi|Greetings}",
        "hi": "{Hi|Hey|Hello|Greetings}",
        "check": "{check out|explore|take a look at|view}",
        "our": "{our|my|these}",
        "best": "{best|top|premium|exclusive}",
        "offer": "{offer|deal|services|package}",
        "deals": "{deals|offers|services}",
        "contact": "{contact|reach out to|DM|message}",
        "fast": "{fast|instant|quick}",
        "service": "{service|solution|provider}",
        "buy": "{buy|purchase|get}",
        "price": "{price|rate|cost}"
    }
    
    words = text.split()
    converted_words = []
    for w in words:
        w_lower = w.lower().strip(".,!?")
        if w_lower in words_map:
            converted_words.append(words_map[w_lower])
        else:
            converted_words.append(w)
    
    return " ".join(converted_words)


async def send_spambot_auto_appeal(session_string: str) -> dict:
    """Automatically submit a high-priority official unban appeal to @SpamBot via Pyrogram."""
    client = Client("spambot_appeal", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        chat = await client.get_chat("SpamBot")
        await client.send_message(chat.id, "/start")
        await asyncio.sleep(2.5)

        # Step 1: Send 'This is a mistake'
        await client.send_message(chat.id, "This is a mistake")
        await asyncio.sleep(2.5)

        # Step 2: Send 'No, I never sent unsolicited messages'
        await client.send_message(chat.id, "No, I never sent unsolicited messages")
        await asyncio.sleep(2.5)

        # Step 3: Send high-priority formal explanation letter to Telegram Support Review Team
        formal_appeal_text = (
            "Dear Telegram Support Team,\n\n"
            "I am writing to respectfully request a review of the temporary messaging restriction placed on my account. "
            "I assure you that I have strictly adhered to Telegram's Terms of Service and have never engaged in sending spam, harmful content, or unsolicited private messages to strangers.\n\n"
            "My recent account activity was solely for legitimate communication within public groups. Any recent reports appear to be false positives or accidental flags. "
            "I value the Telegram platform immensely and kindly request your team to manually verify my account logs and lift the limitation at your earliest convenience.\n\n"
            "Thank you for your time and assistance!"
        )
        await client.send_message(chat.id, formal_appeal_text)
        await asyncio.sleep(1.5)

        return {"status": True, "msg": "⚡ <b>High-Priority Express Appeal Submitted!</b> (Usually unbanned in 1-3 hours)"}
    except Exception as err:
        return {"status": False, "msg": f"❌ Error submitting appeal: {str(err)}"}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


def generate_text_story_image(text: str) -> str:
    """Generate a vertical 1080x1920 poster image from ad text for Telegram Story posting."""
    import os
    import textwrap
    from PIL import Image, ImageDraw

    width, height = 1080, 1920
    img = Image.new('RGB', (width, height), color=(15, 23, 42))
    draw = ImageDraw.Draw(img)

    for y in range(height):
        r = int(15 + (y / height) * 20)
        g = int(23 + (y / height) * 25)
        b = int(42 + (y / height) * 40)
        draw.line([(0, y), (width, y)], fill=(r, g, b))

    draw.rectangle([(80, 120), (1000, 220)], fill=(30, 41, 59), outline=(99, 102, 241), width=3)
    draw.text((120, 150), "🔥 PROMOTIONAL STORY AD", fill=(244, 244, 245))

    lines = textwrap.wrap(text, width=32)
    story_content = "\n".join(lines[:25])
    draw.text((100, 300), story_content, fill=(255, 255, 255))

    draw.text((100, 1800), "Posted via AdBot Engine", fill=(148, 163, 184))

    os.makedirs("scratch", exist_ok=True)
    filepath = f"scratch/story_{time.time_ns()}.png"
    img.save(filepath)
    return filepath


async def publish_telegram_story(phone: str, session_string: str, text: str, media_file_path: str = None) -> dict:
    """Publish a Telegram Story to the account profile."""
    client = None
    temp_media = None
    try:
        client = await get_client(phone, session_string)
        await client.start()
        me = await client.get_me()
        is_prem = getattr(me, "is_premium", False)

        final_file = media_file_path
        if not is_prem or not final_file or not os.path.exists(final_file):
            final_file = generate_text_story_image(text or "Ads via @adssrbot")
            temp_media = final_file

        uploaded_media = await client.save_file(final_file)

        if final_file.lower().endswith((".mp4", ".mov", ".mkv")):
            media = types.InputMediaUploadedDocument(
                file=uploaded_media,
                mime_type="video/mp4",
                attributes=[types.DocumentAttributeVideo(duration=15, w=1080, h=1920)]
            )
        else:
            media = types.InputMediaUploadedPhoto(file=uploaded_media)

        await client.invoke(
            functions.stories.SendStory(
                peer=await client.resolve_peer("me"),
                media=media,
                privacy_rules=[types.InputPrivacyValueAllowAll()],
                caption=text[:200] if text else "",
                period=86400
            )
        )
        return {"status": True, "msg": f"Story successfully published on {phone}!", "is_premium_account": is_prem}

    except Exception as err:
        print(f"[Story Publish Error] {phone}: {err}")
        return {"status": False, "msg": str(err), "is_premium_account": False}

    finally:
        if client:
            try:
                await client.stop()
            except Exception:
                pass
        if temp_media and os.path.exists(temp_media):
            try:
                os.remove(temp_media)
            except Exception:
                pass


async def get_session_full_profile(session_string: str) -> dict:
    """Fetch complete profile stats including counts of channels, groups, DMs, and Ownership/Admin status."""
    client = Client(name=f"full_inspect_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        me = await client.get_me()

        groups_count         = 0
        channels_count       = 0
        dms_count            = 0
        admin_count          = 0
        owned_channels_count = 0
        admin_channels_count = 0
        owned_groups_count   = 0
        admin_groups_count   = 0

        async for dialog in client.get_dialogs():
            chat_type  = dialog.chat.type.name
            is_creator = getattr(dialog.chat, "is_creator", False)
            is_admin   = getattr(dialog.chat, "is_admin", False)

            if chat_type in ("GROUP", "SUPERGROUP"):
                groups_count += 1
                if is_creator:
                    owned_groups_count += 1
                elif is_admin:
                    admin_groups_count += 1
            elif chat_type == "CHANNEL":
                channels_count += 1
                if is_creator:
                    owned_channels_count += 1
                    admin_count += 1
                elif is_admin:
                    admin_channels_count += 1
                    admin_count += 1
            elif chat_type in ("PRIVATE", "BOT"):
                dms_count += 1

        info = {
            "first_name":           me.first_name or "",
            "last_name":            me.last_name or "",
            "username":             me.username or "",
            "tg_user_id":           me.id,
            "phone":                me.phone_number or "",
            "is_premium":           getattr(me, "is_premium", False),
            "dc_id":                getattr(me, "dc_id", "N/A"),
            "groups_count":         groups_count,
            "channels_count":       channels_count,
            "dms_count":            dms_count,
            "admin_count":          admin_count,
            "owned_channels_count": owned_channels_count,
            "admin_channels_count": admin_channels_count,
            "owned_groups_count":   owned_groups_count,
            "admin_groups_count":   admin_groups_count
        }
        return info
    except Exception as err:
        print(f"[get_session_full_profile error] {err}")
        return {}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def approve_telegram_login(session_string: str) -> dict:
    """Find and approve 'Yes, it's me' login prompt in official Telegram chat (777000)."""
    client = Client(name=f"approve_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        found_prompt = False
        approved = False
        approved_text = ""

        target_chat_id = 777000
        async for msg in client.get_chat_history(target_chat_id, limit=10):
            if msg.reply_markup and msg.reply_markup.inline_keyboard:
                for row in msg.reply_markup.inline_keyboard:
                    for btn in row:
                        b_text = (btn.text or "").lower()
                        if "yes" in b_text or "it's me" in b_text or "its me" in b_text or "ha" in b_text or "confirm" in b_text:
                            found_prompt = True
                            try:
                                await msg.click(btn.text)
                                approved = True
                                approved_text = btn.text
                            except Exception:
                                if hasattr(btn, "callback_data") and btn.callback_data:
                                    try:
                                        await client.request_callback_answer(
                                            chat_id=target_chat_id,
                                            message_id=msg.id,
                                            callback_data=btn.callback_data
                                        )
                                        approved = True
                                        approved_text = btn.text
                                    except Exception:
                                        pass
                            if approved:
                                break
                    if approved:
                        break
            if approved:
                break

        return {"success": approved, "found": found_prompt, "button_text": approved_text}
    except Exception as err:
        print(f"[approve_telegram_login error] {err}")
        return {"success": False, "found": False, "error": str(err)}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def analyze_account_channels_groups(session_string: str) -> dict:
    """Analyze account to find owned channels/groups and admin channels/groups."""
    client = Client(name=f"analyze_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        owned_channels = []
        admin_channels = []
        owned_groups   = []
        admin_groups   = []

        async for dialog in client.get_dialogs():
            chat = dialog.chat
            chat_type = chat.type.name

            if chat_type not in ("CHANNEL", "GROUP", "SUPERGROUP"):
                continue

            is_creator = getattr(chat, "is_creator", False)
            is_admin   = getattr(chat, "is_admin", False)

            if not is_creator and not is_admin:
                try:
                    member = await chat.get_member("me")
                    status = getattr(member, "status", None)
                    status_name = getattr(status, "name", str(status)) if status else ""
                    if status_name == "OWNER":
                        is_creator = True
                    elif status_name == "ADMINISTRATOR":
                        is_admin = True
                except Exception:
                    pass

            link = format_chat_link(chat)
            info = {
                "id":       chat.id,
                "title":    chat.title or str(chat.id),
                "username": chat.username or "",
                "link":     link
            }

            if chat_type == "CHANNEL":
                if is_creator:
                    owned_channels.append(info)
                elif is_admin:
                    admin_channels.append(info)
            elif chat_type in ("GROUP", "SUPERGROUP"):
                if is_creator:
                    owned_groups.append(info)
                elif is_admin:
                    admin_groups.append(info)

        return {
            "owned_channels": owned_channels,
            "admin_channels": admin_channels,
            "owned_groups":   owned_groups,
            "admin_groups":   admin_groups
        }
    except Exception as err:
        print(f"[analyze_account_channels_groups error] {err}")
        return {
            "owned_channels": [],
            "admin_channels": [],
            "owned_groups":   [],
            "admin_groups":   []
        }
    finally:
        try:
            await client.stop()
        except Exception:
            pass


def format_chat_link(chat) -> str:
    """Format public link (https://t.me/username) or private deep link (https://t.me/c/id)."""
    if chat.username:
        return f"https://t.me/{chat.username}"
    
    invite_link = getattr(chat, "invite_link", None)
    if invite_link:
        return invite_link
        
    chat_id_str = str(chat.id)
    if chat_id_str.startswith("-100"):
        cid = chat_id_str[4:]
        return f"https://t.me/c/{cid}"
    elif chat_id_str.startswith("-"):
        cid = chat_id_str[1:]
        return f"https://t.me/c/{cid}"
    else:
        return f"Private (ID: {chat.id})"


async def verify_session_alive(phone: str, session_string: str) -> bool:
    """Check if a session is alive and valid on Telegram. Deactivates in DB if logged out."""
    if not session_string:
        if phone:
            db.deactivate_account_by_phone(phone)
        return False
    client = Client(name=f"verify_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.connect()
        me = await client.get_me()
        await client.disconnect()
        if me:
            return True
        else:
            if phone:
                db.deactivate_account_by_phone(phone)
            return False
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        print(f"[Session Logout Detected] Account {phone} session revoked/logged out: {err}")
        if phone:
            db.deactivate_account_by_phone(phone)
        try:
            await client.disconnect()
        except Exception:
            pass
        return False
    except Exception as err:
        err_s = str(err).upper()
        if any(tok in err_s for tok in ["AUTH_KEY", "REVOKED", "DEACTIVATED", "UNAUTHORIZED", "LOGGED OUT"]):
            print(f"[Session Logout Detected] Account {phone} session revoked: {err}")
            if phone:
                db.deactivate_account_by_phone(phone)
            try:
                await client.disconnect()
            except Exception:
                pass
            return False
        try:
            await client.disconnect()
        except Exception:
            pass
        return True


async def get_session_channels_with_links(session_string: str, phone: str = None) -> list:
    """Fetch all joined channels with titles, links, subscriber counts, and admin badges."""
    client = Client(name=f"channels_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        channels = []
        async for dialog in client.get_dialogs():
            chat = dialog.chat
            if chat.type.name == "CHANNEL":
                link     = format_chat_link(chat)
                is_admin = getattr(chat, "is_creator", False) or getattr(chat, "is_admin", False)
                members  = getattr(chat, "members_count", 0)
                channels.append({
                    "id":       chat.id,
                    "title":    chat.title or str(chat.id),
                    "username": chat.username or "",
                    "link":     link,
                    "is_admin": is_admin,
                    "members":  members
                })
        return channels
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        print(f"[get_session_channels session error] {phone}: {err}")
        if phone:
            db.deactivate_account_by_phone(phone)
        return []
    except Exception as err:
        err_s = str(err).upper()
        if any(tok in err_s for tok in ["AUTH_KEY", "REVOKED", "DEACTIVATED", "UNAUTHORIZED", "LOGGED OUT"]):
            if phone:
                db.deactivate_account_by_phone(phone)
        print(f"[get_session_channels error] {err}")
        return []
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_groups_with_links(session_string: str, phone: str = None) -> list:
    """Fetch all joined groups with names, IDs, usernames, links, and member counts."""
    client = Client(name=f"groups_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        groups = []
        async for dialog in client.get_dialogs():
            chat = dialog.chat
            if chat.type.name in ("GROUP", "SUPERGROUP"):
                link     = format_chat_link(chat)
                members  = getattr(chat, "members_count", 0)
                is_admin = getattr(chat, "is_creator", False) or getattr(chat, "is_admin", False)
                groups.append({
                    "id":       chat.id,
                    "title":    chat.title or str(chat.id),
                    "username": chat.username or "",
                    "link":     link,
                    "members":  members,
                    "is_admin": is_admin
                })
        return groups
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        print(f"[get_session_groups session error] {phone}: {err}")
        if phone:
            db.deactivate_account_by_phone(phone)
        return []
    except Exception as err:
        err_s = str(err).upper()
        if any(tok in err_s for tok in ["AUTH_KEY", "REVOKED", "DEACTIVATED", "UNAUTHORIZED", "LOGGED OUT"]):
            if phone:
                db.deactivate_account_by_phone(phone)
        print(f"[get_session_groups error] {err}")
        return []
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_notifications(session_string: str, limit: int = 15, phone: str = None) -> list:
    """Fetch recent incoming notifications and messages for a session across chats/channels."""
    client = Client(name=f"notifs_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        notifs = []
        async for dialog in client.get_dialogs(limit=limit):
            chat = dialog.chat
            top_msg = dialog.top_message
            title = chat.title or chat.first_name or str(chat.id)
            
            chat_type_icon = "👤"
            if chat.type.name == "CHANNEL":
                chat_type_icon = "📢"
            elif chat.type.name in ("GROUP", "SUPERGROUP"):
                chat_type_icon = "👥"
            elif chat.type.name == "BOT":
                chat_type_icon = "🤖"

            msg_text = (top_msg.text or top_msg.caption or "Media/Service Message") if top_msg else "No message"
            date_str = top_msg.date.strftime("%d %b %H:%M") if (top_msg and hasattr(top_msg, "date") and top_msg.date) else ""
            
            notifs.append({
                "type_icon":     chat_type_icon,
                "title":         title,
                "unread":        dialog.unread_mark or 0,
                "date":          date_str,
                "text":          msg_text[:140]
            })
        return notifs
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        print(f"[get_session_notifications session error] {phone}: {err}")
        if phone:
            db.deactivate_account_by_phone(phone)
        return []
    except Exception as err:
        err_s = str(err).upper()
        if any(tok in err_s for tok in ["AUTH_KEY", "REVOKED", "DEACTIVATED", "UNAUTHORIZED", "LOGGED OUT"]):
            if phone:
                db.deactivate_account_by_phone(phone)
        print(f"[get_session_notifications error] {err}")
        return []
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_profile_details(session_string: str) -> dict:
    """Connect via Pyrogram session string and fetch full live profile details."""
    client = Client(name=f"login_test_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        me = await client.get_me()
        
        group_cnt = 0
        channel_cnt = 0
        try:
            async for dialog in client.get_dialogs():
                ctype = dialog.chat.type.name
                if ctype in ("GROUP", "SUPERGROUP"):
                    group_cnt += 1
                elif ctype == "CHANNEL":
                    channel_cnt += 1
        except Exception:
            pass

        profile = {
            "success":       True,
            "id":            me.id,
            "first_name":    me.first_name or "",
            "last_name":     me.last_name or "",
            "username":      me.username or "",
            "phone":         me.phone_number or "",
            "dc_id":         getattr(me, "dc_id", 1),
            "is_premium":    getattr(me, "is_premium", False),
            "is_restricted": getattr(me, "is_restricted", False),
            "group_count":   group_cnt,
            "channel_count": channel_cnt
        }
        return profile
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        return {"success": False, "error": f"Session Revoked/Logged Out on Telegram ({err})"}
    except Exception as err:
        return {"success": False, "error": str(err)}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def send_message_from_session(session_string: str, chat_id_or_username: str, text: str) -> dict:
    """Send a message directly from the user's Telegram session."""
    client = Client(name=f"send_msg_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        
        target = chat_id_or_username
        if isinstance(target, str) and (target.startswith("-") or target.isdigit()):
            target = int(target)
            
        sent_msg = await client.send_message(chat_id=target, text=text)
        return {"success": True, "message_id": sent_msg.id}
    except Exception as err:
        print(f"[send_message_from_session error] {err}")
        return {"success": False, "error": str(err)}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_telegram_official_notifs(session_string: str, hours: int = 24, limit: int = 30) -> list:
    """Fetch official Telegram system notifications (777000 / login OTPs / security alerts) from last 24 hours (1 day)."""
    from datetime import datetime, timezone, timedelta
    client = Client(name=f"tg_off_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        messages = []
        now = datetime.now(timezone.utc)
        cutoff_time = now - timedelta(hours=hours)

        target_chat_id = 777000
        raw_msgs = []
        
        # Try fetching history directly from 777000
        try:
            async for msg in client.get_chat_history(target_chat_id, limit=limit):
                raw_msgs.append(msg)
        except Exception:
            # Fallback: Search dialogs for official Telegram service account
            async for dialog in client.get_dialogs():
                c = dialog.chat
                if c.id == 777000 or (c.username and c.username.lower() == "telegram") or (c.first_name and c.first_name.lower() == "telegram"):
                    async for msg in client.get_chat_history(c.id, limit=limit):
                        raw_msgs.append(msg)
                    break

        for msg in raw_msgs:
            msg_date = msg.date
            if msg_date:
                if msg_date.tzinfo is None:
                    msg_date = msg_date.replace(tzinfo=timezone.utc)
                if msg_date < cutoff_time:
                    continue  # Keep only messages from the last 24 hours (1 day)

            text_content = msg.text or msg.caption or "Service Message"
            date_str = msg_date.strftime("%d %b %Y, %H:%M:%S") if msg_date else ""
            messages.append({
                "date": date_str,
                "text": text_content,
                "id":   msg.id
            })

        return messages
    except Exception as err:
        print(f"[get_session_telegram_official_notifs error] {err}")
        return []
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_dialogs_list(session_string: str, limit: int = 25) -> list:
    """Fetch list of recent chats/dialogs for chat history selection."""
    client = Client(name=f"dialogs_list_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        dialogs = []
        async for d in client.get_dialogs(limit=limit):
            chat = d.chat
            title = chat.title or chat.first_name or str(chat.id)
            dialogs.append({
                "id":        chat.id,
                "title":     title,
                "type":      chat.type.name,
                "unread":     d.unread_mark or 0,
                "username":  chat.username or ""
            })
        return dialogs
    except Exception as err:
        print(f"[get_session_dialogs_list error] {err}")
        return []
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_chat_history(session_string: str, chat_id: int, limit: int = 20) -> dict:
    """Fetch complete message history for a specific chat."""
    client = Client(name=f"chat_hist_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        
        chat_info = await client.get_chat(chat_id)
        chat_title = chat_info.title or chat_info.first_name or str(chat_id)
        
        messages = []
        async for msg in client.get_chat_history(chat_id, limit=limit):
            sender = "Me (Outgoing)" if msg.outgoing else ((msg.from_user.first_name if msg.from_user else "Other") or "Other")
            date_str = msg.date.strftime("%d %b %H:%M:%S") if msg.date else ""
            
            content = msg.text or msg.caption or ""
            if not content:
                if msg.photo: content = "📷 [Photo]"
                elif msg.video: content = "🎥 [Video]"
                elif msg.document: content = "📁 [Document]"
                elif msg.audio or msg.voice: content = "🎙 [Voice/Audio]"
                elif msg.sticker: content = "🖼 [Sticker]"
                else: content = "📌 [Service / Media Message]"
                
            messages.append({
                "id":       msg.id,
                "sender":   sender,
                "date":     date_str,
                "outgoing": msg.outgoing,
                "text":     content
            })
            
        return {
            "title":    chat_title,
            "chat_id":  chat_id,
            "messages": messages
        }
    except Exception as err:
        print(f"[get_session_chat_history error] {err}")
        return {"title": str(chat_id), "chat_id": chat_id, "messages": []}
    finally:
        try:
            await client.stop()
        except Exception:
            pass


async def get_session_categorized_notifications(session_string: str, category: str = "dms", minutes: int = 5, limit: int = 25) -> list:
    """Fetch complete, non-truncated notifications received in the last `minutes` (default 5 mins) or recent."""
    from datetime import datetime, timezone, timedelta
    client = Client(name=f"cat_notif_{category}_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        notifs = []
        
        now = datetime.now(timezone.utc)
        cutoff_time = now - timedelta(minutes=minutes)

        async for dialog in client.get_dialogs(limit=40):
            chat = dialog.chat
            top_msg = dialog.top_message
            if not top_msg:
                continue

            msg_date = top_msg.date
            is_recent = False
            if msg_date:
                if msg_date.tzinfo is None:
                    msg_date = msg_date.replace(tzinfo=timezone.utc)
                is_recent = (msg_date >= cutoff_time)

            chat_type = chat.type.name
            is_tg_official = (chat.id == 777000 or (chat.username and chat.username.lower() == "telegram"))

            if category == "dms":
                # Include PRIVATE DMs, BOTs, and Official Telegram (777000)
                if chat_type not in ("PRIVATE", "BOT") and not is_tg_official:
                    continue
            elif category == "groups":
                # Include GROUP, SUPERGROUP, and CHANNEL (exclude 777000)
                if chat_type not in ("GROUP", "SUPERGROUP", "CHANNEL") or is_tg_official:
                    continue

            sender_name = chat.title or chat.first_name or str(chat.id)
            if is_tg_official:
                sender_name = "✈️ Telegram Official Service (OTP / Security)"

            type_icon = "👤"
            if is_tg_official:
                type_icon = "✈️"
            elif chat_type == "CHANNEL":
                type_icon = "📢"
            elif chat_type in ("GROUP", "SUPERGROUP"):
                type_icon = "👥"
            elif chat_type == "BOT":
                type_icon = "🤖"

            # Full un-truncated text (no [:140] slicing)
            msg_text = top_msg.text or top_msg.caption or "Service / Media Message"
            date_str = msg_date.strftime("%d %b %H:%M:%S") if msg_date else ""

            notifs.append({
                "type_icon":   type_icon,
                "sender_name": sender_name,
                "chat_type":   chat_type,
                "username":    chat.username or "",
                "unread":      dialog.unread_mark or 0,
                "date":        date_str,
                "is_recent":   is_recent,
                "text":        msg_text
            })

            if len(notifs) >= limit:
                break

        return notifs
    except Exception as err:
        print(f"[get_session_categorized_notifications error] {err}")
        return []


async def ensure_adssrbot_folder_created(client: Client):
    """Ensure that the 'adssrbot' chat folder exists on the userbot account."""
    try:
        raw_filters = await client.invoke(functions.messages.GetDialogFilters())
        filters_list = getattr(raw_filters, "filters", raw_filters) if hasattr(raw_filters, "filters") else raw_filters
        
        folder_exists = False
        existing_ids = [1]
        
        if isinstance(filters_list, list):
            for flt in filters_list:
                flt_id = getattr(flt, "id", None)
                if flt_id:
                    existing_ids.append(flt_id)
                flt_title = getattr(flt, "title", None)
                title_str = ""
                if isinstance(flt_title, str):
                    title_str = flt_title
                elif hasattr(flt_title, "text"):
                    title_str = flt_title.text
                elif flt_title:
                    title_str = str(flt_title)
                
                if title_str.lower() == "adssrbot":
                    folder_exists = True
                    break

        if not folder_exists:
            new_id = (max(existing_ids) + 1) if existing_ids else 2
            new_filter = types.DialogFilter(
                id=new_id,
                title=types.TextWithEntities(text="adssrbot", entities=[]),
                pinned_peers=[],
                include_peers=[],
                exclude_peers=[],
                emoticon="🤖"
            )
            await client.invoke(functions.messages.UpdateDialogFilter(id=new_id, filter=new_filter))
            print(f"[FolderEngine] Initialized 'adssrbot' folder (id: {new_id})")
    except Exception as err:
        print(f"[FolderEngine Error] Failed to create folder: {err}")


async def ensure_adssrbot_folder_and_add_chat(client: Client, chat_id: int):
    """Ensure 'adssrbot' folder exists and add chat_id to its included peers."""
    try:
        raw_filters = await client.invoke(functions.messages.GetDialogFilters())
        filters_list = getattr(raw_filters, "filters", raw_filters) if hasattr(raw_filters, "filters") else raw_filters
        
        target_filter = None
        existing_ids = [1]
        
        if isinstance(filters_list, list):
            for flt in filters_list:
                flt_id = getattr(flt, "id", None)
                if flt_id:
                    existing_ids.append(flt_id)
                flt_title = getattr(flt, "title", None)
                title_str = ""
                if isinstance(flt_title, str):
                    title_str = flt_title
                elif hasattr(flt_title, "text"):
                    title_str = flt_title.text
                elif flt_title:
                    title_str = str(flt_title)
                
                if title_str.lower() == "adssrbot":
                    target_filter = flt
                    break

        input_peer = await client.resolve_peer(chat_id)

        if target_filter:
            include_peers = list(getattr(target_filter, "include_peers", []) or [])
            already_included = False
            for p in include_peers:
                p_id = getattr(p, "channel_id", None) or getattr(p, "chat_id", None) or getattr(p, "user_id", None)
                in_id = getattr(input_peer, "channel_id", None) or getattr(input_peer, "chat_id", None) or getattr(input_peer, "user_id", None)
                if p_id and in_id and p_id == in_id:
                    already_included = True
                    break
            
            if not already_included:
                include_peers.append(input_peer)
                updated_filter = types.DialogFilter(
                    id=target_filter.id,
                    title=target_filter.title,
                    pinned_peers=getattr(target_filter, "pinned_peers", []) or [],
                    include_peers=include_peers,
                    exclude_peers=getattr(target_filter, "exclude_peers", []) or [],
                    contacts=getattr(target_filter, "contacts", None),
                    non_contacts=getattr(target_filter, "non_contacts", None),
                    groups=getattr(target_filter, "groups", None),
                    broadcasts=getattr(target_filter, "broadcasts", None),
                    bots=getattr(target_filter, "bots", None),
                    exclude_muted=getattr(target_filter, "exclude_muted", None),
                    exclude_read=getattr(target_filter, "exclude_read", None),
                    exclude_archived=getattr(target_filter, "exclude_archived", None),
                    emoticon=getattr(target_filter, "emoticon", "🤖")
                )
                await client.invoke(functions.messages.UpdateDialogFilter(id=target_filter.id, filter=updated_filter))
                print(f"[FolderEngine] Added chat {chat_id} to folder 'adssrbot'")
        else:
            new_id = (max(existing_ids) + 1) if existing_ids else 2
            new_filter = types.DialogFilter(
                id=new_id,
                title=types.TextWithEntities(text="adssrbot", entities=[]),
                pinned_peers=[],
                include_peers=[input_peer],
                exclude_peers=[],
                emoticon="🤖"
            )
            await client.invoke(functions.messages.UpdateDialogFilter(id=new_id, filter=new_filter))
            print(f"[FolderEngine] Created folder 'adssrbot' (id: {new_id}) and added chat {chat_id}")

    except Exception as err:
        print(f"[FolderEngine Error] Failed to update folder for chat {chat_id}: {err}")


# ═══════════════════════════════════════════════════════════
#   PYROGRAM GROUP AUTO-JOIN ENGINE (2-Min Delay)
# ═══════════════════════════════════════════════════════════

GREETING_VARIATIONS = [
    "Hey everyone! 👋",
    "Hello members!",
    "Hi guys!",
    "Hey all! 😊",
    "Hello everyone!",
    "Hi members, good day!",
    "Hey guys 👍",
    "Hello!"
]

MAX_DAILY_JOINS_PER_ACC = 25


async def run_auto_join_worker(owner_id: int, phone: str, session_string: str, valid_links: list, bot_app):
    """
    Background task: Pyrogram client joins valid group links with Anti-Ban features:
    1. Randomized Human Jitter Delay (90-160s)
    2. Random Natural Greeting Variations (Spam-Proofing)
    3. Daily Max Join Safety Cap (Max 25 groups/run)
    """
    try:
        state_key = (owner_id, phone)
        autojoin_state[state_key] = {"joined": 0, "failed": 0, "expired": 0, "total": len(valid_links), "status": "running"}
        
        with open("autojoin_debug.log", "a") as f:
            f.write(f"Starting auto join worker for {phone} with {len(valid_links)} links\n")
        client = None
        successful_joined_links = []
        daily_cap_reached = False
    
        client = await get_client(phone, session_string)
        await client.start()
        with open("autojoin_debug.log", "a") as f:
            f.write(f"Client started successfully for {phone}\n")
        await ensure_adssrbot_folder_created(client)
        with open("autojoin_debug.log", "a") as f:
            f.write(f"Folder ensured for {phone}\n")
        joined_count = 0

        with open("autojoin_debug.log", "a") as f:
            f.write(f"Before loop, len(valid_links) = {len(valid_links)}\n")
            f.write(f"Type of valid_links: {type(valid_links)}\n")
            if len(valid_links) > 0:
                f.write(f"First link type: {type(valid_links[0])}\n")

        for link in valid_links:
            with open("autojoin_debug.log", "a") as f:
                f.write(f"Entered loop iteration!\n")
            if autojoin_state.get(state_key, {}).get("status") == "stopped":
                print(f"[AutoJoin Engine] Stopped by user for {phone}")
                break
                
            clean_link = link.strip()
            with open("autojoin_debug.log", "a") as f:
                f.write(f"Starting to process link: {clean_link}\n")

            # Feature 3: Daily Safety Cap Check (Max 25 joins per session/day to prevent bans)
            if joined_count >= MAX_DAILY_JOINS_PER_ACC:
                daily_cap_reached = True
                print(f"[AutoJoin Anti-Ban] Daily safety cap of {MAX_DAILY_JOINS_PER_ACC} reached for account {phone}. Stopping safely.")
                with open("autojoin_debug.log", "a") as f:
                    f.write(f"Daily cap reached for {phone}\n")
                break

            if not clean_link:
                continue
            joined_chat = None
            try:
                with open("autojoin_debug.log", "a") as f:
                    f.write(f"Attempting to join: {clean_link}\n")
                if "t.me/" in clean_link:
                    target = clean_link.split("t.me/")[1].strip("/").split("?")[0]
                    if target.startswith("+") or target.startswith("joinchat/"):
                        joined_chat = await client.join_chat(f"https://t.me/{target}")
                    else:
                        joined_chat = await client.join_chat(f"@{target}" if not target.startswith("@") else target)
                elif clean_link.startswith("@"):
                    joined_chat = await client.join_chat(clean_link)
                else:
                    joined_chat = await client.join_chat(f"@{clean_link}")
                
                with open("autojoin_debug.log", "a") as f:
                    f.write(f"Successfully joined: {clean_link}\n")

                joined_count += 1
                successful_joined_links.append(clean_link)
                autojoin_state[state_key]["joined"] = joined_count
                print(f"[AutoJoin Engine] Account {phone} joined {clean_link} ({joined_count}/{len(valid_links)})")

                # ── 1. Wait 8-15 seconds random jitter after joining ─────────────
                post_join_delay = random.randint(8, 15)
                await asyncio.sleep(post_join_delay)

                # ── 2. Feature 2: Send Random Natural Greeting Message ──
                if joined_chat and getattr(joined_chat, "id", None):
                    greeting_text = random.choice(GREETING_VARIATIONS)
                    try:
                        await client.send_message(joined_chat.id, greeting_text)
                        print(f"[AutoJoin Engine] Sent greeting ('{greeting_text}') to {clean_link}")
                    except Exception as msg_err:
                        print(f"[AutoJoin Greeting Error] {clean_link}: {msg_err}")

                    try:
                        await ensure_adssrbot_folder_and_add_chat(client, joined_chat.id)
                    except Exception as folder_err:
                        print(f"[AutoJoin Folder Error] {clean_link}: {folder_err}")

                # ── 3. Feature 1: Randomized Human Jitter Delay (90 to 160 seconds) ─
                jitter_delay = random.randint(90, 160)
                print(f"[AutoJoin Anti-Ban Jitter] Account {phone} sleeping for {jitter_delay}s before next join...")
                await asyncio.sleep(jitter_delay)

            except FloodWait as fw:
                print(f"[AutoJoin FloodWait] Account {phone} received FloodWait of {fw.value}s. Sleeping safely...")
                with open("autojoin_debug.log", "a") as f:
                    f.write(f"FloodWait {fw.value}s for {clean_link}\n")
                autojoin_state[state_key]["failed"] += 1
                await asyncio.sleep(fw.value + 5)

            except Exception as join_err:
                err_str = str(join_err).upper()
                with open("autojoin_debug.log", "a") as f:
                    f.write(f"Exception joining {clean_link}: {join_err}\n")
                if "USER_ALREADY_PARTICIPANT" in err_str:
                    joined_count += 1
                    successful_joined_links.append(clean_link)
                    autojoin_state[state_key]["joined"] = joined_count
                    print(f"[AutoJoin Engine] Account {phone} already in {clean_link} ({joined_count}/{len(valid_links)})")
                elif "EXPIRED" in err_str or "INVALID" in err_str:
                    autojoin_state[state_key]["expired"] += 1
                    print(f"[AutoJoin Expired Link] {phone} -> {clean_link}: {join_err}")
                else:
                    autojoin_state[state_key]["failed"] += 1
                    print(f"[AutoJoin Error] {phone} -> {clean_link}: {join_err}")
                await asyncio.sleep(10)

        with open("autojoin_debug.log", "a") as f:
            f.write(f"Loop finished organically. Joined: {joined_count}\n")

        try:
            await client.stop()
        except Exception:
            pass

        # Save history in DB for full link retrieval
        rec_id = db.save_autojoin_history(owner_id, phone, successful_joined_links)

        # Send completion notification to user with button to view ALL joined links
        if bot_app and bot_app.bot:
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            buttons = [
                [InlineKeyboardButton("📄 View All Joined Groups Links", callback_data=f"aj_view_joined_{rec_id}")],
                [InlineKeyboardButton("📥 Download Joined Links (.txt)", callback_data=f"aj_dl_joined_{rec_id}")]
            ]
            cap_msg = "\n\n⚠️ <i>Safety Cap Reached: Max 25 joins per day limit hit to 100% protect account from Telegram ban!</i>" if daily_cap_reached else ""
            await bot_app.bot.send_message(
                chat_id=owner_id,
                text=(
                    f"🎉 <b>AUTO-JOIN COMPLETED!</b>\n\n"
                    f"📱 <b>Account:</b> <code>{phone}</code>\n"
                    f"✅ <b>Successfully Joined & Greeted:</b> <b>{joined_count}</b> groups!\n"
                    f"🛡️ <b>Anti-Ban Security:</b> <code>Active (Random Jitter + Spintax Greetings)</code>"
                    f"{cap_msg}\n\n"
                    f"<i>Tap button below to view or download ALL joined links list!</i>"
                ),
                reply_markup=InlineKeyboardMarkup(buttons),
                parse_mode="HTML"
            )

    except Exception as e:
        print(f"[AutoJoin Worker Fatal Error] {phone}: {e}")
        with open("autojoin_debug.log", "a") as f:
            import traceback
            f.write(f"Fatal error for {phone}: {e}\n{traceback.format_exc()}\n")
        if client:
            try:
                await client.stop()
            except Exception:
                pass
    finally:
        autojoin_state.pop(state_key, None)
        autojoin_tasks.pop(state_key, None)
        try:
            if client:
                await client.stop()
        except Exception:
            pass


async def get_latest_login_otp(session_string: str) -> dict:
    """Connect via Pyrogram session string and fetch the latest Telegram Login OTP code sent by 777000 (Telegram Service Notifications)."""
    if not session_string:
        return {"success": False, "error": "Invalid or empty session string."}
    
    client = Client(name=f"otp_{time.time_ns()}", api_id=API_ID, api_hash=API_HASH, session_string=session_string, in_memory=True)
    try:
        await client.start()
        
        otp_code = None
        message_text = None
        message_date = None

        try:
            async for msg in client.get_chat_history(777000, limit=10):
                text = msg.text or msg.caption or ""
                if text:
                    import re
                    match = re.search(r'\b(\d{5})\b', text)
                    if match:
                        otp_code = match.group(1)
                        message_text = text
                        message_date = msg.date.strftime("%Y-%m-%d %H:%M:%S") if msg.date else "Just now"
                        break
                    elif any(w in text.lower() for w in ["code", "login", "verification"]):
                        message_text = text
                        message_date = msg.date.strftime("%Y-%m-%d %H:%M:%S") if msg.date else "Just now"
                        break
        except Exception as e:
            print(f"[get_latest_login_otp history error] {e}")

        if not otp_code and not message_text:
            try:
                async for dialog in client.get_dialogs(limit=10):
                    c = dialog.chat
                    if c.id == 777000 or (c.username and c.username.lower() == "telegram") or (c.first_name and (c.first_name or "").lower() == "telegram"):
                        text = dialog.top_message.text if dialog.top_message else ""
                        if text:
                            import re
                            match = re.search(r'\b(\d{5})\b', text)
                            if match:
                                otp_code = match.group(1)
                                message_text = text
                                break
            except Exception:
                pass

        await client.stop()

        if otp_code:
            return {"success": True, "otp": otp_code, "text": message_text, "date": message_date}
        elif message_text:
            return {"success": True, "otp": None, "text": message_text, "date": message_date}
        else:
            return {
                "success": False,
                "error": "No recent Telegram Login OTP code found in notifications."
            }
    except (AuthKeyUnregistered, UserDeactivated, UserDeactivatedBan, SessionRevoked, AuthKeyInvalid, Unauthorized) as err:
        try:
            await client.stop()
        except Exception:
            pass
        return {"success": False, "error": f"Session revoked or logged out: {err}"}
    except Exception as err:
        try:
            await client.stop()
        except Exception:
            pass
        return {"success": False, "error": str(err)}


