"""
bot.py — Entry point wrapper calling main.py
"""
import main

if __name__ == "__main__":
    main.main()

