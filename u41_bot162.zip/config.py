# ============================================================
#   AdBot — Configuration File
#   Fill in your credentials below before running the bot
# ============================================================

# ─── BOT CREDENTIALS ────────────────────────────────────────
# Get this from @BotFather on Telegram
BOT_TOKEN = "8244568420:AAEm_FISmcGz7u3iv1fPSdD7UZYlEgETl6E"

# ─── TELEGRAM API CREDENTIALS ───────────────────────────────
# Get these from https://my.telegram.org → API Development Tools
API_ID   = 37502006
API_HASH = "9104a85f0ff8a082de836d76cdbed6d6"

# ─── ADMIN SETTINGS ─────────────────────────────────────────
# Your Telegram user ID (get it from @userinfobot)
ADMIN_IDS = [8949860238, 8207882848]  # Your Telegram user ID(s)

# ─── BOT SETTINGS ───────────────────────────────────────────
BOT_USERNAME   = "@YourAdBot"
LOGGER_BOT     = "@YourLoggerBot"
SESSION_FOLDER = "sessions"
DB_PATH        = "adbot.db"

# ─── FORCE JOIN CHANNELS ────────────────────────────────────
# User must join these channels to use the bot
FORCE_JOIN_CHANNEL_1 = "@Adssrbo"
FORCE_JOIN_LINK_1    = "https://t.me/Adssrbo"
FORCE_JOIN_CHANNEL_2 = "-1003066762141"
FORCE_JOIN_LINK_2    = "https://t.me/+kvrfavfd-1FjMTQ1"

# ─── WEB APP URL (ngrok tunnel) ──────────────────────────────
WEBAPP_URL = "https://amplifier-astronaut-cognition.ngrok-free.dev/dashboard.html"

# ─── BROADCAST INTERVALS (in seconds) ───────────────────────
INTERVALS = {
    "15sec": 15,
    "1min":  60,
    "5min":  300,
    "10min": 600,
    "30min": 1800,
    "1hr":   3600,
}

# ─── CYCLE OPTIONS ──────────────────────────────────────────
CYCLES = [1, 5, 10, 25, 50, 0]   # 0 = unlimited ♾️

# ─── DISCLAIMER ─────────────────────────────────────────────
DISCLAIMER = (
    "🚫 Any Illegal Ads or content are NOT allowed.\n"
    "If found, accounts will be banned.\n"
    "Creator is not liable for misuse. Use at your own risk. 🤝"
)

# ─── GMAIL IMAP AUTO-VERIFICATION SETTINGS ──────────────────
# Scans FamPay / Bank payment alert emails via IMAP SSL
import os
# Admin Panel Security & Direct Chrome Link Settings
PANEL_BASE_URL = os.getenv("PANEL_BASE_URL", "http://localhost:8001")
ADMIN_PANEL_PASSWORD = os.getenv("ADMIN_PANEL_PASSWORD", "admin123")
ADMIN_AUTH_SECRET = os.getenv("ADMIN_AUTH_SECRET", "tgstore_admin_secret_99281")

GMAIL_EMAIL    = os.getenv("GMAIL_EMAIL", "chinupatraq@gmail.com")
GMAIL_PASSWORD = os.getenv("GMAIL_PASSWORD", "uukhhygbgodrhboh")

