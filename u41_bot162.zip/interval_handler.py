"""
handlers/interval_handler.py — Interval & Cycle Settings
Inline keyboard-based selection for broadcast timing and cycles
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler
import database as db
from config import INTERVALS, CYCLES


def interval_keyboard():
    buttons = [
        [
            InlineKeyboardButton("⚡ 1 min",  callback_data="interval_1min"),
            InlineKeyboardButton("🕐 5 min",  callback_data="interval_5min"),
        ],
        [
            InlineKeyboardButton("🕑 10 min", callback_data="interval_10min"),
            InlineKeyboardButton("🕕 30 min", callback_data="interval_30min"),
        ],
        [
            InlineKeyboardButton("🕐 1 hour", callback_data="interval_1hr"),
        ]
    ]
    return InlineKeyboardMarkup(buttons)


def cycle_keyboard():
    buttons = [
        [
            InlineKeyboardButton("1×",  callback_data="cycle_1"),
            InlineKeyboardButton("5×",  callback_data="cycle_5"),
            InlineKeyboardButton("10×", callback_data="cycle_10"),
        ],
        [
            InlineKeyboardButton("25×", callback_data="cycle_25"),
            InlineKeyboardButton("50×", callback_data="cycle_50"),
            InlineKeyboardButton("♾️ Unlimited", callback_data="cycle_0"),
        ]
    ]
    return InlineKeyboardMarkup(buttons)


async def setinterval_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Show interval selection keyboard."""
    await update.message.reply_text(
        "⏱ *Select Broadcast Interval:*\n\nHow often should the ad be sent?",
        reply_markup=interval_keyboard(),
        parse_mode="Markdown"
    )


async def interval_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Handle interval selection."""
    query    = update.callback_query
    uid      = query.from_user.id
    interval = query.data.replace("interval_", "")

    await query.answer()
    db.update_settings(uid, interval=interval)

    await query.edit_message_text(
        f"✅ Interval set to *{interval}*!\n\n"
        "Now select number of cycles:",
        reply_markup=cycle_keyboard(),
        parse_mode="Markdown"
    )


async def cycle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Handle cycle selection."""
    query  = update.callback_query
    uid    = query.from_user.id
    cycles = int(query.data.replace("cycle_", ""))

    await query.answer()
    db.update_settings(uid, cycles=cycles)

    settings = db.get_settings(uid)
    cycle_str = "♾️ Unlimited" if cycles == 0 else str(cycles)

    await query.edit_message_text(
        f"✅ *Settings Saved!*\n\n"
        f"⏱ Interval: *{settings['interval']}*\n"
        f"🔄 Cycles: *{cycle_str}*\n\n"
        "Use /startbroadcast to begin! 🚀",
        parse_mode="Markdown"
    )


async def setcycles_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Show cycles selection keyboard."""
    await update.message.reply_text(
        "🔄 *Select Number of Cycles:*\n\nHow many rounds should the ad broadcast?",
        reply_markup=cycle_keyboard(),
        parse_mode="Markdown"
    )
