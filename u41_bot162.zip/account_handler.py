"""
handlers/account_handler.py — Add/Remove Telegram Accounts
Handles OTP flow and 2FA for adding user accounts
"""

import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, ConversationHandler, CommandHandler,
    MessageHandler, filters, CallbackQueryHandler
)
from pyrogram import Client
from pyrogram.errors import (
    PhoneNumberInvalid, PhoneCodeInvalid, PhoneCodeExpired,
    SessionPasswordNeeded, PasswordHashInvalid
)
import database as db
from config import API_ID, API_HASH

# Conversation states
ENTER_PHONE = 1
ENTER_OTP   = 2
ENTER_2FA   = 3

# Temp storage: {user_id: {phone, client}}
pending_logins = {}


async def addaccount_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Start the add account flow."""
    uid = update.effective_user.id
    await update.message.reply_text(
        "📱 *Add Telegram Account*\n\n"
        "Send me the phone number with country code:\n"
        "Example: `+919876543210`\n\n"
        "Type /cancel to abort.",
        parse_mode="Markdown"
    )
    return ENTER_PHONE


async def receive_phone(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Receive phone number and send OTP."""
    uid   = update.effective_user.id
    phone = update.message.text.strip()

    if not phone.startswith("+"):
        await update.message.reply_text("❌ Invalid format. Use: `+919876543210`", parse_mode="Markdown")
        return ENTER_PHONE

    await update.message.reply_text(f"⏳ Sending OTP to `{phone}`...", parse_mode="Markdown")

    try:
        client = Client(
            name=phone,
            api_id=API_ID,
            api_hash=API_HASH,
            in_memory=True
        )
        await client.connect()
        sent = await client.send_code(phone)
        pending_logins[uid] = {
            "phone": phone,
            "client": client,
            "phone_code_hash": sent.phone_code_hash
        }

        await update.message.reply_text(
            f"✅ OTP sent to `{phone}`\n\n"
            "Enter the OTP you received (format: `1 2 3 4 5` with spaces):",
            parse_mode="Markdown"
        )
        return ENTER_OTP

    except PhoneNumberInvalid:
        await update.message.reply_text("❌ Invalid phone number. Try again:")
        return ENTER_PHONE
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}\nTry again:")
        return ENTER_PHONE


async def receive_otp(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Receive OTP and sign in."""
    uid  = update.effective_user.id
    code = update.message.text.strip().replace(" ", "")

    if uid not in pending_logins:
        await update.message.reply_text("⚠️ Session expired. Use /addaccount again.")
        return ConversationHandler.END

    data   = pending_logins[uid]
    client = data["client"]
    phone  = data["phone"]

    try:
        await client.sign_in(phone, data["phone_code_hash"], code)
        session_string = await client.export_session_string()
        await client.disconnect()

        db.add_account(uid, phone, session_string)
        del pending_logins[uid]

        await update.message.reply_text(
            f"✅ Account `{phone}` added successfully!\n"
            f"Total accounts: {db.count_accounts(uid)}",
            parse_mode="Markdown"
        )
        return ConversationHandler.END

    except SessionPasswordNeeded:
        ctx.user_data["2fa_phone"] = phone
        await update.message.reply_text(
            "🔐 *2FA Password Required*\n\nEnter your Two-Factor Authentication password:",
            parse_mode="Markdown"
        )
        return ENTER_2FA

    except PhoneCodeInvalid:
        await update.message.reply_text("❌ Wrong OTP. Try again:")
        return ENTER_OTP

    except PhoneCodeExpired:
        await update.message.reply_text("❌ OTP expired. Use /addaccount to restart.")
        del pending_logins[uid]
        return ConversationHandler.END

    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}")
        return ConversationHandler.END


async def receive_2fa(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Receive 2FA password."""
    uid      = update.effective_user.id
    password = update.message.text.strip()

    if uid not in pending_logins:
        await update.message.reply_text("⚠️ Session expired. Use /addaccount again.")
        return ConversationHandler.END

    data   = pending_logins[uid]
    client = data["client"]
    phone  = data["phone"]

    try:
        await client.check_password(password)
        session_string = await client.export_session_string()
        await client.disconnect()

        db.add_account(uid, phone, session_string, two_fa_password=password)
        del pending_logins[uid]

        await update.message.reply_text(
            f"✅ Account `{phone}` added (2FA verified)!\n"
            f"Total accounts: {db.count_accounts(uid)}",
            parse_mode="Markdown"
        )
        return ConversationHandler.END

    except PasswordHashInvalid:
        await update.message.reply_text("❌ Wrong 2FA password. Try again:")
        return ENTER_2FA

    except Exception as e:
        await update.message.reply_text(f"❌ Error: {e}")
        return ConversationHandler.END


async def cancel_conv(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid in pending_logins:
        try:
            await pending_logins[uid]["client"].disconnect()
        except:
            pass
        del pending_logins[uid]
    await update.message.reply_text("❌ Cancelled.")
    return ConversationHandler.END


async def myaccounts_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """List all added accounts."""
    uid      = update.effective_user.id
    accounts = db.get_accounts(uid)

    if not accounts:
        await update.message.reply_text(
            "📭 No accounts added yet.\nUse /addaccount to add one."
        )
        return

    lines = ["📱 *Your Accounts:*\n"]
    for i, acc in enumerate(accounts, 1):
        lines.append(f"{i}. `{acc['phone']}`")

    lines.append(f"\n*Total: {len(accounts)} account(s)*")
    lines.append("\nUse /removeaccount to remove one.")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def removeaccount_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Show inline buttons to remove an account."""
    uid      = update.effective_user.id
    accounts = db.get_accounts(uid)

    if not accounts:
        await update.message.reply_text("📭 No accounts to remove.")
        return

    buttons = [
        [InlineKeyboardButton(f"🗑 {acc['phone']}", callback_data=f"remove_{acc['phone']}")]
        for acc in accounts
    ]
    buttons.append([InlineKeyboardButton("❌ Cancel", callback_data="remove_cancel")])

    await update.message.reply_text(
        "Select account to remove:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def remove_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Handle remove account button press."""
    query = update.callback_query
    uid   = query.from_user.id
    await query.answer()

    if query.data == "remove_cancel":
        await query.edit_message_text("❌ Cancelled.")
        return

    phone = query.data.replace("remove_", "", 1)
    db.remove_account(uid, phone)
    await query.edit_message_text(f"✅ Account `{phone}` removed.", parse_mode="Markdown")


# ── ConversationHandler builder ─────────────────────────────
def get_account_conv_handler():
    return ConversationHandler(
        entry_points=[CommandHandler("addaccount", addaccount_cmd)],
        states={
            ENTER_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_phone)],
            ENTER_OTP:   [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_otp)],
            ENTER_2FA:   [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_2fa)],
        },
        fallbacks=[CommandHandler("cancel", cancel_conv)],
        allow_reentry=True
    )
