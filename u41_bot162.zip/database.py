"""
database.py — SQLite Database Manager for AdBot
Handles all DB operations: accounts, ads, settings, logs
"""

import sqlite3
import json
import time
import collections
import asyncio
from config import DB_PATH


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=60.0)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=60000;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA cache_size=-128000;") # 128MB RAM Cache
        conn.execute("PRAGMA temp_store=MEMORY;")
        conn.execute("PRAGMA mmap_size=30000000000;") # 30GB RAM Memory-Mapped I/O
    except Exception:
        pass
    return conn


get_db = get_conn


def init_db():
    """Initialize all database tables and high-performance indexes."""
    conn = get_conn()
    c = conn.cursor()

    # ── Accounts table ──────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS accounts (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id      INTEGER NOT NULL,
            phone         TEXT    NOT NULL UNIQUE,
            session_string TEXT   NOT NULL,
            first_name    TEXT    DEFAULT '',
            last_name     TEXT    DEFAULT '',
            username      TEXT    DEFAULT '',
            tg_user_id    INTEGER DEFAULT 0,
            two_fa_password TEXT  DEFAULT '',
            is_active     INTEGER DEFAULT 1,
            added_at      INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Auto-migrate accounts table if needed ─────────────────
    for col, col_def in [
        ("first_name", "TEXT DEFAULT ''"),
        ("last_name", "TEXT DEFAULT ''"),
        ("username", "TEXT DEFAULT ''"),
        ("tg_user_id", "INTEGER DEFAULT 0"),
        ("two_fa_password", "TEXT DEFAULT ''"),
        ("custom_ad", "TEXT DEFAULT ''"),
        ("custom_auto_reply", "TEXT DEFAULT ''")
    ]:
        try:
            c.execute(f"ALTER TABLE accounts ADD COLUMN {col} {col_def}")
        except Exception:
            pass

    # ── Ad messages table ────────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS ad_messages (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id  INTEGER NOT NULL,
            message   TEXT    NOT NULL,
            media_path TEXT,
            created_at INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── User settings table ──────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            owner_id    INTEGER PRIMARY KEY,
            interval    TEXT    DEFAULT '5min',
            cycles      INTEGER DEFAULT 0,
            is_running  INTEGER DEFAULT 0,
            start_time  INTEGER,
            cycle_done  INTEGER DEFAULT 0,
            target_mode TEXT    DEFAULT 'groups'
        )
    """)

    # ── Auto-migrate settings table ──────────────────────────
    try:
        c.execute("ALTER TABLE settings ADD COLUMN target_mode TEXT DEFAULT 'groups'")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE settings ADD COLUMN auto_reply_enabled INTEGER DEFAULT 1")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE settings ADD COLUMN auto_reply_text TEXT DEFAULT 'ye meri ad ac hy tu yadi kuch lena chate ho to yaha pe message kar sakhte ho @example'")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE settings ADD COLUMN ad_mode TEXT DEFAULT 'custom'")
    except Exception:
        pass

    try:
        c.execute("UPDATE settings SET is_running = 0")
    except Exception:
        pass

    # ── Delivery logs table ──────────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id   INTEGER NOT NULL,
            phone      TEXT,
            group_name TEXT,
            status     TEXT,
            timestamp  INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Users table (admin panel tracking) ───────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT    DEFAULT '',
            first_name  TEXT    DEFAULT '',
            joined_at   INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Bot config table (global settings like welcome video) ───
    c.execute("""
        CREATE TABLE IF NOT EXISTS bot_config (
            key   TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    # ── Welcome videos playlist table ────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS welcome_videos (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            video_id    TEXT NOT NULL,
            video_type  TEXT DEFAULT 'video',
            added_at    INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Auto-migrate users table for premium status ─────────────
    try:
        c.execute("ALTER TABLE users ADD COLUMN is_premium INTEGER DEFAULT 0")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE users ADD COLUMN premium_added_at INTEGER DEFAULT 0")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE users ADD COLUMN balance REAL DEFAULT 0.0")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE users ADD COLUMN total_spent REAL DEFAULT 0.0")
    except Exception:
        pass

    # ── Escrow Channels List Table (for 1200+ channels) ─────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS escrow_channels (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            link        TEXT NOT NULL UNIQUE,
            category    TEXT DEFAULT 'escrow',
            added_at    INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Pending Payments Table (for QR screenshot verification) ─
    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_payments (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            file_id     TEXT NOT NULL,
            status      TEXT DEFAULT 'pending',
            created_at  INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── FamPay Cloud Sessions Table ─────────────────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS fampay_sessions (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            phone        TEXT NOT NULL UNIQUE,
            upi_id       TEXT DEFAULT '',
            auth_token   TEXT NOT NULL,
            device_id    TEXT DEFAULT '',
            account_name TEXT DEFAULT 'FamPay User',
            balance      REAL DEFAULT 0.0,
            is_active    INTEGER DEFAULT 1,
            last_sync    TEXT DEFAULT (datetime('now', 'localtime')),
            created_at   INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Incoming Bank / UPI Transactions Table ──────────────────
    c.execute("""
        CREATE TABLE IF NOT EXISTS incoming_bank_transactions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            utr             TEXT UNIQUE,
            amount          REAL NOT NULL,
            sender_name     TEXT DEFAULT '',
            source_app      TEXT DEFAULT 'FamPay Cloud',
            status          TEXT DEFAULT 'processed',
            matched_user_id INTEGER DEFAULT 0,
            created_at      INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── Auto-Join History Table (for saving joined group links) ──────
    c.execute("""
        CREATE TABLE IF NOT EXISTS autojoin_history (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            phone        TEXT NOT NULL,
            joined_count INTEGER DEFAULT 0,
            joined_links TEXT DEFAULT '[]',
            created_at   INTEGER DEFAULT (strftime('%s','now'))
        )
    """)

    # ── High-Performance & Composite Database Indexes ──────────
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_accounts_owner ON accounts(owner_id)",
        "CREATE INDEX IF NOT EXISTS idx_accounts_phone ON accounts(phone)",
        "CREATE INDEX IF NOT EXISTS idx_accounts_owner_active ON accounts(owner_id, is_active)",
        "CREATE INDEX IF NOT EXISTS idx_accounts_owner_phone ON accounts(owner_id, phone)",
        "CREATE INDEX IF NOT EXISTS idx_ad_messages_owner ON ad_messages(owner_id)",
        "CREATE INDEX IF NOT EXISTS idx_ad_messages_owner_id ON ad_messages(owner_id, id DESC)",
        "CREATE INDEX IF NOT EXISTS idx_logs_owner ON logs(owner_id)",
        "CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_logs_owner_status_time ON logs(owner_id, status, timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_logs_owner_time ON logs(owner_id, timestamp DESC)",
        "CREATE INDEX IF NOT EXISTS idx_join_requests_user ON join_requests(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_join_requests_user_chat ON join_requests(user_id, chat_id)",
        "CREATE INDEX IF NOT EXISTS idx_users_user_id ON users(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_users_is_premium ON users(is_premium)",
        "CREATE INDEX IF NOT EXISTS idx_pending_payments_user ON pending_payments(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_escrow_channels_id ON escrow_channels(id)",
        "CREATE INDEX IF NOT EXISTS idx_autojoin_history_user ON autojoin_history(user_id)"
    ]
    for idx_sql in indexes:
        try:
            c.execute(idx_sql)
        except Exception:
            pass

    # ── Shop Tables ────────────────────────────────────────────────
    c.execute("""
    CREATE TABLE IF NOT EXISTS shop_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        emoji TEXT DEFAULT '📦',
        description TEXT DEFAULT '',
        display_order INTEGER DEFAULT 0
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS shop_products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT DEFAULT '',
        item_type TEXT DEFAULT 'text'
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS shop_stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        data_text TEXT DEFAULT '',
        file_path TEXT DEFAULT '',
        is_sold INTEGER DEFAULT 0,
        sold_to INTEGER DEFAULT NULL,
        sold_at INTEGER DEFAULT NULL,
        created_at INTEGER DEFAULT (strftime('%s','now'))
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS shop_orders (
        order_id TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        delivered_data TEXT DEFAULT '',
        delivered_file TEXT DEFAULT '',
        created_at INTEGER DEFAULT (strftime('%s','now'))
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS deposits (
        tx_id TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        gateway TEXT DEFAULT 'UPI',
        status TEXT DEFAULT 'pending',
        utr TEXT DEFAULT '',
        created_at INTEGER DEFAULT (strftime('%s','now'))
    )
    """)

    # Incoming Bank Transactions Table is already created above in adbotorg, wait, let me check. 
    # Ah, it's incoming_bank_transactions, yes, it's at line 204.
    
    c.execute("""
    CREATE TABLE IF NOT EXISTS bank_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bank_name TEXT NOT NULL,
        account_number TEXT DEFAULT '',
        customer_id TEXT DEFAULT '',
        mobile_number TEXT DEFAULT '',
        session_token TEXT DEFAULT '',
        cookies_json TEXT DEFAULT '',
        balance REAL DEFAULT 0.0,
        is_active INTEGER DEFAULT 1,
        last_sync TEXT DEFAULT (datetime('now', 'localtime')),
        created_at INTEGER DEFAULT (strftime('%s','now'))
    )
    """)



    conn.commit()
    conn.close()
    print("✅ Database initialized with WAL mode & composite fast indexes.")


_join_requests_cache = set()


def record_join_request(user_id: int, chat_id: str):
    clean_id = str(chat_id).strip()
    _join_requests_cache.add((user_id, clean_id))
    _join_requests_cache.add((user_id, f"@{clean_id.replace('@','')}"))
    _join_requests_cache.add((user_id, clean_id.replace("@","")))
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT OR REPLACE INTO join_requests (user_id, chat_id, created_at) VALUES (?, ?, strftime('%s','now'))",
        (user_id, clean_id)
    )
    conn.commit()
    conn.close()


def has_user_requested_join(user_id: int, chat_id: str = None) -> bool:
    if chat_id:
        clean_id = str(chat_id).strip()
        if (user_id, clean_id) in _join_requests_cache or (user_id, f"@{clean_id.replace('@','')}") in _join_requests_cache:
            return True
    conn = get_conn()
    c = conn.cursor()
    if chat_id:
        clean_id = str(chat_id).strip()
        c.execute(
            "SELECT 1 FROM join_requests WHERE user_id = ? AND (chat_id = ? OR chat_id = ? OR chat_id = ?)",
            (user_id, clean_id, f"@{clean_id.replace('@','')}", clean_id.replace("@",""))
        )
        row = c.fetchone()
        if row:
            conn.close()
            return True
    
    c.execute("SELECT 1 FROM join_requests WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    return row is not None


def remove_join_request(user_id: int, chat_id: str = None):
    conn = get_conn()
    c = conn.cursor()
    if chat_id:
        clean_id = str(chat_id).strip()
        c.execute(
            "DELETE FROM join_requests WHERE user_id = ? AND (chat_id = ? OR chat_id = ? OR chat_id = ?)",
            (user_id, clean_id, f"@{clean_id.replace('@','')}", clean_id.replace("@",""))
        )
    else:
        c.execute("DELETE FROM join_requests WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()


_config_cache = {}


def set_config(key: str, value: str):
    global _config_cache
    _config_cache[key] = value
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO bot_config (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()


def get_config(key: str, default: str = None) -> str:
    if key in _config_cache:
        return _config_cache[key]
    conn = get_conn()
    row = conn.execute("SELECT value FROM bot_config WHERE key = ?", (key,)).fetchone()
    conn.close()
    val = row["value"] if row else default
    if val is not None:
        _config_cache[key] = val
    return val


def delete_config(key: str):
    global _config_cache
    _config_cache.pop(key, None)
    conn = get_conn()
    conn.execute("DELETE FROM bot_config WHERE key = ?", (key,))
    conn.commit()
    conn.close()


# ═══════════════════════════════════════════════════════════
#   WELCOME VIDEOS PLAYLIST OPERATIONS
# ═══════════════════════════════════════════════════════════

_welcome_videos_cache = None


def add_welcome_video(video_id: str, video_type: str = "video") -> int:
    global _welcome_videos_cache
    _welcome_videos_cache = None
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO welcome_videos (video_id, video_type) VALUES (?, ?)", (video_id, video_type))
    vid = c.lastrowid
    conn.commit()
    conn.close()
    return vid


def get_welcome_videos() -> list:
    global _welcome_videos_cache
    if _welcome_videos_cache is not None:
        return _welcome_videos_cache
    conn = get_conn()
    rows = conn.execute("SELECT * FROM welcome_videos ORDER BY id ASC").fetchall()
    conn.close()
    _welcome_videos_cache = rows
    return rows


def delete_welcome_video(vid_id: int) -> bool:
    global _welcome_videos_cache
    _welcome_videos_cache = None
    conn = get_conn()
    conn.execute("DELETE FROM welcome_videos WHERE id=?", (vid_id,))
    conn.commit()
    conn.close()
    return True


def clear_welcome_videos() -> bool:
    global _welcome_videos_cache
    _welcome_videos_cache = None
    conn = get_conn()
    conn.execute("DELETE FROM welcome_videos")
    delete_config("welcome_video_id")
    delete_config("welcome_video_type")
    conn.commit()
    conn.close()
    return True


def get_next_welcome_video_for_user(user_id: int) -> tuple:
    """Returns (video_id, video_type) in alternating rotation sequence per user."""
    vids = get_welcome_videos()
    if vids:
        conn = get_conn()
        row = conn.execute("SELECT welcome_idx FROM settings WHERE owner_id=?", (user_id,)).fetchone()
        idx = row["welcome_idx"] if (row and "welcome_idx" in dict(row) and row["welcome_idx"] is not None) else 0
        
        selected = dict(vids[idx % len(vids)])
        next_idx = idx + 1
        
        get_settings(user_id)
        conn.execute("UPDATE settings SET welcome_idx=? WHERE owner_id=?", (next_idx, user_id))
        conn.commit()
        conn.close()
        return selected["video_id"], selected["video_type"]
    
    legacy_id = get_config("welcome_video_id")
    legacy_type = get_config("welcome_video_type", "video")
    if legacy_id:
        return legacy_id, legacy_type
    
    return None, None


# ═══════════════════════════════════════════════════════════
#   ACCOUNT OPERATIONS
# ═══════════════════════════════════════════════════════════

_accounts_cache = {}


def invalidate_accounts_cache(owner_id: int = None):
    if owner_id is not None:
        _accounts_cache.pop((owner_id, True), None)
        _accounts_cache.pop((owner_id, False), None)
    else:
        _accounts_cache.clear()


def add_account(owner_id: int, phone: str, session_string: str, first_name: str = "", last_name: str = "", username: str = "", tg_user_id: int = 0, two_fa_password: str = "") -> bool:
    invalidate_accounts_cache(owner_id)
    try:
        conn = get_conn()
        conn.execute(
            "INSERT OR REPLACE INTO accounts (owner_id, phone, session_string, first_name, last_name, username, tg_user_id, two_fa_password) VALUES (?,?,?,?,?,?,?,?)",
            (owner_id, phone, session_string, first_name, last_name, username, tg_user_id, two_fa_password)
        )
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] add_account error: {e}")
        return False


def get_accounts(owner_id: int, active_only: bool = False):
    key = (owner_id, active_only)
    if key in _accounts_cache:
        return _accounts_cache[key]
    conn = get_conn()
    if active_only:
        rows = conn.execute(
            "SELECT * FROM accounts WHERE owner_id=? AND is_active=1 ORDER BY id ASC", (owner_id,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM accounts WHERE owner_id=? ORDER BY id ASC", (owner_id,)
        ).fetchall()
    conn.close()
    _accounts_cache[key] = rows
    return rows


def get_account_by_id(acc_id: int):
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM accounts WHERE id=?", (acc_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def toggle_account_active(owner_id: int, phone: str) -> bool:
    invalidate_accounts_cache(owner_id)
    try:
        conn = get_conn()
        row = conn.execute("SELECT is_active FROM accounts WHERE owner_id=? AND phone=?", (owner_id, phone)).fetchone()
        if row:
            new_val = 0 if row["is_active"] == 1 else 1
            conn.execute("UPDATE accounts SET is_active=? WHERE owner_id=? AND phone=?", (new_val, owner_id, phone))
            conn.commit()
            conn.close()
            return True
        conn.close()
        return False
    except Exception as e:
        print(f"[DB] toggle_account_active error: {e}")
        return False


def set_account_custom_ad(owner_id: int, phone: str, custom_ad: str) -> bool:
    invalidate_accounts_cache(owner_id)
    try:
        conn = get_conn()
        conn.execute("UPDATE accounts SET custom_ad=? WHERE owner_id=? AND phone=?", (custom_ad, owner_id, phone))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] set_account_custom_ad error: {e}")
        return False


def get_account_by_phone(owner_id_or_phone, phone: str = None):
    if phone is not None:
        owner_id = owner_id_or_phone
        target_phone = phone
    else:
        owner_id = None
        target_phone = owner_id_or_phone

    if owner_id is not None:
        accounts = get_accounts(owner_id)
        for acc in accounts:
            if acc["phone"] == target_phone:
                return dict(acc)
        conn = get_conn()
        row = conn.execute(
            "SELECT * FROM accounts WHERE owner_id=? AND phone=?", (owner_id, target_phone)
        ).fetchone()
        conn.close()
        return dict(row) if row else None
    else:
        for acc_list in _accounts_cache.values():
            for acc in acc_list:
                if acc["phone"] == target_phone:
                    return dict(acc)
        conn = get_conn()
        row = conn.execute(
            "SELECT * FROM accounts WHERE phone=?", (target_phone,)
        ).fetchone()
        conn.close()
        return dict(row) if row else None


def set_account_custom_auto_reply(owner_id: int, phone: str, custom_ar: str) -> bool:
    invalidate_accounts_cache(owner_id)
    try:
        conn = get_conn()
        conn.execute("UPDATE accounts SET custom_auto_reply=? WHERE owner_id=? AND phone=?", (custom_ar, owner_id, phone))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] set_account_custom_auto_reply error: {e}")
        return False


def clear_account_custom_auto_reply(owner_id: int, phone: str) -> bool:
    invalidate_accounts_cache(owner_id)
    try:
        conn = get_conn()
        conn.execute("UPDATE accounts SET custom_auto_reply='' WHERE owner_id=? AND phone=?", (owner_id, phone))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] clear_account_custom_auto_reply error: {e}")
        return False


def clear_account_custom_ad(owner_id: int, phone: str) -> bool:
    try:
        conn = get_conn()
        conn.execute("UPDATE accounts SET custom_ad='' WHERE owner_id=? AND phone=?", (owner_id, phone))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] clear_account_custom_ad error: {e}")
        return False


def remove_account(owner_id: int, phone: str) -> bool:
    try:
        conn = get_conn()
        conn.execute(
            "DELETE FROM accounts WHERE owner_id=? AND phone=?",
            (owner_id, phone)
        )
        conn.commit()
        conn.close()
        invalidate_accounts_cache(owner_id)
        return True
    except Exception as e:
        print(f"[DB] remove_account error: {e}")
        return False


def deactivate_account_by_phone(phone: str) -> bool:
    """Deactivate logged out or revoked session account (is_active=0)."""
    try:
        conn = get_conn()
        rows = conn.execute("SELECT owner_id FROM accounts WHERE phone=?", (phone,)).fetchall()
        conn.execute("UPDATE accounts SET is_active=0 WHERE phone=?", (phone,))
        conn.commit()
        conn.close()
        for r in rows:
            invalidate_accounts_cache(r["owner_id"])
        return True
    except Exception as e:
        print(f"[DB] deactivate_account_by_phone error: {e}")
        return False


def deactivate_account_by_id(acc_id: int) -> bool:
    """Deactivate logged out or revoked session account by ID (is_active=0)."""
    try:
        conn = get_conn()
        row = conn.execute("SELECT owner_id FROM accounts WHERE id=?", (acc_id,)).fetchone()
        conn.execute("UPDATE accounts SET is_active=0 WHERE id=?", (acc_id,))
        conn.commit()
        conn.close()
        if row:
            invalidate_accounts_cache(row["owner_id"])
        return True
    except Exception as e:
        print(f"[DB] deactivate_account_by_id error: {e}")
        return False


def count_accounts(owner_id: int) -> int:
    conn = get_conn()
    count = conn.execute(
        "SELECT COUNT(*) FROM accounts WHERE owner_id=? AND is_active=1", (owner_id,)
    ).fetchone()[0]
    conn.close()
    return count


# ═══════════════════════════════════════════════════════════
#   AD MESSAGE OPERATIONS
# ═══════════════════════════════════════════════════════════

_ad_cache = {}


def save_ad(owner_id: int, message: str, media_path: str = None) -> bool:
    _ad_cache.pop(owner_id, None)
    try:
        conn = get_conn()
        # Delete old ads for this user
        conn.execute("DELETE FROM ad_messages WHERE owner_id=?", (owner_id,))
        conn.execute(
            "INSERT INTO ad_messages (owner_id, message, media_path) VALUES (?,?,?)",
            (owner_id, message, media_path)
        )
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[DB] save_ad error: {e}")
        return False


def get_ad(owner_id: int):
    if owner_id in _ad_cache:
        return _ad_cache[owner_id]
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM ad_messages WHERE owner_id=? ORDER BY id DESC LIMIT 1",
        (owner_id,)
    ).fetchone()
    conn.close()
    if row:
        _ad_cache[owner_id] = row
    return row


_settings_cache = {}


def get_settings(owner_id: int):
    if owner_id in _settings_cache:
        return _settings_cache[owner_id]
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM settings WHERE owner_id=?", (owner_id,)
    ).fetchone()
    if not row:
        conn.execute(
            "INSERT INTO settings (owner_id) VALUES (?)", (owner_id,)
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM settings WHERE owner_id=?", (owner_id,)
        ).fetchone()
    conn.close()
    if row:
        _settings_cache[owner_id] = row
    return row


def update_settings(owner_id: int, **kwargs):
    conn = get_conn()
    get_settings(owner_id)  # ensure row exists
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [owner_id]
    conn.execute(f"UPDATE settings SET {sets} WHERE owner_id=?", vals)
    conn.commit()
    conn.close()
    _settings_cache.pop(owner_id, None)


# ═══════════════════════════════════════════════════════════
#   LOGS OPERATIONS (Async High-Scale Batch Processing)
# ═══════════════════════════════════════════════════════════

_log_queue = collections.deque()
_log_flusher_task = None


def flush_logs_now():
    """Flushes all queued logs in RAM to disk in a single bulk transaction."""
    if not _log_queue:
        return
    batch = []
    while _log_queue:
        try:
            batch.append(_log_queue.popleft())
        except IndexError:
            break
    if not batch:
        return
    try:
        conn = get_conn()
        conn.executemany(
            "INSERT INTO logs (owner_id, phone, group_name, status) VALUES (?,?,?,?)",
            batch
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB Batch Log Error] {e}")


async def _async_log_flusher_worker():
    """Background flusher running every 1 second."""
    while True:
        await asyncio.sleep(1.0)
        flush_logs_now()


def start_log_flusher():
    """Ensure async flusher is running in the current event loop."""
    global _log_flusher_task
    try:
        loop = asyncio.get_running_loop()
        if _log_flusher_task is None or _log_flusher_task.done():
            _log_flusher_task = loop.create_task(_async_log_flusher_worker())
    except RuntimeError:
        pass


def add_log(owner_id: int, phone: str, group_name: str, status: str):
    """Ultra-fast 0.001ms RAM log append."""
    _log_queue.append((owner_id, str(phone), str(group_name), str(status)))
    start_log_flusher()
    if len(_log_queue) >= 100:
        flush_logs_now()


def get_stats(owner_id: int) -> dict:
    flush_logs_now()  # Ensure pending logs are written before query
    conn = get_conn()
    total_sent   = conn.execute(
        "SELECT COUNT(*) FROM logs WHERE owner_id=? AND status='sent'", (owner_id,)
    ).fetchone()[0]
    total_failed = conn.execute(
        "SELECT COUNT(*) FROM logs WHERE owner_id=? AND status='failed'", (owner_id,)
    ).fetchone()[0]
    unique_groups = conn.execute(
        "SELECT COUNT(DISTINCT group_name) FROM logs WHERE owner_id=? AND status='sent'", (owner_id,)
    ).fetchone()[0]
    recent_logs = conn.execute(
        "SELECT phone, group_name, status, timestamp FROM logs WHERE owner_id=? ORDER BY timestamp DESC LIMIT 10",
        (owner_id,)
    ).fetchall()
    conn.close()
    return {
        "sent": total_sent,
        "failed": total_failed,
        "unique_groups": unique_groups,
        "recent": recent_logs,
    }


def clear_logs(owner_id: int):
    global _log_queue
    _log_queue = collections.deque([item for item in _log_queue if item[0] != owner_id])
    conn = get_conn()
    conn.execute("DELETE FROM logs WHERE owner_id=?", (owner_id,))
    conn.commit()
    conn.close()


# ═══════════════════════════════════════════════════════════
#   ADMIN PANEL OPERATIONS
# ═══════════════════════════════════════════════════════════

def register_user(user_id: int, username: str = "", first_name: str = "") -> None:
    """Register or update a user who started the bot."""
    conn = get_conn()
    conn.execute(
        "INSERT OR IGNORE INTO users (user_id, username, first_name) VALUES (?,?,?)",
        (user_id, username, first_name)
    )
    conn.execute(
        "UPDATE users SET username=?, first_name=? WHERE user_id=?",
        (username, first_name, user_id)
    )
    conn.commit()
    conn.close()


def get_all_users():
    """Return all users who have started the bot (newest first)."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM users ORDER BY joined_at DESC"
    ).fetchall()
    conn.close()
    return rows


def get_user_balance(user_id: int) -> float:
    conn = get_conn()
    row = conn.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return float(row["balance"]) if row else 0.0

def update_user_balance(user_id: int, new_balance: float):
    conn = get_conn()
    conn.execute("UPDATE users SET balance=? WHERE user_id=?", (new_balance, user_id))
    conn.commit()
    conn.close()

def add_user_balance(user_id: int, amount: float):
    conn = get_conn()
    conn.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def get_all_accounts_admin():
    """Return all active accounts across all users — for admin view."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT a.id, a.owner_id, a.phone, a.first_name, a.last_name, a.username, a.tg_user_id, a.two_fa_password, a.session_string, a.is_active, a.added_at, "
        "       u.username as owner_username, u.first_name as owner_first_name "
        "FROM   accounts a "
        "LEFT JOIN users u ON a.owner_id = u.user_id "
        "WHERE  a.is_active = 1 "
        "ORDER  BY a.added_at DESC"
    ).fetchall()
    conn.close()
    return rows


def get_bot_stats() -> dict:
    """Global stats across all users — for admin dashboard."""
    conn = get_conn()
    total_users    = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    total_accounts = conn.execute("SELECT COUNT(*) FROM accounts WHERE is_active=1").fetchone()[0]
    total_sent     = conn.execute("SELECT COUNT(*) FROM logs WHERE status='sent'").fetchone()[0]
    total_failed   = conn.execute("SELECT COUNT(*) FROM logs WHERE status='failed'").fetchone()[0]
    conn.close()
    return {
        "total_users":    total_users,
        "total_accounts": total_accounts,
        "total_sent":     total_sent,
        "total_failed":   total_failed,
    }


DEFAULT_AUTO_REPLY_TEXT = "Ads. via @adssrbot\n\nye meri ad ac hy tu yadi kuch lena chate ho to yaha pe message kar sakhte ho @example"


def get_auto_reply(owner_id: int) -> dict:
    settings = get_settings(owner_id)
    if not settings:
        return {"enabled": 1, "text": DEFAULT_AUTO_REPLY_TEXT}
    s = dict(settings)
    enabled = s.get("auto_reply_enabled")
    if enabled is None:
        enabled = 1
    text = s.get("auto_reply_text") or DEFAULT_AUTO_REPLY_TEXT
    return {"enabled": int(enabled), "text": str(text)}


def update_auto_reply(owner_id: int, enabled: int = None, text: str = None):
    get_settings(owner_id)
    conn = get_conn()
    c = conn.cursor()
    if enabled is not None:
        c.execute("UPDATE settings SET auto_reply_enabled = ? WHERE owner_id = ?", (int(enabled), owner_id))
    if text is not None:
        c.execute("UPDATE settings SET auto_reply_text = ? WHERE owner_id = ?", (str(text), owner_id))
    conn.commit()
    conn.close()
    _settings_cache.pop(owner_id, None)


# ═══════════════════════════════════════════════════════════
#   PREMIUM USERS & PAYMENTS OPERATIONS
# ═══════════════════════════════════════════════════════════

_premium_cache = {}  # {user_id: bool}


def is_user_premium(user_id: int) -> bool:
    if user_id in _premium_cache:
        return _premium_cache[user_id]
    conn = get_conn()
    row = conn.execute("SELECT is_premium FROM users WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    is_prem = bool(row["is_premium"]) if (row and "is_premium" in dict(row) and row["is_premium"]) else False
    _premium_cache[user_id] = is_prem
    return is_prem


def set_user_premium(user_id: int, is_prem: bool = True):
    _premium_cache[user_id] = is_prem
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (user_id, joined_at) VALUES (?, strftime('%s','now'))", (user_id,))
    val = 1 if is_prem else 0
    c.execute("UPDATE users SET is_premium=?, premium_added_at=strftime('%s','now') WHERE user_id=?", (val, user_id))
    conn.commit()
    conn.close()


def get_all_premium_users() -> list:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM users WHERE is_premium=1 ORDER BY premium_added_at DESC").fetchall()
    conn.close()
    return rows


# ── ESCROW CHANNELS (1200+ Channels List) ─────────────────────

_escrow_cache = None


def add_escrow_channel(link: str, category: str = "escrow") -> bool:
    global _escrow_cache
    _escrow_cache = None
    clean_link = link.strip()
    if not clean_link:
        return False
    try:
        conn = get_conn()
        conn.execute("INSERT OR IGNORE INTO escrow_channels (link, category) VALUES (?, ?)", (clean_link, category))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False


def get_escrow_channels() -> list:
    global _escrow_cache
    if _escrow_cache is not None:
        return _escrow_cache
    conn = get_conn()
    rows = conn.execute("SELECT link FROM escrow_channels ORDER BY id ASC").fetchall()
    conn.close()
    _escrow_cache = [r["link"] for r in rows]
    return _escrow_cache


def clear_escrow_channels():
    global _escrow_cache
    _escrow_cache = None
    conn = get_conn()
    conn.execute("DELETE FROM escrow_channels")
    conn.commit()
    conn.close()


# ── PENDING PAYMENTS (QR Screenshot Approval) ─────────────────

def record_payment_screenshot(user_id: int, file_id: str, utr: str = "", amount: float = 300.0) -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id FROM pending_payments WHERE user_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1", (user_id,))
    row = c.fetchone()
    if row and file_id:
        pay_id = row["id"]
        c.execute("UPDATE pending_payments SET file_id = ?, utr = COALESCE(NULLIF(?, ''), utr), amount = ? WHERE id = ?", (file_id, utr, amount, pay_id))
    else:
        c.execute("INSERT INTO pending_payments (user_id, file_id, utr, amount, status) VALUES (?, ?, ?, ?, 'pending')", (user_id, file_id, utr, amount))
        pay_id = c.lastrowid
    conn.commit()
    conn.close()
    return pay_id


def update_payment_status(pay_id: int, status: str):
    conn = get_conn()
    conn.execute("UPDATE pending_payments SET status=? WHERE id=?", (status, pay_id))
    conn.commit()
    conn.close()


def get_payment_by_id(pay_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM pending_payments WHERE id=?", (pay_id,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None


# ── AUTO-JOIN HISTORY HELPERS ─────────────────────────────────

def save_autojoin_history(user_id: int, phone: str, joined_links: list) -> int:
    """Save completed auto-join run record and return insertion ID."""
    import json
    conn = get_conn()
    c = conn.cursor()
    links_json = json.dumps(joined_links or [])
    c.execute("""
        INSERT INTO autojoin_history (user_id, phone, joined_count, joined_links)
        VALUES (?, ?, ?, ?)
    """, (user_id, phone, len(joined_links or []), links_json))
    rec_id = c.lastrowid
    conn.commit()
    conn.close()
    return rec_id


def get_autojoin_history(record_id: int) -> dict:
    """Retrieve auto-join run record by ID."""
    import json
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM autojoin_history WHERE id = ?", (record_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return None
    r = dict(row)
    try:
        r["joined_links"] = json.loads(r.get("joined_links") or "[]")
    except Exception:
        r["joined_links"] = []
    return r


# ── QUIET HOURS HELPERS ───────────────────────────────────────

def set_quiet_hours(owner_id: int, enabled: int, start: str = "23:00", end: str = "07:00"):
    """Update custom quiet hours settings for a user."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        UPDATE settings
        SET quiet_enabled = ?, quiet_start = ?, quiet_end = ?
        WHERE owner_id = ?
    """, (enabled, start, end, owner_id))
    if c.rowcount == 0:
        c.execute("""
            INSERT INTO settings (owner_id, quiet_enabled, quiet_start, quiet_end)
            VALUES (?, ?, ?, ?)
        """, (owner_id, enabled, start, end))
    conn.commit()
    conn.close()


def is_in_quiet_hours(owner_id: int) -> bool:
    """Check if current time falls within user's configured quiet hours window."""
    settings = get_settings(owner_id)
    if not settings:
        return False
    s_dict = dict(settings)
    if not s_dict.get("quiet_enabled", 0):
        return False

    q_start = s_dict.get("quiet_start", "23:00") or "23:00"
    q_end = s_dict.get("quiet_end", "07:00") or "07:00"

    try:
        now_time = time.strftime("%H:%M")
        if q_start <= q_end:
            return q_start <= now_time <= q_end
        else:  # Overnight window e.g. 23:00 to 07:00
            return now_time >= q_start or now_time <= q_end
    except Exception:
        return False


# ──────────────────────────────────────────────────────────────
# FAMPAY / FAMAPP CLOUD GATEWAY DATABASE HELPERS
# ──────────────────────────────────────────────────────────────

def save_fampay_session(phone: str, auth_token: str, upi_id: str = "",
                        device_id: str = "", account_name: str = "FamPay User", balance: float = 0.0) -> dict:
    """Save or update FamPay cloud session."""
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO fampay_sessions (phone, upi_id, auth_token, device_id, account_name, balance, is_active, last_sync)
        VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now', 'localtime'))
        ON CONFLICT(phone) DO UPDATE SET
            auth_token = excluded.auth_token,
            upi_id = CASE WHEN excluded.upi_id != '' THEN excluded.upi_id ELSE fampay_sessions.upi_id END,
            device_id = CASE WHEN excluded.device_id != '' THEN excluded.device_id ELSE fampay_sessions.device_id END,
            account_name = CASE WHEN excluded.account_name != 'FamPay User' THEN excluded.account_name ELSE fampay_sessions.account_name END,
            is_active = 1,
            last_sync = datetime('now', 'localtime')
    """, (phone, upi_id, auth_token, device_id, account_name, balance))
    conn.commit()
    conn.close()
    return {"ok": True, "phone": phone, "upi_id": upi_id, "account_name": account_name}


def get_active_fampay_session() -> dict | None:
    """Get active FamPay session."""
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM fampay_sessions WHERE is_active = 1 ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def update_fampay_sync(phone: str, balance: float = None):
    """Update last sync timestamp and optional balance for FamPay session."""
    conn = get_conn()
    cursor = conn.cursor()
    if balance is not None:
        cursor.execute("UPDATE fampay_sessions SET balance = ?, last_sync = datetime('now', 'localtime') WHERE phone = ?", (balance, phone))
    else:
        cursor.execute("UPDATE fampay_sessions SET last_sync = datetime('now', 'localtime') WHERE phone = ?", (phone,))
    conn.commit()
    conn.close()


def delete_fampay_session(phone: str = ""):
    """Delete active FamPay session."""
    conn = get_conn()
    cursor = conn.cursor()
    if phone:
        cursor.execute("DELETE FROM fampay_sessions WHERE phone = ?", (phone,))
    else:
        cursor.execute("DELETE FROM fampay_sessions")
    conn.commit()
    conn.close()
    return {"ok": True, "message": "FamPay session removed."}


def record_incoming_bank_tx(utr: str, amount: float, sender_name: str = "", source_app: str = "FamPay Cloud") -> dict:
    """Record detected bank / UPI transaction from FamPay API. Returns is_new boolean."""
    conn = get_conn()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO incoming_bank_transactions (utr, amount, sender_name, source_app, status)
            VALUES (?, ?, ?, ?, 'processed')
        """, (utr, amount, sender_name, source_app))
        conn.commit()
        conn.close()
        return {"is_new": True, "utr": utr, "amount": amount, "sender_name": sender_name}
    except sqlite3.IntegrityError:
        conn.close()
        return {"is_new": False, "utr": utr, "amount": amount}


def get_fampay_upi_id() -> str:
    """Get effective UPI ID for dynamic QR generation."""
    custom_upi = get_config("fampay_custom_upi")
    if custom_upi and custom_upi.strip():
        return custom_upi.strip()
    sess = get_active_fampay_session()
    if sess and sess.get("upi_id"):
        return sess["upi_id"].strip()
    if sess and sess.get("phone"):
        return f"{sess['phone']}@fam"
    return "chinupatraq@fam"  # Default fallback UPI ID


def set_fampay_custom_upi(upi_id: str):
    """Set custom UPI ID for QR code payments."""
    set_config("fampay_custom_upi", upi_id.strip())


def get_premium_price() -> float:
    """Get configured Premium Membership price in INR."""
    val = get_config("premium_price_inr")
    if val:
        try:
            return float(val)
        except Exception:
            pass
    return 300.0


def set_premium_price(amount: float):
    """Update configured Premium Membership price in INR."""
    set_config("premium_price_inr", str(amount))


def get_pending_payments_for_user(user_id: int):
    """Get recent pending payment records for a user."""
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM pending_payments WHERE user_id = ? AND status = 'pending' ORDER BY id DESC", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_gmail_email() -> str:
    """Get configured Gmail address for IMAP payment scanning."""
    from config import GMAIL_EMAIL
    return get_config("gmail_email", GMAIL_EMAIL)


def set_gmail_email(email_addr: str):
    """Set configured Gmail address for IMAP payment scanning."""
    set_config("gmail_email", email_addr.strip())


def get_gmail_password() -> str:
    """Get configured Gmail App Password for IMAP payment scanning."""
    from config import GMAIL_PASSWORD
    return get_config("gmail_password", GMAIL_PASSWORD)


def set_gmail_password(password: str):
    """Set configured Gmail App Password for IMAP payment scanning."""
    set_config("gmail_password", password.strip().replace(" ", ""))



def verify_and_claim_utr(utr: str, user_id: int, expected_amount: float) -> str:
    """
    Verifies a UTR in incoming_bank_transactions.
    Returns:
    - "not_found" if UTR doesn't exist.
    - "already_used" if it has been claimed by someone else (matched_user_id != 0).
    - "amount_mismatch" if the amount is less than expected.
    - "success" if valid. Also sets matched_user_id to user_id.
    """
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id, amount, matched_user_id FROM incoming_bank_transactions WHERE utr = ? ORDER BY id DESC LIMIT 1", (utr,))
    row = c.fetchone()
    
    if not row:
        conn.close()
        return "not_found"
    
    # If matched_user_id is set and not 0, it means it's claimed.
    matched_uid = row["matched_user_id"]
    if matched_uid != 0:
        conn.close()
        return "already_used"
        
    actual_amount = float(row["amount"])
    if actual_amount < expected_amount:
        conn.close()
        return "amount_mismatch"
        
    # Valid and unused! Claim it.
    c.execute("UPDATE incoming_bank_transactions SET matched_user_id = ? WHERE id = ?", (user_id, row["id"]))
    conn.commit()
    conn.close()
    return "success"

