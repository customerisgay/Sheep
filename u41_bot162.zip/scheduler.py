"""
scheduler.py — Interval & Cycle Scheduler for AdBot
Manages per-user broadcast jobs using APScheduler
"""

import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
import database as db
from config import INTERVALS
import broadcaster

from emojis import e

scheduler = AsyncIOScheduler()
user_cycle_count = {}   # {owner_id: cycles_done}
active_tasks     = {}   # {owner_id: asyncio.Task}
status_msg_ids   = {}   # {owner_id: message_id}


def start_scheduler():
    if not scheduler.running:
        scheduler.start()
        print("✅ Scheduler started.")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)


async def update_live_tracker(owner_id: int, current_cycle: int, max_cycles: int, status_label: str, bot, chat_id: int, acc_stats: dict = None):
    """Helper to update a SINGLE live status message per user using luxury custom emojis."""
    stats = db.get_stats(owner_id)
    cycle_str = f"Unlimited {e('infinty1')}" if max_cycles == 0 else str(max_cycles)
    header  = f"{e('deco_fly_l')} <b>LIVE BROADCAST TRACKER</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    acc_section = ""
    if acc_stats:
        acc_lines = [f"\n{e('android')} <b>Per-Account Live Progress:</b>"]
        for ph, st in acc_stats.items():
            acc_lines.append(f"• <code>{ph}</code> → {e('check')} {st['sent']} Sent | {e('cross')} {st['failed']} Failed")
        acc_section = "\n".join(acc_lines) + "\n"

    text = (
        f"{header}\n{divider}\n\n"
        f"{e('chart')} <b>Active Cycle:</b> <code>#{current_cycle}</code> / <code>{cycle_str}</code>\n"
        f"{e('fire')} <b>Status:</b> {status_label}\n\n"
        f"{e('check')} <b>Total Ads Sent:</b> <code>{stats['sent']}</code>\n"
        f"{e('cross')} <b>Total Failed:</b> <code>{stats['failed']}</code>\n"
        f"{e('globe')} <b>Unique Targets Reached:</b> <code>{stats['unique_groups']}</code>\n"
        f"{acc_section}"
        f"{divider}\n"
        f"<i>⚡ Live Tracker — Real-time live status update...</i>"
    )

    msg_id = status_msg_ids.get(owner_id)
    if msg_id:
        try:
            await bot.edit_message_text(text, chat_id=chat_id, message_id=msg_id, parse_mode="HTML")
            return
        except Exception:
            pass  # If message was deleted or editing failed, send new one

    try:
        msg = await bot.send_message(chat_id, text, parse_mode="HTML")
        status_msg_ids[owner_id] = msg.message_id
    except Exception as err:
        print(f"[Tracker] Send error for user {owner_id}: {err}")


async def _broadcast_job(owner_id: int, max_cycles: int, bot, chat_id: int, selected_phone: str = "all"):
    """Internal job called by scheduler on each interval tick."""
    # Check if broadcast was stopped by user in DB
    settings = db.get_settings(owner_id)
    if not settings or dict(settings).get("is_running", 0) == 0:
        stop_user_job(owner_id)
        return

    current_task = asyncio.current_task()
    if current_task:
        active_tasks[owner_id] = current_task

    cycle_key = f"user_{owner_id}"

    # Track cycles
    if cycle_key not in user_cycle_count:
        user_cycle_count[cycle_key] = 0

    user_cycle_count[cycle_key] += 1
    current_cycle = user_cycle_count[cycle_key]

    # Check if we exceeded cycle limit
    if max_cycles > 0 and current_cycle > max_cycles:
        await update_live_tracker(owner_id, max_cycles, max_cycles, f"<b>Broadcast Completed {e('check')}</b>", bot, chat_id)
        stop_user_job(owner_id)
        return

    try:
        # Update live status: Running
        await update_live_tracker(owner_id, current_cycle, max_cycles, f"<b>Cycle #{current_cycle} Running... {e('hourglass')}</b>", bot, chat_id)

        # Run broadcast
        result = await broadcaster.broadcast_once(owner_id, selected_phone)
        db.update_settings(owner_id, cycle_done=current_cycle)

        acc_stats = result.get("acc_stats", {})

        if "error" in result:
            await update_live_tracker(owner_id, current_cycle, max_cycles, f"<b>Error: {result['error']} {e('cross')}</b>", bot, chat_id, acc_stats=acc_stats)
            stop_user_job(owner_id)
            return

        if result.get("stopped"):
            await update_live_tracker(owner_id, current_cycle, max_cycles, f"<b>Broadcast Stopped {e('cross')}</b>", bot, chat_id, acc_stats=acc_stats)
            stop_user_job(owner_id)
            return

        # Update live status: Cycle Completed
        await update_live_tracker(owner_id, current_cycle, max_cycles, f"<b>Cycle #{current_cycle} Completed {e('check')}</b>", bot, chat_id, acc_stats=acc_stats)

    except asyncio.CancelledError:
        print(f"[Scheduler] Task cancelled for user {owner_id}")
        await update_live_tracker(owner_id, current_cycle, max_cycles, f"<b>Broadcast Stopped {e('cross')}</b>", bot, chat_id)
        raise
    finally:
        active_tasks.pop(owner_id, None)


async def run_first_round(owner_id: int, max_cycles: int, bot, chat_id: int, selected_phone: str = "all"):
    """Run Round 1 immediately as a tracked task."""
    task = asyncio.create_task(_broadcast_job(owner_id, max_cycles, bot, chat_id, selected_phone))
    active_tasks[owner_id] = task
    try:
        await task
    except asyncio.CancelledError:
        print(f"[Scheduler] First round cancelled for user {owner_id}")


def start_user_job(owner_id: int, interval_key: str, max_cycles: int, bot, chat_id: int, selected_phone: str = "all"):
    """Start a broadcast job for the user."""
    job_id = f"broadcast_{owner_id}"

    # Remove existing job if any
    stop_user_job(owner_id)

    # Reset cycle counter
    user_cycle_count[f"user_{owner_id}"] = 0

    seconds = INTERVALS.get(interval_key, 300)

    db.update_settings(owner_id, is_running=1)

    scheduler.add_job(
        _broadcast_job,
        trigger=IntervalTrigger(seconds=seconds),
        args=[owner_id, max_cycles, bot, chat_id, selected_phone],
        id=job_id,
        replace_existing=True,
        max_instances=1
    )

    print(f"[Scheduler] Job scheduled for user {owner_id} | Interval: {interval_key} | Cycles: {max_cycles or '∞'} | Acc: {selected_phone}")


def stop_user_job(owner_id: int):
    """Stop the broadcast job for the user immediately."""
    job_id = f"broadcast_{owner_id}"
    db.update_settings(owner_id, is_running=0)

    if scheduler.get_job(job_id):
        try:
            scheduler.remove_job(job_id)
        except Exception:
            pass

    task = active_tasks.pop(owner_id, None)
    if task and not task.done():
        task.cancel()

    print(f"[Scheduler] Job stopped for user {owner_id}")


def is_user_running(owner_id: int) -> bool:
    job_id = f"broadcast_{owner_id}"
    settings = db.get_settings(owner_id)
    db_running = (dict(settings).get("is_running", 0) == 1) if settings else False
    has_job  = (scheduler.get_job(job_id) is not None)
    has_task = (owner_id in active_tasks and not active_tasks[owner_id].done())
    return db_running or has_job or has_task
