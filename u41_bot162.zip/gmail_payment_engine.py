"""
gmail_payment_engine.py — Gmail IMAP Auto-Verification Engine for FamPay & Bank Alerts
======================================================================================
Connects 24/7 via IMAP SSL to Gmail (e.g. chinupatraq@gmail.com).
Scans incoming payment alerts from FamApp / FamPay (@famapp.in / @fampay.in / Banks).
Extracts:
  - 💵 Amount (₹ / Rs. / INR)
  - 🆔 12-Digit UTR / Transaction Reference Number
  - 👤 Sender Name / Counterparty
  - 🏷️ Order Reference Note (e.g. Prem_8949860238)

Instant Action:
  - Records into incoming_bank_transactions table
  - Auto-approves matching pending Premium payment in Telegram Bot
  - Unlocks Lifetime VIP Premium in 1 second and notifies user + admin on Telegram!
"""

import asyncio
import email
from email.header import decode_header
import imaplib
import logging
import re
from datetime import datetime
import httpx

from config import BOT_TOKEN, ADMIN_IDS
from emojis import e, _E
import database as db

logger = logging.getLogger("GMAIL_IMAP")
logger.setLevel(logging.INFO)

# In-memory cache of already processed email message IDs to prevent redundant parsing
_processed_email_ids: set[str] = set()
_last_gmail_sync_time: datetime | None = None
_gmail_connection_status: dict = {"ok": True, "message": "Connected & Active"}


def get_gmail_status() -> dict:
    """Returns current Gmail IMAP connection health and last sync timestamp."""
    email_addr = db.get_gmail_email()
    return {
        "ok": _gmail_connection_status.get("ok", True),
        "email": email_addr,
        "message": _gmail_connection_status.get("message", "Connected & Active"),
        "last_sync": _last_gmail_sync_time.strftime("%Y-%m-%d %H:%M:%S") if _last_gmail_sync_time else datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "processed_count": len(_processed_email_ids)
    }


def test_gmail_connection() -> dict:
    """Tests Gmail IMAP SSL connection synchronously."""
    email_addr = db.get_gmail_email()
    email_pass = db.get_gmail_password()

    if not email_addr or not email_pass:
        return {"ok": False, "message": "Gmail email or app password not configured."}

    clean_pass = email_pass.replace(" ", "")
    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)
        mail.login(email_addr, clean_pass)
        status, _ = mail.select("inbox")
        mail.close()
        mail.logout()
        if status == "OK":
            return {"ok": True, "message": f"Successfully connected to {email_addr}!"}
        return {"ok": False, "message": f"IMAP status returned: {status}"}
    except Exception as exc:
        return {"ok": False, "message": str(exc)}


def parse_email_body(msg) -> str:
    """Extract plain text or html content from email message."""
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            cdispo = str(part.get('Content-Disposition') or '')
            if ctype in ("text/plain", "text/html") and "attachment" not in cdispo:
                try:
                    payload = part.get_payload(decode=True)
                    if payload:
                        body += " " + payload.decode(errors="ignore")
                except Exception:
                    pass
    else:
        try:
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode(errors="ignore")
        except Exception:
            pass
    return body


def extract_payment_details_from_text(subject: str, body: str, from_addr: str) -> dict | None:
    """
    Parses amount, UTR, sender, and order reference from FamPay/Bank email text.
    """
    full_text = f"{subject} {body}"
    clean_text = re.sub(r'<[^>]+>', ' ', full_text)  # strip HTML tags
    clean_text = re.sub(r'\s+', ' ', clean_text)

    # 1. Amount Extraction (e.g. ₹300, Rs. 300, INR 300.00, credited by Rs 300, Received ₹300)
    amount = 0.0
    amt_patterns = [
        r'(?:Rs\.?|INR|₹)\s*([\d,]+(?:\.\d{1,2})?)',
        r'credited\s+(?:by|with|for)?\s*(?:Rs\.?|INR|₹)?\s*([\d,]+(?:\.\d{1,2})?)',
        r'received\s+(?:Rs\.?|INR|₹)?\s*([\d,]+(?:\.\d{1,2})?)',
        r'paid\s+you\s+(?:Rs\.?|INR|₹)?\s*([\d,]+(?:\.\d{1,2})?)',
        r'added\s+(?:Rs\.?|INR|₹)?\s*([\d,]+(?:\.\d{1,2})?)',
    ]
    for p in amt_patterns:
        m = re.search(p, clean_text, re.IGNORECASE)
        if m:
            try:
                val = float(m.group(1).replace(",", ""))
                if val > 0:
                    amount = val
                    break
            except Exception:
                pass

    if amount <= 0:
        return None

    # 2. UTR / Ref No Extraction (10-18 digits strictly required)
    utr = ""
    utr_patterns = [
        r'(?:UTR|Ref(?:\s*No)?|RRN|Txn(?:\s*ID)?|UPI\s*Ref(?:\s*No)?)\s*[:#-]?\s*([0-9]{10,18})',
        r'UPI\s*/\s*([0-9]{10,18})',
        r'\b([0-9]{12})\b',  # Standard 12-digit UPI UTR
        r'Transaction\s*ID\s*[:#-]?\s*([0-9]{10,18})'
    ]
    for p in utr_patterns:
        m = re.search(p, clean_text, re.IGNORECASE)
        if m:
            utr = m.group(1).strip()
            break

    # If NO valid UTR found, this is a normal email
    if not utr:
        return None

    # 3. Sender Name
    sender = "FamPay / UPI Payer"
    sender_patterns = [
        r'from\s+([A-Za-z0-9\s]{3,30})\b',
        r'by\s+UPI\s+user\s+([A-Za-z0-9\s]{3,30})\b',
        r'received\s+from\s+([A-Za-z0-9\s]{3,30})\b',
        r'paid\s+by\s+([A-Za-z0-9\s]{3,30})\b'
    ]
    for p in sender_patterns:
        m = re.search(p, clean_text, re.IGNORECASE)
        if m:
            s_name = m.group(1).strip()
            if not s_name.lower().startswith("famapp") and not s_name.lower().startswith("google"):
                sender = s_name
                break

    # 4. Order Reference / Purpose (e.g. Prem_8949860238)
    note = ""
    note_m = re.search(r'(PREM_[0-9]+|VIP_[0-9]+|TOPUP_[0-9]+)', clean_text, re.IGNORECASE)
    if note_m:
        note = note_m.group(1)

    return {
        "amount": amount,
        "utr": utr,
        "sender": sender,
        "note": note,
        "from": from_addr,
        "subject": subject
    }


def scan_gmail_inbox_sync() -> list[dict]:
    """
    Synchronous IMAP scan of Gmail inbox for new FamPay & Bank payment alert emails.
    """
    global _last_gmail_sync_time, _gmail_connection_status

    email_addr = db.get_gmail_email()
    email_pass = db.get_gmail_password()

    if not email_addr or not email_pass:
        _gmail_connection_status = {"ok": False, "message": "Gmail credentials not configured."}
        return []

    clean_pass = email_pass.replace(" ", "")
    found_txs = []

    try:
        mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)
        mail.login(email_addr, clean_pass)
        status, _ = mail.select("inbox")
        if status != "OK":
            mail.logout()
            _gmail_connection_status = {"ok": False, "message": "Could not select Inbox folder."}
            return []

        _gmail_connection_status = {"ok": True, "message": "Connected & Active"}
        _last_gmail_sync_time = datetime.now()

        # Search recent 30 emails in inbox
        status, messages = mail.search(None, "ALL")
        if status == "OK" and messages[0]:
            msg_ids = messages[0].split()[-30:]

            for e_id in reversed(msg_ids):
                e_id_str = e_id.decode() if isinstance(e_id, bytes) else str(e_id)
                if e_id_str in _processed_email_ids:
                    continue

                status, data = mail.fetch(e_id, "(RFC822)")
                if status != "OK" or not data or not data[0]:
                    continue

                raw_email = data[0][1]
                msg = email.message_from_bytes(raw_email)

                # Decode Subject
                raw_subj = msg.get("Subject", "")
                subject = ""
                try:
                    dec_list = decode_header(raw_subj)
                    for item, enc in dec_list:
                        if isinstance(item, bytes):
                            subject += item.decode(enc or "utf-8", errors="ignore")
                        else:
                            subject += str(item)
                except Exception:
                    subject = str(raw_subj)

                from_addr = str(msg.get("From", ""))
                body = parse_email_body(msg)

                # Filter payment-related emails only
                f_low = from_addr.lower()
                s_low = subject.lower()
                is_payment_alert = (
                    "famapp" in f_low or "fampay" in f_low or "famapp" in s_low or "fampay" in s_low or
                    "alerts@" in f_low or "notify@" in f_low or "bank" in f_low or "upi" in f_low or
                    "credited" in s_low or "payment received" in s_low or "money received" in s_low or
                    "received rs" in s_low or "received inr" in s_low or "received ₹" in s_low
                )

                if is_payment_alert:
                    parsed = extract_payment_details_from_text(subject, body, from_addr)
                    if parsed and parsed.get("utr"):
                        parsed["email_id"] = e_id_str
                        found_txs.append(parsed)

                _processed_email_ids.add(e_id_str)

        mail.close()
        mail.logout()
        return found_txs

    except Exception as exc:
        logger.error(f"Gmail IMAP scanning error: {exc}")
        _gmail_connection_status = {"ok": False, "message": f"Error: {exc}"}
        return []


async def check_and_auto_unlock_premium(utr: str, amount: float, sender_name: str = "", note: str = "") -> dict:
    """
    Checks if a Telegram user has a pending Premium order for this payment and automatically unlocks it.
    """
    conn = db.get_conn()
    c = conn.cursor()

    target_user_id = None
    target_pay_id = None

    # 1. Check if note has 'Prem_<user_id>'
    if note:
        parts = note.split("_")
        if len(parts) >= 2 and parts[1].isdigit():
            target_user_id = int(parts[1])

    # 2. Check pending_payments table for matching UTR or user
    if target_user_id:
        c.execute("SELECT id, user_id FROM pending_payments WHERE user_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1", (target_user_id,))
        row = c.fetchone()
        if row:
            target_pay_id = row["id"]
    else:
        # Check by UTR directly, or if utr is empty in db but amount matches (fallback for no note)
        expected_price = db.get_premium_price()
        c.execute(
            "SELECT id, user_id FROM pending_payments WHERE (utr = ? OR file_id = ? OR (utr = '' AND amount = ?)) AND status = 'pending' ORDER BY id DESC LIMIT 1", 
            (utr, f"UTR_{utr}", expected_price)
        )
        row = c.fetchone()
        if row:
            target_pay_id = row["id"]
            target_user_id = row["user_id"]


    conn.close()

    if target_user_id:
        # Approve payment and grant lifetime premium
        if target_pay_id:
            db.update_payment_status(target_pay_id, "approved")
        db.set_user_premium(target_user_id, True)

        # Notify user instantly on Telegram
        try:
            user_msg = (
                f"{e('deco_fly_l')} 🎉 <b>PREMIUM MEMBERSHIP UNLOCKED!</b> {e('fire')}{e('deco_fly_r')}\n\n"
                f"✅ <b>Gmail IMAP Payment Verified!</b>\n"
                f"💰 <b>Amount Received:</b> <b>₹{amount:.2f} INR</b>\n"
                f"🆔 <b>UTR Reference:</b> <code>{utr}</code>\n"
                f"👤 <b>Sender:</b> {sender_name or 'UPI User'}\n"
                f"👑 <b>Status:</b> <b>Active (Lifetime VIP)</b> {e('crown')}\n\n"
                f"✨ <i>Aapka Premium Membership successfully activate ho gaya hai! Ab aap 1200+ Escrow channels aur unlimited auto-reply features use kar sakte hain.</i>"
            )
            user_kb = {
                "inline_keyboard": [
                    [{"text": "⚡ Open Premium Menu", "callback_data": "btn_premium", "icon_custom_emoji_id": _E["crown"], "style": "success"}],
                    [{"text": "🏠 Main Menu", "callback_data": "btn_home", "icon_custom_emoji_id": _E["globe"]}]
                ]
            }
            send_url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
            async with httpx.AsyncClient(timeout=10.0) as client:
                await client.post(send_url, json={"chat_id": target_user_id, "text": user_msg, "parse_mode": "HTML", "reply_markup": user_kb})
            logger.info(f"✅ User {target_user_id} automatically unlocked Lifetime Premium via Gmail IMAP Alert!")
        except Exception as err:
            logger.warning(f"Could not notify user {target_user_id}: {err}")

        # Notify Admins on Telegram
        for adm in ADMIN_IDS:
            try:
                admin_msg = (
                    f"⚡ <b>[Gmail IMAP] Instant Auto-Approval!</b>\n\n"
                    f"👑 <b>User:</b> <code>{target_user_id}</code>\n"
                    f"💰 <b>Amount:</b> <b>₹{amount:.2f} INR</b>\n"
                    f"🆔 <b>UTR:</b> <code>{utr}</code>\n"
                    f"👤 <b>Sender:</b> {sender_name or 'Unknown'}\n"
                    f"🏷️ <b>Note:</b> <code>{note or 'N/A'}</code>\n"
                    f"⭐ <b>Status:</b> <b>Premium Granted Automatically</b> ✅"
                )
                async with httpx.AsyncClient(timeout=10.0) as client:
                    await client.post(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", json={"chat_id": adm, "text": admin_msg, "parse_mode": "HTML"})
            except Exception:
                pass

        return {"ok": True, "unlocked_user": target_user_id}

    return {"ok": False, "message": "No matching pending user found"}


async def scan_and_auto_credit_gmail() -> int:
    """
    Scans Gmail asynchronously in thread pool, records transactions, and auto-unlocks Premium.
    """
    new_txs = await asyncio.to_thread(scan_gmail_inbox_sync)
    new_credits = 0

    for tx in new_txs:
        utr = tx["utr"]
        amt = tx["amount"]
        sender = tx["sender"]
        note = tx.get("note", "")

        # Record incoming bank transaction into adbot.db
        rec = db.record_incoming_bank_tx(
            utr=utr,
            amount=amt,
            sender_name=sender,
            source_app="FamPay Gmail IMAP Alert"
        )

        if rec.get("is_new"):
            new_credits += 1
            logger.info(f"⚡ [GMAIL IMAP] New Payment Alert: ₹{amt:.2f} | UTR: {utr} | Sender: {sender} | Note: {note}")
            await check_and_auto_unlock_premium(utr=utr, amount=amt, sender_name=sender, note=note)

    return new_credits


async def gmail_auto_syncer_loop():
    """
    24/7 Background Continuous Polling Loop for Gmail FamPay & Bank Alerts (every 6 seconds).
    """
    logger.info("🚀 Gmail IMAP Auto-Verification background syncer started!")
    while True:
        try:
            await scan_and_auto_credit_gmail()
        except Exception as exc:
            logger.error(f"Error in gmail_auto_syncer_loop: {exc}")
        await asyncio.sleep(6)
