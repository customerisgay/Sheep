"""
handlers/dashboard_handler.py — Analytics Dashboard
Shows real-time stats, recent logs, and bot status
"""

import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import database as db
import scheduler as sched


def format_time(ts):
    if not ts:
        return "N/A"
    return time.strftime("%d %b %Y %H:%M:%S", time.localtime(ts))


async def dashboard_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Show the analytics dashboard."""
    uid      = update.effective_user.id
    stats    = db.get_stats(uid)
    settings = db.get_settings(uid)
    accounts = db.get_accounts(uid)
    ad       = db.get_ad(uid)
    running  = sched.is_user_running(uid)

    cycle_str   = "♾️ Unlimited" if settings["cycles"] == 0 else str(settings["cycles"])
    status_icon = "🟢 Running" if running else "🔴 Stopped"
    ad_preview  = (ad["message"][:50] + "...") if ad else "❌ Not set"

    text = (
        f"📊 *AdBot Dashboard*\n"
        f"{'━' * 28}\n\n"
        f"🤖 *Status:* {status_icon}\n"
        f"📱 *Accounts:* {len(accounts)}\n"
        f"⏱ *Interval:* {settings['interval']}\n"
        f"🔄 *Cycles:* {cycle_str} (done: {settings['cycle_done']})\n\n"
        f"📢 *Ad Preview:*\n`{ad_preview}`\n\n"
        f"{'━' * 28}\n"
        f"📈 *Delivery Stats:*\n"
        f"✅ Sent:         {stats['sent']}\n"
        f"❌ Failed:       {stats['failed']}\n"
        f"📣 Unique Groups: {stats['unique_groups']}\n"
        f"{'━' * 28}"
    )

    buttons = [
        [
            InlineKeyboardButton("📋 Recent Logs", callback_data="dash_logs"),
            InlineKeyboardButton("🗑 Clear Logs",  callback_data="dash_clearlogs"),
        ],
        [
            InlineKeyboardButton("🔄 Refresh", callback_data="dash_refresh"),
        ]
    ]

    await update.message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def dashboard_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Handle dashboard button actions."""
    query = update.callback_query
    uid   = query.from_user.id
    await query.answer()

    if query.data == "dash_logs":
        stats = db.get_stats(uid)
        if not stats["recent"]:
            await query.message.reply_text("📭 No logs yet.")
            return

        lines = ["📋 *Recent Delivery Logs:*\n"]
        for log in stats["recent"]:
            icon = "✅" if log["status"] == "sent" else "❌"
            ts   = format_time(log["timestamp"])
            lines.append(f"{icon} `{log['phone']}` → {log['group_name']}\n   🕐 {ts}")

        await query.message.reply_text("\n".join(lines), parse_mode="Markdown")

    elif query.data == "dash_clearlogs":
        db.clear_logs(uid)
        await query.edit_message_text("🗑 Logs cleared successfully!")

    elif query.data == "dash_refresh":
        # Re-run dashboard
        stats    = db.get_stats(uid)
        settings = db.get_settings(uid)
        accounts = db.get_accounts(uid)
        ad       = db.get_ad(uid)
        running  = sched.is_user_running(uid)

        cycle_str   = "♾️ Unlimited" if settings["cycles"] == 0 else str(settings["cycles"])
        status_icon = "🟢 Running" if running else "🔴 Stopped"
        ad_preview  = (ad["message"][:50] + "...") if ad else "❌ Not set"

        text = (
            f"📊 *AdBot Dashboard* (Refreshed)\n"
            f"{'━' * 28}\n\n"
            f"🤖 *Status:* {status_icon}\n"
            f"📱 *Accounts:* {len(accounts)}\n"
            f"⏱ *Interval:* {settings['interval']}\n"
            f"🔄 *Cycles:* {cycle_str} (done: {settings['cycle_done']})\n\n"
            f"📢 *Ad Preview:*\n`{ad_preview}`\n\n"
            f"{'━' * 28}\n"
            f"📈 *Delivery Stats:*\n"
            f"✅ Sent:         {stats['sent']}\n"
            f"❌ Failed:       {stats['failed']}\n"
            f"📣 Unique Groups: {stats['unique_groups']}\n"
            f"{'━' * 28}"
        )

        buttons = [
            [
                InlineKeyboardButton("📋 Recent Logs", callback_data="dash_logs"),
                InlineKeyboardButton("🗑 Clear Logs",  callback_data="dash_clearlogs"),
            ],
            [
                InlineKeyboardButton("🔄 Refresh", callback_data="dash_refresh"),
            ]
        ]

        await query.edit_message_text(
            text,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
