import telebot
import sqlite3
import qrcode
import random
import datetime
import os
import io
import json
import string
import logging
import traceback
import re
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv('BOT_TOKEN')
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN environment variable not set!")

ADMIN_IDS = [8207882848, 8255647546, 7566919489]
ADMIN_ID = ADMIN_IDS[0]
GROUP_ID = -1003783363388
UPI_ID = "vivek57827@ybl"
BINANCE_ID = "955505224"
HOW_TO_USE_VIDEO_LINK = "https://youtu.be/6osi85I2Y6U?si=YfolGjwVgYuCyUEt"
BOT_USERNAME = "Siyapanelbot"
SUPPORT_USERNAME = "sii_3s"
UPDATE_CHANNEL_LINK = "https://t.me/Sriyapanels"

user_temp_data = {}

START_EMOJIS = {
    "store_icon": "5312361253610475399",
    "unlock": "5393302369024882368",
    "arrow": "5803244322979585969",
    "buy": "6021352786724133912",
    "check": "5406745015365943482",
    "add": "5990147899403539264",
    "profile": "5828049232287767432",
    "refer": "5798436339019947373",
    "how": "5314504236132747481",
    "support": "5956045399511797140",
    "gift": "5785281906459283269",
    "balance": "5417924076503062111",
    "select": "5470177992950946662",
}

PREMIUM_EMOJIS = {
    "store_icon": "5319201848022808495",
    "buy_now": "6091170843080007327",
    "check_update": "6215156189454409086",
    "add_balance": "6089118454302909415",
    "my_profile": "6091248818211265593",
    "refer_earn": "6215494177610802481",
    "how_to_use": "6334523775970712629",
    "support": "5956045399511797140",
    "daily_gift": "5785281906459283269",
    "deposit_success": "6091430271989587379",
    "plan_icon": "5312361253610475399",
    "price_icon": "6021352786724133912",
    "back_button": "5809840662601802452",
    "wallet": "6118203281341685007",
    "upi": "5433601609076586221",
    "binance": "6129732880529628243",
    "verify": "6129652186684070216",
    "accept": "6267118537752450044",
    "reject": "5377843592020649123",
    "history_keys": "5377396889652060561",
    "history_deposits": "6091430271989587379",
    "spin": "6129779562529168023",
    "youtube": "5929221469027437894",
    "balance_rupee": "6091430271989587379",
    "select_option": "6118531988073747281",
    "purchases_label": "6091170843080007327",
    "referrals_label": "6334321173773425054",
    "joined_label": "6332080283176672910",
    "refer_commission": "6091231303334633875",
    "referrals_count": "6334831098060609201",
    "balance_label": "6091430271989587379",
    "tutorial_video_text": "5769547529993588669",
    "support_contact": "5956045399511797140",
    "deposit_amount": "6035277294036061660",
    "screenshot_request": "5809840662601802452",
    "verification_sent": "6028565819225542441",
    "payment_success": "5769547529993588669",      # NEW
    "redeem": None,
    "warning": None,
    "info": None,
}

STANDARD_EMOJIS = {
    "store_icon": "🏪",
    "buy_now": "🛒",
    "check_update": "💾",
    "add_balance": "💰",
    "my_profile": "🔥",
    "refer_earn": "🔗",
    "how_to_use": "📖",
    "support": "✈️",
    "daily_gift": "🎁",
    "deposit_success": "✅",
    "plan_icon": "📅",
    "price_icon": "🪙",
    "back_button": "🔙",
    "wallet": "💳",
    "upi": "💳",
    "binance": "🪙",
    "verify": "✅",
    "accept": "✅",
    "reject": "❌",
    "history_keys": "📜",
    "history_deposits": "📜",
    "spin": "🎰",
    "youtube": "▶️",
    "balance_rupee": "₹",
    "select_option": "👇",
    "purchases_label": "🛒",
    "referrals_label": "📨",
    "joined_label": "📅",
    "refer_commission": "💸",
    "referrals_count": "👥",
    "balance_label": "💰",
    "tutorial_video_text": "🎬",
    "support_contact": "✈️",
    "deposit_amount": "💰",
    "screenshot_request": "📸",
    "verification_sent": "✅",
    "payment_success": "✅",
    "redeem": "🎫",
    "warning": "⚠️",
    "info": "ℹ️",
}

bot = telebot.TeleBot(BOT_TOKEN)

def is_admin(user_id):
    return user_id in ADMIN_IDS

def init_db():
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    balance REAL,
                    referred_by INTEGER,
                    total_referrals INTEGER,
                    join_date TEXT,
                    last_daily_claim TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    plans TEXT,
                    tutorial TEXT,
                    status TEXT DEFAULT 'Available'
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    product_name TEXT,
                    plan TEXT,
                    price REAL,
                    payment_method TEXT,
                    status TEXT,
                    utr TEXT,
                    date TEXT,
                    is_manual INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS redeem_codes (
                    code TEXT PRIMARY KEY,
                    amount REAL,
                    used_by INTEGER,
                    is_used INTEGER
                )''')
    try:
        c.execute("ALTER TABLE products ADD COLUMN status TEXT DEFAULT 'Available'")
    except sqlite3.OperationalError:
        pass
    conn.commit()
    conn.close()
    logger.info("Database initialized.")

init_db()

def get_user(user_id):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def create_user(user_id, ref_id=None):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    if ref_id and ref_id != user_id and get_user(ref_id):
        c.execute("UPDATE users SET total_referrals = total_referrals + 1 WHERE user_id=?", (ref_id,))
        log_referral(ref_id, user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute("INSERT INTO users (user_id, balance, referred_by, total_referrals, join_date, last_daily_claim) "
              "VALUES (?, 0.0, ?, 0, ?, ?)",
              (user_id, ref_id, now, ""))
    conn.commit()
    conn.close()
    logger.info(f"New user: {user_id} (referred by {ref_id})")

def ensure_user_exists(user_id):
    if not get_user(user_id):
        create_user(user_id)

def update_balance(user_id, amount):
    ensure_user_exists(user_id)
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def get_balance(user_id):
    ensure_user_exists(user_id)
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute("SELECT balance FROM users WHERE user_id=?", (user_id,))
    bal = c.fetchone()[0]
    conn.close()
    return bal

def add_order(user_id, product_name, plan, price, payment_method, status, utr="", is_manual=0):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute("INSERT INTO orders (user_id, product_name, plan, price, payment_method, status, utr, date, is_manual) "
              "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
              (user_id, product_name, plan, price, payment_method, status, utr, now, is_manual))
    conn.commit()
    conn.close()
    return c.lastrowid

def get_last_daily_claim(user_id):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute("SELECT last_daily_claim FROM users WHERE user_id=?", (user_id,))
    res = c.fetchone()
    conn.close()
    return res[0] if res else ""

def update_last_daily_claim(user_id):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    now = datetime.datetime.now().strftime("%Y-%m-%d")
    c.execute("UPDATE users SET last_daily_claim = ? WHERE user_id=?", (now, user_id))
    conn.commit()
    conn.close()

def credit_referrer_bonus(user_id, amount):
    conn = sqlite3.connect('store.db')
    c = conn.cursor()
    c.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row and row[0]:
        referrer = row[0]
        bonus = round(amount * 0.01, 2)
        if bonus > 0:
            c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (bonus, referrer))
            conn.commit()
            logger.info(f"Referrer {referrer} got bonus ₹{bonus}")
            log_referral_bonus(referrer, user_id, bonus)
    conn.close()

def get_user_info(user_id):
    try:
        chat = bot.get_chat(user_id)
        name = chat.first_name or "Unknown"
        if chat.last_name:
            name += " " + chat.last_name
        username = chat.username if chat.username else ""
        return name, username
    except:
        return "Unknown", ""

def send_purchase_log(order_id, user_id, product_name, plan, price, method, utr=""):
    name, username = get_user_info(user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"🛒 <b>PURCHASE</b>\n\n"
        f"Product: {product_name}\n"
        f"Plan: {plan}\n"
        f"Price: ₹{price:.2f}\n"
        f"Payment: {method}\n"
        f"UTR: {utr if utr else 'N/A'}\n\n"
        f"👤 {name}"
        f"{' (@' + username + ')' if username else ''}\n"
        f"🆔 {user_id}\n"
        f"🕒 {now}\n"
        f"📋 Order ID: {order_id}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
        logger.info(f"Purchase log sent for order {order_id}")
    except Exception as e:
        logger.error(f"Failed to send purchase log: {e}")

def log_gift_claimed(user_id, reward):
    name, username = get_user_info(user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"🎁 <b>GIFT CLAIMED</b>\n\n"
        f"👤 {name}{' (@' + username + ')' if username else ''}\n"
        f"🆔 {user_id}\n"
        f"💰 Reward: ₹{reward:.2f}\n"
        f"🕒 {now}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Failed to send gift log: {e}")

def log_referral(referrer_id, new_user_id):
    ref_name, ref_username = get_user_info(referrer_id)
    new_name, new_username = get_user_info(new_user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"🔗 <b>NEW REFERRAL</b>\n\n"
        f"👤 Referrer: {ref_name}{' (@' + ref_username + ')' if ref_username else ''}\n"
        f"🆔 {referrer_id}\n\n"
        f"👤 New User: {new_name}{' (@' + new_username + ')' if new_username else ''}\n"
        f"🆔 {new_user_id}\n"
        f"🕒 {now}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Failed to send referral log: {e}")

def log_referral_bonus(referrer_id, user_id, bonus):
    ref_name, ref_username = get_user_info(referrer_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"💸 <b>REFERRAL BONUS</b>\n\n"
        f"👤 {ref_name}{' (@' + ref_username + ')' if ref_username else ''}\n"
        f"🆔 {referrer_id}\n"
        f"💰 Bonus: ₹{bonus:.2f} from user {user_id}\n"
        f"🕒 {now}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Failed to send referral bonus log: {e}")

def log_product_added(name, plans):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"➕ <b>NEW PRODUCT ADDED</b>\n\n"
        f"📦 Name: {name}\n"
        f"📋 Plans: {plans}\n"
        f"🕒 {now}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Failed to send product added log: {e}")

def log_payment_request(order_id, user_id, product_name, plan, price, method, utr=""):
    name, username = get_user_info(user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_text = (
        f"📤 <b>PAYMENT REQUEST</b>\n\n"
        f"Product: {product_name}\n"
        f"Plan: {plan}\n"
        f"Amount: ₹{price:.2f}\n"
        f"Method: {method}\n"
        f"UTR: {utr if utr else 'N/A'}\n\n"
        f"👤 {name}{' (@' + username + ')' if username else ''}\n"
        f"🆔 {user_id}\n"
        f"🕒 {now}\n"
        f"📋 Order ID: {order_id}"
    )
    try:
        bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Failed to send payment request log: {e}")

def pin_verification_message(user_id, amount, product_name=None, plan=None, method=None):
    name, username = get_user_info(user_id)
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if product_name:
        text = (
            f"✅ <b>PAYMENT VERIFIED</b>\n\n"
            f"👤 {name}{' (@' + username + ')' if username else ''}\n"
            f"🆔 {user_id}\n"
            f"📦 Product: {product_name}\n"
            f"📅 Plan: {plan}\n"
            f"💰 Amount: ₹{amount:.2f}\n"
            f"💳 Method: {method}\n"
            f"🕒 {now}"
        )
    else:
        text = (
            f"✅ <b>DEPOSIT VERIFIED</b>\n\n"
            f"👤 {name}{' (@' + username + ')' if username else ''}\n"
            f"🆔 {user_id}\n"
            f"💰 Amount: ₹{amount:.2f}\n"
            f"🕒 {now}"
        )
    try:
        msg = bot.send_message(GROUP_ID, text, parse_mode='HTML')
        bot.pin_chat_message(GROUP_ID, msg.message_id)
    except Exception as e:
        logger.error(f"Failed to pin verification message: {e}")

def strip_tg_emoji_tags(text):
    return re.sub(r'<tg-emoji[^>]*>([^<]*)</tg-emoji>', r'\1', text)

def safe_send_message(chat_id, text, parse_mode='HTML', reply_markup=None, disable_web_page_preview=None):
    try:
        return bot.send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup,
                                disable_web_page_preview=disable_web_page_preview)
    except Exception as e:
        logger.error(f"Message send failed: {e}")
        if "ENTITY_TEXT_INVALID" in str(e):
            fallback_text = strip_tg_emoji_tags(text)
            logger.info(f"Retrying with fallback text")
            try:
                return bot.send_message(chat_id, fallback_text, parse_mode='HTML', reply_markup=reply_markup,
                                        disable_web_page_preview=disable_web_page_preview)
            except Exception as e2:
                logger.error(f"Fallback send also failed: {e2}")
                raise e
        else:
            raise

def safe_send_photo(chat_id, photo, caption=None, parse_mode='HTML', reply_markup=None):
    try:
        return bot.send_photo(chat_id, photo, caption=caption, parse_mode=parse_mode, reply_markup=reply_markup)
    except Exception as e:
        logger.error(f"Photo send failed: {e}")
        raise

def send_and_pin(text, parse_mode='HTML', reply_markup=None):
    try:
        msg = safe_send_message(GROUP_ID, text, parse_mode=parse_mode, reply_markup=reply_markup)
        try:
            bot.pin_chat_message(GROUP_ID, msg.message_id)
        except:
            pass
        return msg
    except Exception as e:
        logger.error(f"Failed to send to group: {e}")
        return None

def send_log(text, parse_mode='HTML', reply_markup=None):
    logger.info(f"LOG: {text}")

def get_premium_emoji_html(key, fallback="⭐"):
    emoji_id = PREMIUM_EMOJIS.get(key)
    if emoji_id:
        return f'<tg-emoji emoji-id="{emoji_id}">{STANDARD_EMOJIS.get(key, fallback)}</tg-emoji>'
    else:
        return STANDARD_EMOJIS.get(key, fallback)

def create_custom_button(text, callback_data=None, url=None, emoji_key=None, style=None):
    kwargs = {'text': text}
    if callback_data:
        kwargs['callback_data'] = callback_data
    elif url:
        kwargs['url'] = url
    else:
        raise ValueError("Either callback_data or url must be provided.")
    if emoji_key and PREMIUM_EMOJIS.get(emoji_key):
        kwargs['icon_custom_emoji_id'] = PREMIUM_EMOJIS[emoji_key]
    if style:
        kwargs['style'] = style
    return InlineKeyboardButton(**kwargs)

def main_menu():
    markup = InlineKeyboardMarkup(row_width=2)
    markup.row(create_custom_button("Buy Now", "buy_now", emoji_key="buy_now", style="success"))
    markup.add(
        create_custom_button("Check Update", "check_update", emoji_key="check_update", style="primary"),
        create_custom_button("Add Balance", "add_balance", emoji_key="add_balance", style="success")
    )
    markup.row(create_custom_button("My Profile + History", "my_profile", emoji_key="my_profile", style="success"))
    markup.add(
        create_custom_button("Refer And Earn", "refer_earn", emoji_key="refer_earn", style="primary"),
        create_custom_button("How To Use Bot", "how_to_use", emoji_key="how_to_use", style="success")
    )
    markup.add(
        create_custom_button("Support", "support", emoji_key="support", style="danger"),
        create_custom_button("Daily Gift", "daily_gift", emoji_key="daily_gift", style="success")
    )
    return markup

def admin_menu():
    markup = InlineKeyboardMarkup(row_width=1)
    markup.add(
        InlineKeyboardButton("➕ Add Product", callback_data="admin_add_product"),
        InlineKeyboardButton("🗑 Delete Product", callback_data="admin_delete_product"),
        InlineKeyboardButton("🔄 Toggle Product Status", callback_data="admin_toggle_status"),
        InlineKeyboardButton("🎫 Generate Redeem Code", callback_data="admin_redeem"),
        InlineKeyboardButton("📦 View Pending Logs", callback_data="admin_logs")
    )
    return markup

def back_btn():
    markup = InlineKeyboardMarkup()
    markup.add(create_custom_button("Back to Menu", "back_main", emoji_key="back_button", style="danger"))
    return markup

def accept_reject_buttons(callback_accept, callback_reject):
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        create_custom_button("Accept", callback_accept, emoji_key="accept", style="success"),
        create_custom_button("Reject", callback_reject, emoji_key="reject", style="danger")
    )
    return markup

def verify_button(callback_data):
    markup = InlineKeyboardMarkup()
    markup.add(create_custom_button("VERIFY PAYMENT", callback_data, emoji_key="verify", style="success"))
    return markup

def tutorial_button():
    markup = InlineKeyboardMarkup()
    markup.add(create_custom_button("Watch Tutorial", url=HOW_TO_USE_VIDEO_LINK, emoji_key="youtube", style="danger"))
    return markup

def send_or_replace(chat_id, text, parse_mode='HTML', reply_markup=None, delete_old_msg_id=None):
    if delete_old_msg_id:
        try:
            bot.delete_message(chat_id, delete_old_msg_id)
        except:
            pass
    return safe_send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.chat.id
    ref_id = None
    if len(message.text.split()) > 1:
        try:
            ref_id = int(message.text.split()[1])
        except:
            pass
    ensure_user_exists(user_id)
    bal = get_balance(user_id)

    def tag(key, fallback):
        emoji_id = START_EMOJIS.get(key)
        if emoji_id:
            return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'
        return fallback

    store = tag("store_icon", "🏪")
    unlock = tag("unlock", "🔓")
    arrow = tag("arrow", "⏩")
    buy = tag("buy", "🛒")
    check = tag("check", "⬇️")
    add = tag("add", "💰")
    profile = tag("profile", "⚙️")
    refer = tag("refer", "🔥")
    how = tag("how", "⁉️")
    support = tag("support", "🌐")
    gift = tag("gift", "🎁")
    balance_icon = tag("balance", "💰")
    select = tag("select", "👇")

    start_text = f'''{store} <b>SIYA PANEL STORE</b> {unlock}
{arrow}
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
┝ {buy} <b>Buy Now</b> : All Key Purchase & Instant Delivery
┝ {check} <b>Check Update</b> : Check Setup Video And Update Apk
┝ {add} <b>Add Balance</b> : Deposit Balance & Secure Auto-Add Payment System
┝ {profile} <b>My Profile + All History</b> : Check Your Account Information + All History
┝ {refer} <b>Refer And Earn</b> : Share Refer Link & Earn Money
┝ {how} <b>How To Use Bot</b> : View Tutorial And Work This Bot
┝ {support} <b>Support</b> : Bot Problem Fixed For Support Admin
┝ {gift} <b>Daily Gift</b> : Free Spin and win random balance daily, Only one spin every 24 hours.
〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
{arrow}
{add} <b>Your Balance:</b> {balance_icon}₹{bal:.2f}
{select} Select an option from the menu below:'''

    safe_send_message(user_id, start_text, parse_mode='HTML', reply_markup=main_menu())
    logger.info(f"User {user_id} started.")

@bot.message_handler(commands=['admin_panel'])
def admin_panel_command(message):
    if not is_admin(message.chat.id):
        safe_send_message(message.chat.id, "⛔ Access Denied.")
        return
    safe_send_message(message.chat.id, "🛠 Admin Control Panel", parse_mode='HTML', reply_markup=admin_menu())
    logger.info(f"Admin opened panel.")

@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    try:
        bot.answer_callback_query(call.id)
    except Exception as e:
        if "query is too old" not in str(e):
            logger.error(f"Answer callback error: {e}")

    user_id = call.message.chat.id
    ensure_user_exists(user_id)

    try:
        bot.delete_message(user_id, call.message.message_id)
    except:
        pass

    try:
        if call.data == "back_main":
            bal = get_balance(user_id)
            store_icon = get_premium_emoji_html("store_icon", "🏪")
            text = (
                f"{store_icon} SIYA PANEL STORE {store_icon}\n\n"
                f"Your Balance: 💰 ₹{bal:.2f}\n\n👇 Select an option:"
            )
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=main_menu())
            return

        if call.data == "buy_now":
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT id, name, plans FROM products WHERE status='Available'")
            prods = c.fetchall()
            conn.close()
            if not prods:
                safe_send_message(user_id, "❌ No products available.")
                return
            markup = InlineKeyboardMarkup(row_width=1)
            for p in prods:
                markup.add(create_custom_button(p[1], f"sel_prod_{p[0]}", emoji_key="buy_now", style="success"))
            markup.row(create_custom_button("Back", "back_main", emoji_key="back_button", style="danger"))
            header_icon = get_premium_emoji_html("buy_now", "🛒")
            safe_send_message(user_id, f"{header_icon} PRODUCT STORE\n\nChoose a product:", parse_mode='HTML', reply_markup=markup)
            return

        if call.data.startswith("sel_prod_"):
            prod_id = int(call.data.split("_")[2])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT name, plans FROM products WHERE id=? AND status='Available'", (prod_id,))
            row = c.fetchone()
            conn.close()
            if not row:
                safe_send_message(user_id, "Product not available or out of stock.")
                return
            name, plans_json = row
            plans = json.loads(plans_json)

            product_icon = get_premium_emoji_html("buy_now", "🛒")
            choose_icon = get_premium_emoji_html("plan_icon", "🛍️")
            coin_icon = get_premium_emoji_html("price_icon", "🪙")
            time_icon = get_premium_emoji_html("plan_icon", "⏳")
            plan_lines = [f"┝ {coin_icon}₹{p['price']:.2f} — {time_icon}{p['days']} Days" for p in plans]
            plan_text = "\n".join(plan_lines)

            text = f"{product_icon} {name}\n{choose_icon} Choose your access plan:\n{plan_text}"
            markup = InlineKeyboardMarkup(row_width=1)
            for p in plans:
                markup.add(create_custom_button(
                    f"{p['days']} Day - ₹{p['price']}",
                    f"buy_plan_{prod_id}_{p['days']}_{p['price']}",
                    emoji_key="plan_icon", style="success"
                ))
            markup.row(create_custom_button("Back", "buy_now", emoji_key="back_button", style="danger"))
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=markup)
            return

        if call.data.startswith("buy_plan_"):
            parts = call.data.split("_")
            prod_id, days, price = int(parts[2]), int(parts[3]), float(parts[4])
            balance = get_balance(user_id)
            if balance >= price:
                markup = InlineKeyboardMarkup(row_width=1)
                markup.add(create_custom_button("✅ Pay from Wallet", f"wallet_pay_{prod_id}_{days}_{price}", emoji_key="wallet", style="success"))
                markup.row(create_custom_button("Back", "buy_now", emoji_key="back_button", style="danger"))
                safe_send_message(user_id, f"💳 You have enough balance (₹{balance:.2f}). Pay from wallet?", parse_mode='HTML', reply_markup=markup)
            else:
                markup = InlineKeyboardMarkup(row_width=2)
                markup.add(
                    create_custom_button("Pay UPI", f"pay_upi_{prod_id}_{days}_{price}", emoji_key="upi", style="success"),
                    create_custom_button("Binance", f"pay_binance_{prod_id}_{days}_{price}", emoji_key="binance", style="success")
                )
                markup.row(create_custom_button("Back", "buy_now", emoji_key="back_button", style="danger"))
                text = f"❌ INSUFFICIENT BALANCE\n\nPrice: ₹{price}\nYour Balance: ₹{balance:.2f}\nDeficit: ₹{price - balance:.2f}\n\nSelect gateway:"
                safe_send_message(user_id, text, parse_mode='HTML', reply_markup=markup)
            return

        if call.data.startswith("wallet_pay_"):
            parts = call.data.split("_")
            prod_id, days, price = int(parts[2]), int(parts[3]), float(parts[4])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT name, status FROM products WHERE id=?", (prod_id,))
            row = c.fetchone()
            if not row or row[1] != 'Available':
                safe_send_message(user_id, "❌ This product is no longer available.")
                conn.close()
                return
            pname = row[0]
            c.execute("UPDATE users SET balance = balance - ? WHERE user_id=?", (price, user_id))
            c.execute("INSERT INTO orders (user_id, product_name, plan, price, payment_method, status, date) "
                      "VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (user_id, pname, f"{days} Days", price, "Wallet", "Completed",
                       datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()
            conn.close()
            credit_referrer_bonus(user_id, price)

            order_id = c.lastrowid
            send_purchase_log(order_id, user_id, pname, f"{days} Days", price, "Wallet")

            success_icon = get_premium_emoji_html("payment_success", "✅")
            support_icon = get_premium_emoji_html("support_contact", "✈️")
            text = (
                f"{success_icon} <b>Payment Successful!</b>\n\n"
                f"Product: {pname}\nPlan: {days} Days\nAmount Deducted: ₹{price:.2f}\n\n"
                f"{support_icon} Contact admin @{SUPPORT_USERNAME} to receive your panel."
            )
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            send_log(f"💳 Wallet Purchase\nUser: {user_id}\nProduct: {pname}\nPlan: {days} Days\nAmount: ₹{price}")
            return

        if call.data.startswith("pay_upi_"):
            parts = call.data.split("_")
            prod_id, days, price = int(parts[2]), int(parts[3]), float(parts[4])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT status FROM products WHERE id=?", (prod_id,))
            row = c.fetchone()
            conn.close()
            if not row or row[0] != 'Available':
                safe_send_message(user_id, "❌ This product is no longer available.")
                return
            qr = qrcode.QRCode(box_size=10, border=4)
            qr.add_data(f"upi://pay?pa={UPI_ID}&am={price}&cu=INR")
            qr.make(fit=True)
            img = qr.make_image(fill='black', back_color='white')
            bio = io.BytesIO()
            img.save(bio, 'PNG')
            bio.seek(0)
            safe_send_photo(user_id, bio,
                           caption=f"💳 Scan to Pay ₹{price}\n\nUPI ID: {UPI_ID}\n\nAfter paying, click verify:",
                           parse_mode='HTML')
            markup = verify_button(f"verify_upi_{prod_id}_{days}_{price}")
            safe_send_message(user_id, "👇 Verify after payment:", reply_markup=markup)
            return

        if call.data.startswith("pay_binance_"):
            parts = call.data.split("_")
            prod_id, days, price = int(parts[2]), int(parts[3]), float(parts[4])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT status FROM products WHERE id=?", (prod_id,))
            row = c.fetchone()
            conn.close()
            if not row or row[0] != 'Available':
                safe_send_message(user_id, "❌ This product is no longer available.")
                return
            text = f"🪙 Binance Payment\n\nSend exactly ₹{price} to Binance ID: <b>{BINANCE_ID}</b>\n\nAfter sending, click verify:"
            safe_send_message(user_id, text, parse_mode='HTML')
            markup = verify_button(f"verify_binance_{prod_id}_{days}_{price}")
            safe_send_message(user_id, "👇 Verify after payment:", reply_markup=markup)
            return

        if call.data.startswith("verify_upi_") or call.data.startswith("verify_binance_"):
            parts = call.data.split("_")
            method = parts[1]
            prod_id, days, price = int(parts[2]), int(parts[3]), float(parts[4])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT status FROM products WHERE id=?", (prod_id,))
            row = c.fetchone()
            conn.close()
            if not row or row[0] != 'Available':
                safe_send_message(user_id, "❌ This product is no longer available.")
                return

            user_temp_data[user_id] = {
                'type': 'product',
                'prod_id': prod_id,
                'days': days,
                'price': price,
                'method': method.capitalize()
            }

            screenshot_emoji = get_premium_emoji_html("screenshot_request", "📸")
            safe_send_message(user_id, f"{screenshot_emoji} Please send a <b>screenshot</b> of your payment.", parse_mode='HTML')
            bot.register_next_step_handler(call.message, handle_screenshot)
            return

        if call.data == "check_update":
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("🔗 Click Here For Setup & Updates", url=UPDATE_CHANNEL_LINK))
            markup.row(create_custom_button("Back", "back_main", emoji_key="back_button", style="danger"))
            update_icon = get_premium_emoji_html("check_update", "💾")
            safe_send_message(user_id, f"{update_icon} Check Update\n\nCheck Setup Video & Update Apk", parse_mode='HTML', reply_markup=markup)
            return

        if call.data == "add_balance":
            markup = InlineKeyboardMarkup(row_width=2)
            markup.add(
                create_custom_button("PAY UPI", "recharge_upi", emoji_key="upi", style="success"),
                create_custom_button("BINANCE", "recharge_binance", emoji_key="binance", style="success")
            )
            markup.row(create_custom_button("Redeem Code", "redeem_code", emoji_key="redeem", style="success"))
            markup.row(create_custom_button("Back", "back_main", emoji_key="back_button", style="danger"))
            add_icon = get_premium_emoji_html("add_balance", "💰")
            safe_send_message(user_id, f"{add_icon} Add Balance\n\nDeposit Balance & Secure Auto-Add Payment System", parse_mode='HTML', reply_markup=markup)
            return

        if call.data == "recharge_upi" or call.data == "recharge_binance":
            method = "UPI" if call.data == "recharge_upi" else "Binance"
            deposit_emoji = get_premium_emoji_html("deposit_amount", "💵")
            text = f"{deposit_emoji} Enter the <b>Amount</b> you want to deposit via {method}.\n\n<i>Just type the number (e.g., 100)</i>"
            safe_send_message(user_id, text, parse_mode='HTML')
            bot.register_next_step_handler(call.message, process_add_balance_amount, method)
            return

        if call.data == "redeem_code":
            safe_send_message(user_id, "🎫 Please send the <b>Redeem Code</b> you received from the admin:", parse_mode='HTML')
            bot.register_next_step_handler(call.message, process_redeem_code)
            return

        if call.data == "my_profile":
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT balance, total_referrals, join_date FROM users WHERE user_id=?", (user_id,))
            bal, refs, date = c.fetchone()
            c.execute("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='Completed'", (user_id,))
            orders = c.fetchone()[0]
            conn.close()
            markup = InlineKeyboardMarkup(row_width=2)
            markup.add(
                create_custom_button("Key History", "hist_keys", emoji_key="history_keys", style="success"),
                create_custom_button("Deposit History", "hist_deposits", emoji_key="history_deposits", style="success")
            )
            markup.row(create_custom_button("Back", "back_main", emoji_key="back_button", style="danger"))
            profile_icon = get_premium_emoji_html("my_profile", "🔥")
            bal_icon = get_premium_emoji_html("balance_label", "💰")
            pur_icon = get_premium_emoji_html("purchases_label", "🛒")
            ref_icon = get_premium_emoji_html("referrals_label", "📨")
            join_icon = get_premium_emoji_html("joined_label", "📅")
            text = (
                f"{profile_icon} My Profile + History\n\n"
                f"🆔 ID: {user_id}\n"
                f"{bal_icon} Balance: ₹{bal:.2f}\n"
                f"{pur_icon} Purchases: {orders}\n"
                f"{ref_icon} Referrals: {refs}\n"
                f"{join_icon} Joined: {date}"
            )
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=markup)
            return

        if call.data == "hist_keys" or call.data == "hist_deposits":
            type_field = "product_name" if call.data == "hist_keys" else "payment_method"
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute(f"SELECT {type_field}, plan, price, date FROM orders WHERE user_id=? AND status='Completed' ORDER BY id DESC LIMIT 10",
                      (user_id,))
            history = c.fetchall()
            conn.close()
            text = f"📜 {'Key' if type_field=='product_name' else 'Deposit'} History (Last 10)\n\n"
            if not history:
                text += "No history found."
            else:
                for h in history:
                    text += f"▸ {h[0]} ({h[1]}) - ₹{h[2]} [{h[3]}]\n"
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            return

        if call.data == "refer_earn":
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT total_referrals FROM users WHERE user_id=?", (user_id,))
            refs = c.fetchone()[0]
            conn.close()
            link = f"https://t.me/{BOT_USERNAME}?start={user_id}"
            refer_icon = get_premium_emoji_html("refer_earn", "🔗")
            comm_icon = get_premium_emoji_html("refer_commission", "💸")
            count_icon = get_premium_emoji_html("referrals_count", "👥")
            text = (
                f"{refer_icon} Refer And Earn\n\n"
                f"Share Refer Link & Earn Money\n\n"
                f"<code>{link}</code>\n\n"
                f"{comm_icon} Earn <b>1% Commission</b> when your referred friends purchase!\n"
                f"{count_icon} Total referrals: {refs}"
            )
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            return

        if call.data == "daily_gift":
            last_claim = get_last_daily_claim(user_id)
            today = datetime.datetime.now().strftime("%Y-%m-%d")
            if last_claim == today:
                bot.answer_callback_query(call.id, "❌ Already claimed today! Come back in 24 hours.", show_alert=True)
                bal = get_balance(user_id)
                store_icon = get_premium_emoji_html("store_icon", "🏪")
                text = f"{store_icon} SIYA PANEL STORE {store_icon}\n\nYour Balance: 💰 ₹{bal:.2f}\n\n👇 Select an option:"
                safe_send_message(user_id, text, parse_mode='HTML', reply_markup=main_menu())
                return
            reward = round(random.uniform(0.01, 1.00), 2)
            update_balance(user_id, reward)
            update_last_daily_claim(user_id)
            log_gift_claimed(user_id, reward)
            gift_icon = get_premium_emoji_html("daily_gift", "🎁")
            spin_icon = get_premium_emoji_html("spin", "🎰")
            text = f"{gift_icon} Daily Gift\n\n{spin_icon} Congratulations!\n\nYou won <b>₹{reward}</b>! Added to your wallet."
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            send_log(f"🎁 Daily Gift\nUser: {user_id}\nReward: ₹{reward}")
            return

        if call.data == "how_to_use":
            buy_icon = get_premium_emoji_html("buy_now", "🛒")
            check_icon = get_premium_emoji_html("check_update", "💾")
            add_icon = get_premium_emoji_html("add_balance", "💰")
            profile_icon = get_premium_emoji_html("my_profile", "🔥")
            refer_icon = get_premium_emoji_html("refer_earn", "🔗")
            support_icon = get_premium_emoji_html("support", "✈️")
            gift_icon = get_premium_emoji_html("daily_gift", "🎁")
            how_icon = get_premium_emoji_html("how_to_use", "📖")
            text = (
                f"{how_icon} How To Use Bot\n\n"
                "View Tutorial And Work This Bot\n\n"
                f"{buy_icon} Buy Now – All Key Purchases &amp; Instant Delivery\n"
                f"{check_icon} Check Update – Check Setup Video And Update Apk\n"
                f"{add_icon} Add Balance – Deposit Balance &amp; Secure Auto-Add Payment System\n"
                f"{profile_icon} My Profile + History – Check Your Account Information &amp; All History\n"
                f"{refer_icon} Refer And Earn – Share Refer Link &amp; Earn Money\n"
                f"{support_icon} Support – Bot Problem Fixed For Support Admin\n"
                f"{gift_icon} Daily Gift – Free Spin &amp; Win Random Balance Daily (once every 24 hours)\n\n"
                f"{get_premium_emoji_html('tutorial_video_text', '🎬')} Tap the video button below for a full tutorial:"
            )
            markup = tutorial_button()
            markup.row(create_custom_button("Back", "back_main", emoji_key="back_button", style="danger"))
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=markup)
            return

        if call.data == "support":
            support_icon = get_premium_emoji_html("support", "✈️")
            contact_icon = get_premium_emoji_html("support_contact", "✈️")
            text = f"{support_icon} Support\n\nBot Problem Fixed For Support Admin\n\n{contact_icon} Contact: @{SUPPORT_USERNAME}"
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            return

        if call.data == "admin_panel":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            safe_send_message(user_id, "🛠 Admin Control Panel", parse_mode='HTML', reply_markup=admin_menu())
            return

        if call.data == "admin_add_product":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            safe_send_message(user_id, "📝 Add New Product\n\nSend the <b>Product Name</b>:", parse_mode='HTML')
            bot.register_next_step_handler(call.message, add_product_name)
            return

        if call.data == "admin_delete_product":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT id, name FROM products")
            products = c.fetchall()
            conn.close()
            if not products:
                safe_send_message(user_id, "❌ No products to delete.")
                return
            markup = InlineKeyboardMarkup(row_width=1)
            for pid, name in products:
                markup.add(InlineKeyboardButton(f"🗑 {name}", callback_data=f"del_prod_{pid}"))
            markup.row(create_custom_button("Back", "admin_panel", emoji_key="back_button", style="danger"))
            safe_send_message(user_id, "Select a product to delete:", parse_mode='HTML', reply_markup=markup)
            return

        if call.data.startswith("del_prod_"):
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            prod_id = int(call.data.split("_")[2])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("DELETE FROM products WHERE id=?", (prod_id,))
            conn.commit()
            conn.close()
            safe_send_message(user_id, "✅ Product deleted successfully.")
            send_log(f"🗑 Product deleted by admin: ID {prod_id}")
            safe_send_message(user_id, "🛠 Admin Control Panel", parse_mode='HTML', reply_markup=admin_menu())
            return

        if call.data == "admin_toggle_status":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT id, name, status FROM products")
            products = c.fetchall()
            conn.close()
            if not products:
                safe_send_message(user_id, "❌ No products.")
                return
            markup = InlineKeyboardMarkup(row_width=1)
            for pid, name, status in products:
                emoji = "🟢" if status == "Available" else "🔴"
                label = f"{emoji} {name} ({status})"
                markup.add(InlineKeyboardButton(label, callback_data=f"toggle_prod_{pid}"))
            markup.row(create_custom_button("Back", "admin_panel", emoji_key="back_button", style="danger"))
            safe_send_message(user_id, "🔄 <b>Toggle Product Status</b>\n\nClick a product to change its status:", parse_mode='HTML', reply_markup=markup)
            return

        if call.data.startswith("toggle_prod_"):
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            prod_id = int(call.data.split("_")[2])
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT status FROM products WHERE id=?", (prod_id,))
            row = c.fetchone()
            if not row:
                safe_send_message(user_id, "Product not found.")
                conn.close()
                return
            new_status = "Out of Stock" if row[0] == "Available" else "Available"
            c.execute("UPDATE products SET status=? WHERE id=?", (new_status, prod_id))
            conn.commit()
            conn.close()
            safe_send_message(user_id, f"✅ Product status updated to <b>{new_status}</b>.", parse_mode='HTML')
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT id, name, status FROM products")
            products = c.fetchall()
            conn.close()
            markup = InlineKeyboardMarkup(row_width=1)
            for pid, name, status in products:
                emoji = "🟢" if status == "Available" else "🔴"
                label = f"{emoji} {name} ({status})"
                markup.add(InlineKeyboardButton(label, callback_data=f"toggle_prod_{pid}"))
            markup.row(create_custom_button("Back", "admin_panel", emoji_key="back_button", style="danger"))
            safe_send_message(user_id, "🔄 <b>Toggle Product Status</b>\n\nClick a product to change its status:", parse_mode='HTML', reply_markup=markup)
            return

        if call.data == "admin_redeem":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            safe_send_message(user_id, "🎫 Generate Redeem Code\n\nSend the Amount for this code (e.g. 50):", parse_mode='HTML')
            bot.register_next_step_handler(call.message, admin_generate_redeem)
            return

        if call.data == "admin_logs":
            if not is_admin(user_id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return
            conn = sqlite3.connect('store.db')
            c = conn.cursor()
            c.execute("SELECT * FROM orders WHERE status='Pending' ORDER BY id DESC LIMIT 10")
            logs = c.fetchall()
            conn.close()
            text = "📦 Pending Logs:\n\n"
            for log in logs:
                text += (f"ID: {log[0]}\nUser: {log[1]}\nProduct: {log[2]} ({log[3]})\n"
                         f"Price: ₹{log[4]}\nMethod: {log[5]}\nUTR: {log[7]}\nDate: {log[8]}\n----------------\n")
            if not logs:
                text += "No pending logs."
            safe_send_message(user_id, text, parse_mode='HTML', reply_markup=back_btn())
            return

        if call.data.startswith("dep_verify_upi_") or call.data.startswith("dep_verify_binance_"):
            amount = float(call.data.split("_")[3])
            method = "UPI" if "upi" in call.data else "Binance"
            user_temp_data[user_id] = {
                'type': 'deposit',
                'amount': amount,
                'method': method
            }
            screenshot_emoji = get_premium_emoji_html("screenshot_request", "📸")
            safe_send_message(user_id, f"{screenshot_emoji} Please send a <b>screenshot</b> of your payment.", parse_mode='HTML')
            bot.register_next_step_handler(call.message, handle_screenshot)
            return

        if call.data.startswith("adm_"):
            if call.message.chat.id != GROUP_ID and not is_admin(call.message.chat.id):
                bot.answer_callback_query(call.id, "Access Denied.")
                return

            data = call.data.split("_")
            if data[1] == "accept":
                user_id = int(data[2])
                prod_id = int(data[3])
                days = int(data[4])
                price = float(data[5])
                conn = sqlite3.connect('store.db')
                c = conn.cursor()
                c.execute("SELECT name FROM products WHERE id=?", (prod_id,))
                row = c.fetchone()
                if not row:
                    bot.answer_callback_query(call.id, "Product not found.")
                    return
                pname = row[0]
                c.execute("UPDATE orders SET status='Completed' "
                          "WHERE user_id=? AND product_name=? AND plan=? AND price=? AND status='Pending' "
                          "ORDER BY id DESC LIMIT 1",
                          (user_id, pname, f"{days} Days", price))
                conn.commit()
                credit_referrer_bonus(user_id, price)
                conn.close()
                try:
                    bot.edit_message_text(f"✅ Accepted by {call.from_user.first_name}",
                                          chat_id=call.message.chat.id, message_id=call.message.message_id)
                except:
                    pass

                pin_verification_message(user_id, price, pname, f"{days} Days", "Manual")
                name, username = get_user_info(user_id)
                log_text = (
                    f"✅ <b>ORDER ACCEPTED</b>\n\n"
                    f"Product: {pname}\nPlan: {days} Days\nPrice: ₹{price}\n"
                    f"👤 {name}{' (@' + username + ')' if username else ''}\n🆔 {user_id}"
                )
                try:
                    bot.send_message(GROUP_ID, log_text, parse_mode='HTML')
                except:
                    pass

                success_icon = get_premium_emoji_html("payment_success", "✅")
                support_icon = get_premium_emoji_html("support_contact", "✈️")
                bot.send_message(user_id,
                                 f"{success_icon} <b>Payment Verified!</b>\n\nProduct: {pname}\nPlan: {days} Days\n\n{support_icon} Contact admin @{SUPPORT_USERNAME} to receive your panel.",
                                 parse_mode='HTML')
                send_log(f"✅ Order Accepted\nUser: {user_id}\nProduct: {pname}\nPlan: {days} Days\nPrice: ₹{price}")
                return

            if data[1] == "reject":
                user_id = int(data[2])
                try:
                    bot.edit_message_text(f"❌ Rejected by {call.from_user.first_name}",
                                          chat_id=call.message.chat.id, message_id=call.message.message_id)
                except:
                    pass
                bot.send_message(user_id, "❌ Your payment verification was rejected. Please contact support.")
                send_log(f"❌ Order Rejected\nUser: {user_id}")
                return

            if data[1] == "dep":
                if data[2] == "accept":
                    user_id = int(data[3])
                    amount = float(data[4])
                    conn = sqlite3.connect('store.db')
                    c = conn.cursor()
                    c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, user_id))
                    c.execute("UPDATE orders SET status='Completed' "
                              "WHERE user_id=? AND product_name='Deposit' AND price=? AND status='Pending' "
                              "ORDER BY id DESC LIMIT 1", (user_id, amount))
                    conn.commit()
                    conn.close()
                    try:
                        bot.edit_message_text(f"✅ Deposit Accepted by {call.from_user.first_name}",
                                              chat_id=call.message.chat.id, message_id=call.message.message_id)
                    except:
                        pass
                    pin_verification_message(user_id, amount)
                    deposit_icon = get_premium_emoji_html("deposit_success", "✅")
                    bot.send_message(user_id, f"{deposit_icon} Deposit Successful!\n\n₹{amount} added to your wallet. You can now buy panels.", parse_mode='HTML')
                    send_log(f"✅ Deposit Accepted\nUser: {user_id}\nAmount: ₹{amount}")
                    return
                elif data[2] == "reject":
                    user_id = int(data[3])
                    try:
                        bot.edit_message_text(f"❌ Deposit Rejected by {call.from_user.first_name}",
                                              chat_id=call.message.chat.id, message_id=call.message.message_id)
                    except:
                        pass
                    bot.send_message(user_id, "❌ Your deposit was rejected. Please contact support.")
                    send_log(f"❌ Deposit Rejected\nUser: {user_id}")
                    return

        bot.answer_callback_query(call.id, "Unknown action.")

    except Exception as e:
        logger.error(f"Callback error: {e}", exc_info=True)
        safe_send_message(user_id, f"❌ An error occurred: {str(e)}")

def handle_screenshot(message):
    user_id = message.chat.id
    if not message.photo:
        safe_send_message(user_id, "❌ Please send a photo (screenshot).")
        bot.register_next_step_handler(message, handle_screenshot)
        return

    photo_file_id = message.photo[-1].file_id
    data = user_temp_data.pop(user_id, None)
    if not data:
        safe_send_message(user_id, "❌ Session expired. Please start again.")
        return

    if data.get('type') == 'product':
        prod_id = data['prod_id']
        days = data['days']
        price = data['price']
        method = data['method']

        conn = sqlite3.connect('store.db')
        c = conn.cursor()
        c.execute("SELECT name FROM products WHERE id=?", (prod_id,))
        row = c.fetchone()
        if not row:
            safe_send_message(user_id, "❌ Product not found.")
            conn.close()
            return
        pname = row[0]

        order_id = add_order(user_id, pname, f"{days} Days", price, method, "Pending", "", is_manual=1)
        conn.close()

        log_payment_request(order_id, user_id, pname, f"{days} Days", price, method)
        send_purchase_log(order_id, user_id, pname, f"{days} Days", price, method)

        caption = (
            f"🛒 <b>NEW ORDER PENDING</b>\n\n"
            f"User: {user_id}\n"
            f"Product: {pname}\nPlan: {days} Days\nPrice: ₹{price}\n"
            f"Method: {method}"
        )
        admin_text = "<b>Actions:</b>"
        markup = accept_reject_buttons(
            f"adm_accept_{user_id}_{prod_id}_{days}_{price}",
            f"adm_reject_{user_id}"
        )
    else:
        amount = data['amount']
        method = data['method']
        order_id = add_order(user_id, "Deposit", "Recharge", amount, method, "Pending", "", is_manual=1)

        caption = (
            f"💳 {method} <b>DEPOSIT PENDING</b>\n\n"
            f"User: {user_id}\nAmount: ₹{amount}"
        )
        admin_text = "<b>Actions:</b>"
        markup = accept_reject_buttons(
            f"adm_dep_accept_{user_id}_{amount}",
            f"adm_dep_reject_{user_id}"
        )

    try:
        bot.send_photo(GROUP_ID, photo_file_id, caption=caption, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Photo send failed: {e}, trying forward")
        try:
            bot.forward_message(GROUP_ID, user_id, message.message_id)
            safe_send_message(GROUP_ID, caption, parse_mode='HTML')
        except Exception as e2:
            safe_send_message(GROUP_ID, f"⚠️ Screenshot failed, but order details:\n{caption}", parse_mode='HTML')
            safe_send_message(user_id, "⚠️ Could not deliver screenshot, but admin has been notified with details.")
        else:
            verification_emoji = get_premium_emoji_html("verification_sent", "✅")
            safe_send_message(user_id, f"{verification_emoji} Verification request sent! Admin will review.", parse_mode='HTML')
    else:
        verification_emoji = get_premium_emoji_html("verification_sent", "✅")
        safe_send_message(user_id, f"{verification_emoji} Verification request sent! Admin will review.", parse_mode='HTML')

    send_and_pin(admin_text, reply_markup=markup)
    logger.info(f"Order {order_id} created with screenshot from user {user_id}")

def process_add_balance_amount(message, method):
    try:
        amount = float(message.text.strip())
        if amount < 1:
            safe_send_message(message.chat.id, "Minimum deposit is ₹1.")
            return
        user_id = message.chat.id
        if method == "UPI":
            qr = qrcode.QRCode(box_size=10, border=4)
            qr.add_data(f"upi://pay?pa={UPI_ID}&am={amount}&cu=INR")
            qr.make(fit=True)
            img = qr.make_image(fill='black', back_color='white')
            bio = io.BytesIO()
            img.save(bio, 'PNG')
            bio.seek(0)
            safe_send_photo(user_id, bio,
                           caption=f"💳 Scan to Pay ₹{amount}\n\nUPI: {UPI_ID}",
                           parse_mode='HTML')
            markup = verify_button(f"dep_verify_upi_{amount}")
            safe_send_message(user_id, "After payment, click Verify.", reply_markup=markup)
        else:
            safe_send_message(user_id,
                             f"🪙 Binance Deposit\n\nSend ₹{amount} to Binance ID: <b>{BINANCE_ID}</b>\n\nAfter sending, click verify:",
                             parse_mode='HTML')
            markup = verify_button(f"dep_verify_binance_{amount}")
            safe_send_message(user_id, "👇 Verify after sending:", reply_markup=markup)
    except ValueError:
        safe_send_message(message.chat.id, "Invalid amount. Please enter a number.")
    except Exception as e:
        logger.error(f"process_add_balance_amount error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ An error occurred: {str(e)}")

def process_redeem_code(message):
    try:
        code = message.text.strip().upper()
        conn = sqlite3.connect('store.db')
        c = conn.cursor()
        c.execute("SELECT amount, is_used FROM redeem_codes WHERE code=?", (code,))
        res = c.fetchone()
        if not res:
            safe_send_message(message.chat.id, "❌ Invalid code.")
        elif res[1] == 1:
            safe_send_message(message.chat.id, "❌ Code already used.")
        else:
            amount = res[0]
            c.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (amount, message.chat.id))
            c.execute("UPDATE redeem_codes SET is_used=1, used_by=? WHERE code=?", (message.chat.id, code))
            conn.commit()
            safe_send_message(message.chat.id, f"✅ ₹{amount} added to your wallet.")
            send_log(f"🎫 Redeem Code Used\nUser: {message.chat.id}\nCode: {code}\nAmount: ₹{amount}")
            logger.info(f"User redeemed code {code}")
        conn.close()
    except Exception as e:
        logger.error(f"process_redeem_code error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ An error occurred: {str(e)}")

def add_product_name(message):
    try:
        name = message.text.strip()
        if not name:
            safe_send_message(message.chat.id, "❌ Name cannot be empty.")
            return
        safe_send_message(message.chat.id, "Send the <b>Plan List</b> in format:\n<code>1 Days - 80\n3 Days - 150</code>",
                     parse_mode='HTML')
        bot.register_next_step_handler(message, add_product_plans, name)
    except Exception as e:
        logger.error(f"add_product_name error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ An error occurred: {str(e)}")

def add_product_plans(message, name):
    try:
        raw = message.text.strip().split('\n')
        plans = []
        for line in raw:
            if '-' in line:
                d, p = line.split('-')
                days = int(d.strip().split()[0])
                price = float(p.strip().replace('₹', ''))
                plans.append({"days": days, "price": price})
            else:
                raise ValueError
        plans_json = json.dumps(plans)
        safe_send_message(message.chat.id, "✅ Plans saved! Now send the <b>Tutorial Link</b> (or 'None'):", parse_mode='HTML')
        bot.register_next_step_handler(message, add_product_link, name, plans_json)
    except Exception as e:
        logger.error(f"add_product_plans error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ Format error. Use:\n<code>1 Days - 80</code>")

def add_product_link(message, name, plans_json):
    try:
        link = message.text.strip()
        if link.lower() == 'none':
            link = ""
        conn = sqlite3.connect('store.db')
        c = conn.cursor()
        c.execute("INSERT INTO products (name, plans, tutorial) VALUES (?, ?, ?)", (name, plans_json, link))
        conn.commit()
        conn.close()
        log_product_added(name, plans_json)
        safe_send_message(message.chat.id, f"✅ Product <b>{name}</b> added successfully!", parse_mode='HTML')
        send_log(f"➕ New Product Added\nName: {name}\nPlans: {plans_json}")
        logger.info(f"Admin added product: {name}")
    except Exception as e:
        logger.error(f"add_product_link error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ An error occurred: {str(e)}")

def admin_generate_redeem(message):
    try:
        amt = float(message.text.strip())
        if amt <= 0:
            safe_send_message(message.chat.id, "Amount must be positive.")
            return
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
        conn = sqlite3.connect('store.db')
        c = conn.cursor()
        c.execute("INSERT INTO redeem_codes (code, amount, used_by, is_used) VALUES (?, ?, ?, ?)",
                  (code, amt, 0, 0))
        conn.commit()
        conn.close()
        safe_send_message(message.chat.id, f"🎫 Redeem Code\n\n<code>{code}</code>\nAmount: ₹{amt}", parse_mode='HTML')
        send_log(f"🎫 New Redeem Code Generated\nCode: <code>{code}</code>\nAmount: ₹{amt}")
        logger.info(f"Admin generated redeem code: {code}")
    except ValueError:
        safe_send_message(message.chat.id, "Invalid amount.")
    except Exception as e:
        logger.error(f"admin_generate_redeem error: {e}", exc_info=True)
        safe_send_message(message.chat.id, f"❌ An error occurred: {str(e)}")

def check_group():
    try:
        bot.send_chat_action(GROUP_ID, action='typing')
        logger.info(f"✅ Group {GROUP_ID} is accessible.")
    except Exception as e:
        logger.error(f"❌ Cannot access group {GROUP_ID}: {e}")

if __name__ == "__main__":
    logger.info("🤖 SIYA PANEL STORE BOT starting!")
    print("Siya Panel Bot started")
    try:
        check_group()
        bot.infinity_polling()
    except Exception as e:
        logger.error(f"Bot crashed: {e}", exc_info=True)
        print(f"ERROR: {e}")