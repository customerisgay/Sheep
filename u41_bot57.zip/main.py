# ========================================
# Requires: aiogram >= 3.20
#   pip install -U "aiogram>=3.20"
# ========================================

import asyncio
import logging
import html
import json
import re
import sqlite3
import random
import qrcode
from io import BytesIO
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, BufferedInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

# ========================================
# CONFIGURATION
# ========================================

BOT_TOKEN        = "8873893011:AAE_deEcoAdHRgjeXmMPfo8KfgZC0EemG5U"
ADMIN_ID         = 8207882848
BOT_USERNAME     = "Sriyapanelsbot"
CHANNEL_LINK     = "https://t.me/Sriyapanels"
UPI_ID           = "chinupatra23@axl"
UPI_NAME         = "pradip kumar patra"
SUPPORT_USERNAME = "@sii_3s"
YOUTUBE_LINK     = "https://youtube.com"

# ========================================
# PREMIUM EMOJI HELPER
# ========================================

_E = {
    # ⚠️ IMPORTANT PRECONDITIONS for these IDs to actually render (Bot API 9.4):
    #  1. The Telegram account that owns this bot (via @BotFather) must have an
    #     ACTIVE Telegram Premium subscription — OR the bot must have a paid
    #     Fragment username. Without one of these, EVERY custom emoji (in
    #     message text via e(), and on buttons via icon_custom_emoji_id) will
    #     be rejected by Telegram with an error like DOCUMENT_INVALID or
    #     CUSTOM_EMOJI_ID_INVALID — which is exactly what was happening.
    #  2. Every ID below must be a REAL custom-emoji sticker ID that currently
    #     exists on Telegram. Forward any message containing the emoji you
    #     want to @JsonDumpBot (or similar) to get its real custom_emoji_id —
    #     a made-up/incorrect ID fails the same way even with Premium active.
    "cart":     "6021352786724133912",
    "arrow":    "5809840662601802452",
    "crown":    "5816539591812845173",
    "link":     "5767297774584339394",
    "forward":  "5803244322979585969",
    "shop":     "5312361253610475399",
    # ✅ verified real IDs (platform icons)
    "android":  "6008224489039466126",
    "ios":      "6273556792513402505",
    "pc":       "6005916300600152073",
    "download": "5406745015365943482",
    "money":    "5417924076503062111",
    "gear":     "5828049232287767432",
    "fire":     "5798436339019947373",
    "question": "5314504236132747481",
    "globe":    "5956045399511797140",
    "gift":     "5785281906459283269",
    "check":    "6028565819225542441",
    # Added — these were missing entirely and caused KeyError crashes on
    # Buy Plan / Payment Screenshot / Stats screens. Placeholder IDs reused
    # from "check" for now — replace with real IDs via @JsonDumpBot when
    # you get a chance (see note above _E).
    "chart":    "6028565819225542441",
    "camera":   "6028565819225542441",
    "clock":    "6028565819225542441",
    "cross":    "6032606743500951856",
    "bulb":     "5472146462362048818",
    "lock":     "5393302369024882368",
    "dev":      "5190498849440931467",
    "text":     "5841276284155467413",
    "wallet":   "5990147899403539264",
    "calendar": "6014861794059752708",
    "tools":    "5449428597922079323",
    "card":     "6019224342666157570",
    "point":    "5470177992950946662",
    "warning":  "5447644880824181073",
    "vote":     "5359741159566484212",
    "idcard":   "5422683699130933153",
    "moon":     "5289930954410836372",
    "hourglass":"5451732530048802485",
    "plus":     "6032733629719777782",  # ✅ verified real ID
    "minus":    "5839277185022866153",
    "edit":     "5334673106202010226",  # ✅ verified real ID
    "trash":    "5445267414562389170",  # ✅ verified real ID
    "coin":     "5379600444098093058",
    "pen":      "5197269100878907942",  # ✅ verified real ID
    "cash":     "5990147899403539264",
}

def e(name: str, fb: str = "•") -> str:
    """For MESSAGE TEXT only (requires parse_mode='HTML'). Renders the premium
    animated emoji for Telegram Premium users, and falls back to `fb` for
    everyone else. Telegram REQUIRES a fallback char here — you cannot omit
    it, even if you never want it shown (see note below)."""
    return f'<tg-emoji emoji-id="{_E[name]}">{fb}</tg-emoji>'

# NOTE: Button labels no longer use any plain-text emoji prefix. Every
# InlineKeyboardButton instead sets icon_custom_emoji_id=_E["..."] directly
# (Bot API 9.4+), so only the premium icon renders next to the label — no
# duplicate plain emoji.

# ========================================
# DATABASE
# ========================================

DB = "store.db"

def _conn():
    return sqlite3.connect(DB)

def init_db():
    con = _conn(); c = con.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT, first_name TEXT,
        balance REAL DEFAULT 0,
        join_date TEXT, referral_code TEXT, referred_by INTEGER
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT, category TEXT,
        price_1d REAL, price_7d REAL, price_31d REAL,
        stock INTEGER DEFAULT 1, description TEXT,
        plans_json TEXT DEFAULT '[]'
    )''')
    try:
        c.execute("ALTER TABLE products ADD COLUMN plans_json TEXT DEFAULT '[]'")
    except sqlite3.OperationalError:
        pass  # column already exists

    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, product_id INTEGER, plan TEXT,
        amount REAL, status TEXT DEFAULT 'completed',
        order_date TEXT, key_delivered INTEGER DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, amount REAL, type TEXT,
        description TEXT, date TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS deposits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, amount REAL,
        screenshot_id TEXT, status TEXT DEFAULT 'pending', date TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS referrals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        referrer_id INTEGER, referred_id INTEGER,
        commission REAL DEFAULT 0, date TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS daily_gift (
        user_id INTEGER PRIMARY KEY,
        last_spin_date TEXT, won_amount REAL DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY, value TEXT
    )''')

    c.execute("SELECT value FROM settings WHERE key='catalog_v2_seeded'")
    already_seeded = c.fetchone()
    if not already_seeded:
        c.execute("DELETE FROM products")
        # (name, category, [[label, price], ...], stock, description)
        prods = [
            ("DRIP CLIENT MOD ( BEST SELLER💫 )", "ANDROID", [
                ["1 day", 90], ["3 day", 180], ["7 day", 340], ["15 day", 590], ["30 day", 900]
            ], 1, ""),
            ("TM PANEL (non root)", "ANDROID", [
                ["1 day", 80], ["7 day", 160], ["15 day", 330], ["31 day", 550], ["Permanent", 1200]
            ], 1, ""),
            ("HG CHEATS", "ANDROID", [
                ["1 day", 170], ["10 day", 450], ["31 day", 800]
            ], 1, ""),
            ("ANGRY MOD (root)", "ANDROID", [
                ["1 day", 80], ["7 day", 150], ["15 day", 300], ["31 day", 550]
            ], 1, ""),
            ("DRIP CLIENT PROXY PANEL", "ANDROID", [
                ["1 day", 90], ["3 day", 170], ["7 day", 290], ["31 day", 680]
            ], 1, ""),
            ("BR MOOD (root)", "ANDROID", [
                ["7 day", 200], ["15 day", 500], ["31 day", 920]
            ], 1, ""),
            ("PATO TEAM", "ANDROID", [
                ["3 day", 300], ["7 day", 550], ["15 day", 800]
            ], 1, ""),
            ("MIGUL IOS PRO PANEL", "IOS", [
                ["1 day", 290], ["7 day", 700], ["31 day (+1 Year Xbox Free)", 1500]
            ], 1, ""),
            ("FLOURITE IOS PANEL", "IOS", [
                ["1 day", 300], ["7 day", 850], ["31 day", 2000]
            ], 1, ""),
            ("Gbox & Esign Certificate", "IOS", [
                ["1 year", 900]
            ], 1, ""),
            ("Proxy Panel", "IOS", [
                ["7 day", 600], ["31 day", 900]
            ], 1, ""),
            ("BR MOD PC", "PC", [
                ["10 day", 500], ["31 day", 900]
            ], 1, ""),
        ]
        c.executemany(
            "INSERT INTO products (name,category,price_1d,price_7d,price_31d,stock,description,plans_json) VALUES (?,?,0,0,0,?,?,?)",
            [(name, cat, stock, desc, json.dumps(plans)) for name, cat, plans, stock, desc in prods]
        )
        c.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('catalog_v2_seeded','1')")

    c.execute("INSERT OR IGNORE INTO settings (key,value) VALUES ('maintenance','0')")
    con.commit(); con.close()

def get_user(uid, uname=None, fname=None):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (uid,))
    row = c.fetchone()
    if not row:
        rc = f"ref{uid}"
        c.execute(
            "INSERT INTO users (user_id,username,first_name,balance,join_date,referral_code) VALUES (?,?,?,0,?,?)",
            (uid, uname or "", fname or "", datetime.now().isoformat(), rc)
        )
        con.commit()
        row = (uid, uname or "", fname or "", 0.0, datetime.now().isoformat(), rc, None)
    con.close(); return row

def get_balance(uid) -> float:
    con = _conn(); c = con.cursor()
    c.execute("SELECT balance FROM users WHERE user_id=?", (uid,))
    r = c.fetchone(); con.close()
    return float(r[0]) if r else 0.0

def update_balance(uid, delta: float):
    con = _conn(); c = con.cursor()
    c.execute("UPDATE users SET balance=balance+? WHERE user_id=?", (delta, uid))
    con.commit(); con.close()

def get_all_users():
    con = _conn(); c = con.cursor()
    c.execute("SELECT user_id FROM users")
    ids = [r[0] for r in c.fetchall()]; con.close(); return ids

def get_referred_by(uid):
    con = _conn(); c = con.cursor()
    c.execute("SELECT referred_by FROM users WHERE user_id=?", (uid,))
    r = c.fetchone(); con.close()
    return r[0] if r else None

def set_referred_by(uid, referrer_id):
    con = _conn(); c = con.cursor()
    c.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, uid))
    con.commit(); con.close()

def get_products():
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM products"); rows = c.fetchall(); con.close(); return rows

def get_product(pid):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM products WHERE id=?", (pid,))
    r = c.fetchone(); con.close(); return r

def update_stock(pid, stock: int):
    con = _conn(); c = con.cursor()
    c.execute("UPDATE products SET stock=? WHERE id=?", (stock, pid))
    con.commit(); con.close()

def add_product(name, category, plans, stock, description):
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT INTO products (name,category,price_1d,price_7d,price_31d,stock,description,plans_json) VALUES (?,?,0,0,0,?,?,?)",
        (name, category, stock, description, json.dumps(plans))
    )
    pid = c.lastrowid; con.commit(); con.close(); return pid

def delete_product(pid):
    con = _conn(); c = con.cursor()
    c.execute("DELETE FROM products WHERE id=?", (pid,))
    con.commit(); con.close()

def update_product(pid, name, category, plans, stock, description):
    con = _conn(); c = con.cursor()
    c.execute(
        "UPDATE products SET name=?, category=?, plans_json=?, stock=?, description=? WHERE id=?",
        (name, category, json.dumps(plans), stock, description, pid)
    )
    con.commit(); con.close()

def get_plans(p) -> list:
    """p is a product row. Returns [[label, price], ...]. Falls back cleanly
    if plans_json is empty/missing (shouldn't happen after migration)."""
    try:
        plans = json.loads(p[8]) if len(p) > 8 and p[8] else []
    except (ValueError, TypeError):
        plans = []
    return plans

def format_plans_text(plans: list) -> str:
    """[[label, price], ...] -> 'label - price' per line, for showing/editing."""
    return "\n".join(f"{label} - {price:.0f}" for label, price in plans)

def parse_plans_text(text: str) -> list:
    """'label - price' per line -> [[label, price], ...]. Raises ValueError
    on a malformed line so the caller can ask the admin to retry."""
    plans = []
    for line in text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        if "-" not in line:
            raise ValueError(f"Line missing ' - ': {line}")
        label, price_s = line.rsplit("-", 1)
        plans.append([label.strip(), float(price_s.strip())])
    if not plans:
        raise ValueError("No plans found")
    return plans

def get_products_by_category(category):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM products WHERE category=?", (category,))
    rows = c.fetchall(); con.close(); return rows

def get_categories():
    con = _conn(); c = con.cursor()
    c.execute("SELECT DISTINCT category FROM products")
    rows = [r[0] for r in c.fetchall()]; con.close(); return rows

def get_all_products():
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM products ORDER BY category, id")
    rows = c.fetchall(); con.close(); return rows

def add_order(uid, pid, plan, amount):
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT INTO orders (user_id,product_id,plan,amount,status,order_date) VALUES (?,?,?,?,'completed',?)",
        (uid, pid, plan, amount, datetime.now().isoformat())
    )
    oid = c.lastrowid; con.commit(); con.close(); return oid

def get_user_orders(uid):
    con = _conn(); c = con.cursor()
    c.execute(
        "SELECT o.*,p.name FROM orders o JOIN products p ON o.product_id=p.id "
        "WHERE o.user_id=? ORDER BY o.order_date DESC LIMIT 10", (uid,)
    )
    rows = c.fetchall(); con.close(); return rows

def add_tx(uid, amount, tx_type, desc):
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT INTO transactions (user_id,amount,type,description,date) VALUES (?,?,?,?,?)",
        (uid, amount, tx_type, desc, datetime.now().isoformat())
    )
    con.commit(); con.close()

def add_deposit(uid, amount) -> int:
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT INTO deposits (user_id,amount,status,date) VALUES (?,?,'pending',?)",
        (uid, amount, datetime.now().isoformat())
    )
    did = c.lastrowid; con.commit(); con.close(); return did

def get_deposit(did):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM deposits WHERE id=?", (did,))
    r = c.fetchone(); con.close(); return r

def update_deposit(did, status, screenshot_id=None):
    con = _conn(); c = con.cursor()
    if screenshot_id:
        c.execute("UPDATE deposits SET status=?,screenshot_id=? WHERE id=?", (status, screenshot_id, did))
    else:
        c.execute("UPDATE deposits SET status=? WHERE id=?", (status, did))
    con.commit(); con.close()

def get_user_deposits(uid):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM deposits WHERE user_id=? ORDER BY date DESC LIMIT 10", (uid,))
    rows = c.fetchall(); con.close(); return rows

def get_pending_deposits():
    con = _conn(); c = con.cursor()
    c.execute(
        "SELECT d.*,u.username,u.first_name FROM deposits d "
        "JOIN users u ON d.user_id=u.user_id WHERE d.status='pending' ORDER BY d.date DESC"
    )
    rows = c.fetchall(); con.close(); return rows

def add_referral(referrer, referred):
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT INTO referrals (referrer_id,referred_id,date) VALUES (?,?,?)",
        (referrer, referred, datetime.now().isoformat())
    )
    con.commit(); con.close()

def get_referral_count(uid) -> int:
    con = _conn(); c = con.cursor()
    c.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id=?", (uid,))
    n = c.fetchone()[0]; con.close(); return n

def get_daily_gift(uid):
    con = _conn(); c = con.cursor()
    c.execute("SELECT * FROM daily_gift WHERE user_id=?", (uid,))
    r = c.fetchone(); con.close(); return r

def update_daily_gift(uid, amount):
    con = _conn(); c = con.cursor()
    c.execute(
        "INSERT OR REPLACE INTO daily_gift (user_id,last_spin_date,won_amount) VALUES (?,?,?)",
        (uid, datetime.now().isoformat(), amount)
    )
    con.commit(); con.close()

def get_maintenance() -> bool:
    con = _conn(); c = con.cursor()
    c.execute("SELECT value FROM settings WHERE key='maintenance'")
    r = c.fetchone(); con.close()
    return r[0] == '1' if r else False

def set_maintenance(on: bool):
    con = _conn(); c = con.cursor()
    c.execute("UPDATE settings SET value=? WHERE key='maintenance'", ('1' if on else '0',))
    con.commit(); con.close()

def get_stats() -> dict:
    con = _conn(); c = con.cursor()
    def q(sql):
        c.execute(sql); return c.fetchone()[0] or 0
    s = {
        "total_users":    q("SELECT COUNT(*) FROM users"),
        "total_orders":   q("SELECT COUNT(*) FROM orders"),
        "total_revenue":  q("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='completed'"),
        "pending_orders": q("SELECT COUNT(*) FROM orders WHERE status='pending'"),
        "pending_deps":   q("SELECT COUNT(*) FROM deposits WHERE status='pending'"),
        "today_orders":   q("SELECT COUNT(*) FROM orders WHERE order_date>=datetime('now','-1 day')"),
        "today_revenue":  q("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='completed' AND order_date>=datetime('now','-1 day')"),
        "total_products": q("SELECT COUNT(*) FROM products"),
    }
    con.close(); return s

# ========================================
# UPI QR GENERATOR
# ========================================

def make_qr(amount: float) -> BufferedInputFile:
    url = f"upi://pay?pa={UPI_ID}&pn={UPI_NAME}&am={amount:.2f}&cu=INR"
    qr  = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(url); qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    bio = BytesIO(); img.save(bio, "PNG"); bio.seek(0)
    return BufferedInputFile(bio.read(), filename="payment_qr.png")

# ========================================
# SAFE EDIT
# ========================================

async def safe_edit(msg: types.Message, text: str, markup=None):
    try:
        await msg.edit_text(text, reply_markup=markup, parse_mode="HTML")
    except Exception:
        try:
            await msg.delete()
        except Exception:
            pass
        await bot.send_message(
            chat_id=msg.chat.id,
            text=text,
            reply_markup=markup,
            parse_mode="HTML"
        )

async def safe_answer(cb: types.CallbackQuery, text: str = "", show_alert: bool = False):
    try:
        await cb.answer(text, show_alert=show_alert)
    except Exception:
        pass

# ========================================
# BOT & DISPATCHER
# ========================================

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp  = Dispatcher()

# ========================================
# AUTO-FALLBACK FOR BAD CUSTOM EMOJI IDs
# ========================================
# Not all 36 IDs in _E are guaranteed to be real/valid Telegram custom-emoji
# documents. Telegram checks each one individually, so ANY single request
# that references a bad ID fails with DOCUMENT_INVALID — even if every other
# request (which happens to only use good IDs) works fine. That's exactly
# why some admin buttons worked and others didn't: it was never all-or-
# nothing, it was per-ID.
#
# Instead of hunting down which of the 36 IDs are bad one by one, this
# session middleware wraps EVERY outgoing Telegram API call: if a request
# is rejected because of a bad custom emoji, it strips the <tg-emoji> tags
# from the text/caption and removes icon_custom_emoji_id from any buttons,
# then retries once automatically. So the admin panel (and everything else)
# always works — premium icons show wherever the ID is actually valid, and
# silently fall back to plain text/no icon wherever it isn't.

from aiogram.exceptions import TelegramBadRequest

_TG_EMOJI_RE = re.compile(r'<tg-emoji emoji-id="\d+">(.*?)</tg-emoji>')

def _strip_custom_emoji_text(text: str) -> str:
    return _TG_EMOJI_RE.sub(r'\1', text)

def _strip_button_icons(markup) -> bool:
    changed = False
    rows = getattr(markup, "inline_keyboard", None) or getattr(markup, "keyboard", None)
    if not rows:
        return changed
    for row in rows:
        for btn in row:
            if getattr(btn, "icon_custom_emoji_id", None):
                btn.icon_custom_emoji_id = None
                changed = True
    return changed

@bot.session.middleware()
async def emoji_fallback_middleware(make_request, bot, method):
    try:
        return await make_request(bot, method)
    except TelegramBadRequest as err:
        msg = str(err)
        if "DOCUMENT_INVALID" not in msg and "CUSTOM_EMOJI" not in msg.upper():
            raise

        changed = False
        for field in ("text", "caption"):
            val = getattr(method, field, None)
            if val and "<tg-emoji" in val:
                setattr(method, field, _strip_custom_emoji_text(val))
                changed = True
        markup = getattr(method, "reply_markup", None)
        if markup is not None and _strip_button_icons(markup):
            changed = True

        if not changed:
            raise

        logging.warning(
            f"Bad custom-emoji ID rejected by Telegram on {method.__class__.__name__} "
            f"({msg}) — retried without it."
        )
        return await make_request(bot, method)

# ========================================
# GLOBAL ERROR HANDLER (final safety net)
# ========================================
# Covers anything the middleware above doesn't (non-emoji errors, etc.) so
# a handler crash never results in silence — the user always gets a reply.

@dp.errors()
async def global_error_handler(event: types.ErrorEvent):
    logging.exception("Unhandled error while processing update", exc_info=event.exception)

    chat_id = None
    upd = event.update
    if upd.callback_query:
        chat_id = upd.callback_query.from_user.id
    elif upd.message:
        chat_id = upd.message.from_user.id

    if chat_id is None:
        return True

    try:
        await bot.send_message(chat_id, "⚠️ Something went wrong processing that action. Please try again.")
    except Exception:
        pass
    return True

# ========================================
# FSM STATES
# ========================================

class DS(StatesGroup):
    custom_amount = State()
    screenshot    = State()

class AS(StatesGroup):
    broadcast      = State()
    balance_adjust = State()

class PS(StatesGroup):
    add_name       = State()
    add_platform   = State()
    add_plans      = State()
    add_stock      = State()
    add_desc       = State()
    edit_select    = State()
    edit_name      = State()
    edit_platform  = State()
    edit_plans     = State()
    edit_stock     = State()
    edit_desc      = State()
    delete_confirm = State()

# ========================================
# COLORFUL KEYBOARD BUILDERS WITH PREMIUM EMOJIS
# ========================================

def kb_main():
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Buy Now',
        callback_data="buy_now",
        icon_custom_emoji_id=_E["cart"],
        style="success",
    ))
    b.row(
        InlineKeyboardButton(
            text='Check Update',
            callback_data="check_update",
            icon_custom_emoji_id=_E["download"],
            style="success",
        ),
        InlineKeyboardButton(
            text='Add Balance',
            callback_data="add_balance",
            icon_custom_emoji_id=_E["cash"],
            style="success",
        ),
    )
    b.row(InlineKeyboardButton(
        text='My Profile + All History',
        callback_data="my_profile",
        icon_custom_emoji_id=_E["gear"],
        style="primary",
    ))
    b.row(
        InlineKeyboardButton(
            text='Refer And Earn',
            callback_data="refer_earn",
            icon_custom_emoji_id=_E["fire"],
            style="primary",
        ),
        InlineKeyboardButton(
            text='How To Use Bot',
            callback_data="how_to_use",
            icon_custom_emoji_id=_E["question"],
            style="primary",
        ),
    )
    b.row(
        InlineKeyboardButton(
            text='Support',
            callback_data="support",
            icon_custom_emoji_id=_E["globe"],
            style="primary",
        ),
        InlineKeyboardButton(
            text='Daily Gift',
            callback_data="daily_gift",
            icon_custom_emoji_id=_E["gift"],
            style="success",
        ),
    )
    return b.as_markup()

def kb_back():
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Back to Menu',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_back_admin():
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Back to Admin',
        callback_data="back_admin",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

PLATFORMS = [
    ("ANDROID", "ANDROID", "android"),
    ("IOS",     "IOS PANELS", "ios"),
    ("PC",      "PC PANEL", "pc"),
]

def kb_products():
    b = InlineKeyboardBuilder()
    for code, label, icon_key in PLATFORMS:
        b.row(InlineKeyboardButton(
            text=label,
            callback_data=f"cat_{code}",
            icon_custom_emoji_id=_E[icon_key],
            style="primary",
        ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_category_products(category):
    b = InlineKeyboardBuilder()
    products = get_products_by_category(category)
    for p in products:
        in_stock = p[6] == 1
        b.row(InlineKeyboardButton(
            text=f'{p[1]}',
            callback_data=f"product_{p[0]}",
            icon_custom_emoji_id=_E["check"] if in_stock else _E["cross"],
            style="success" if in_stock else "danger",
        ))
    b.row(InlineKeyboardButton(
        text='Back to Categories',
        callback_data="buy_now",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_pricing(pid, plans: list):
    b = InlineKeyboardBuilder()
    for idx, (label, price) in enumerate(plans):
        b.row(InlineKeyboardButton(
            text=f'{label} — ₹{price:.0f}',
            callback_data=f"buy_{pid}_{idx}",
            icon_custom_emoji_id=_E["pen"],
            style="primary",
        ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="buy_now",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_deposit():
    b = InlineKeyboardBuilder()
    for amt in [100, 200, 500, 1000]:
        b.row(InlineKeyboardButton(
            text=f'₹{amt}',
            callback_data=f"dep_amt_{amt}",
            icon_custom_emoji_id=_E["cash"],
            style="success",
        ))
    b.row(InlineKeyboardButton(
        text='Custom Amount',
        callback_data="dep_custom",
        icon_custom_emoji_id=_E["pen"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_qr(dep_id, amt_paise: int):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Confirm Payment — Send Screenshot',
        callback_data=f"confirm_pay_{dep_id}",
        icon_custom_emoji_id=_E["check"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='Payment Expired? Get New QR',
        callback_data=f"new_qr_{dep_id}_{amt_paise}",
        icon_custom_emoji_id=_E["hourglass"],
        style="danger",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="add_balance",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_admin():
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Stats Dashboard',
        callback_data='adm_stats',
        icon_custom_emoji_id=_E["vote"],
        style="primary",
    ))
    b.row(
        InlineKeyboardButton(
            text='Maintenance ON',
            callback_data='adm_maint_on',
            icon_custom_emoji_id=_E["warning"],
            style="danger",
        ),
        InlineKeyboardButton(
            text='Maintenance OFF',
            callback_data='adm_maint_off',
            icon_custom_emoji_id=_E["check"],
            style="success",
        ),
    )
    b.row(InlineKeyboardButton(
        text='Stock Management',
        callback_data='adm_stock',
        icon_custom_emoji_id=_E["tools"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Manage Products',
        callback_data='adm_products',
        icon_custom_emoji_id=_E["edit"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Pending Deposits',
        callback_data='adm_deps',
        icon_custom_emoji_id=_E["cash"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='Broadcast',
        callback_data='adm_broadcast',
        icon_custom_emoji_id=_E["forward"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Adjust Balance',
        callback_data='adm_balance',
        icon_custom_emoji_id=_E["money"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='User Count',
        callback_data='adm_users',
        icon_custom_emoji_id=_E["dev"],
        style="primary",
    ))
    return b.as_markup()

def kb_product_manage():
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Add New Product',
        callback_data='adm_product_add',
        icon_custom_emoji_id=_E["plus"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='Edit Product',
        callback_data='adm_product_edit',
        icon_custom_emoji_id=_E["edit"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Delete Product',
        callback_data='adm_product_delete',
        icon_custom_emoji_id=_E["trash"],
        style="danger",
    ))
    b.row(InlineKeyboardButton(
        text='Toggle Stock',
        callback_data='adm_stock',
        icon_custom_emoji_id=_E["tools"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back to Admin',
        callback_data='back_admin',
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_product_list(action):
    b = InlineKeyboardBuilder()
    products = get_all_products()
    for p in products:
        plans = get_plans(p)
        price_note = f'from ₹{min(pr for _, pr in plans):.0f}' if plans else 'no plans set'
        b.row(InlineKeyboardButton(
            text=f'{p[1]} ({price_note})',
            callback_data=f"prod_{action}_{p[0]}",
            icon_custom_emoji_id=_E["shop"],
            style="primary",
        ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="adm_products",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_product_edit_options(pid):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Edit Name',
        callback_data=f"pedit_name_{pid}",
        icon_custom_emoji_id=_E["pen"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Change Platform',
        callback_data=f"pedit_cat_{pid}",
        icon_custom_emoji_id=_E["pen"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Edit Pricing Plans',
        callback_data=f"pedit_plans_{pid}",
        icon_custom_emoji_id=_E["money"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='Edit Stock',
        callback_data=f"pedit_stock_{pid}",
        icon_custom_emoji_id=_E["tools"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Edit Description',
        callback_data=f"pedit_desc_{pid}",
        icon_custom_emoji_id=_E["text"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data='adm_products',
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_platform_select(pid=None, prefix="setcat"):
    """Reusable platform picker — used both when adding a new product and
    when changing an existing product's platform. pid=None means 'adding'."""
    b = InlineKeyboardBuilder()
    for code, label, icon_key in PLATFORMS:
        cb_data = f"{prefix}_{code}" if pid is None else f"{prefix}_{code}_{pid}"
        b.row(InlineKeyboardButton(
            text=label,
            callback_data=cb_data,
            icon_custom_emoji_id=_E[icon_key],
            style="primary",
        ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data='adm_products',
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_after_field_edit(pid):
    """Shown after any single field is edited — lets the admin keep editing
    the SAME product (jump straight back to its edit menu) instead of having
    to go Admin Home → Manage Products → find the product again."""
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Edit This Product Again',
        callback_data=f"prod_edit_{pid}",
        icon_custom_emoji_id=_E["pen"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back to Admin',
        callback_data="back_admin",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

def kb_stock_management():
    b = InlineKeyboardBuilder()
    products = get_products()
    for p in products:
        in_stock = p[6] == 1
        b.row(InlineKeyboardButton(
            text=f'{p[1]} ({p[2]})',
            callback_data=f"stock_toggle_{p[0]}",
            icon_custom_emoji_id=_E["check"] if in_stock else _E["cross"],
            style="success" if in_stock else "danger",
        ))
    b.row(InlineKeyboardButton(
        text='Back to Admin',
        callback_data="back_admin",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    return b.as_markup()

# ========================================
# TEXT BUILDERS WITH PREMIUM EMOJIS
# ========================================

def txt_main(balance: float) -> str:
    return (
        f'{e("shop","🏪")} <b>SPACE X PANEL</b> {e("lock","🔓")}\n'
        f'{e("forward","⏩")}\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'┝ {e("cart","🛒")} <b>Buy Now</b> : All Key Purchase & Instant Delivery\n'
        f'┝ {e("download","⬇️")} <b>Check Update</b> : Check Setup Video And Update Apk\n'
        f'┝ {e("cash","💰")} <b>Add Balance</b> : Deposit Balance & Secure Auto-Add Payment System\n'
        f'┝ {e("gear","⚙️")} <b>My Profile + All History</b> : Check Your Account Information + All History\n'
        f'┝ {e("fire","🔥")} <b>Refer And Earn</b> : Share Refer Link & Earn Money\n'
        f'┝ {e("question","⁉️")} <b>How To Use Bot</b> : View Tutorial And Work This Bot\n'
        f'┝ {e("globe","🌐")} <b>Support</b> : Bot Problem Fixed For Support Admin\n'
        f'┝ {e("gift","🎁")} <b>Daily Gift</b> : Free Spin and win random balance daily, Only one spin every 24 hours.\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("forward","⏩")}\n'
        f'{e("cash","💰")} <b>Your Balance:</b> {e("money","💰")}₹{balance:.2f}\n'
        f'{e("point","👇")} Select an option from the menu below:'
    )

def txt_admin_home() -> str:
    s = get_stats()
    maint = f'{e("warning","🔴")} ON' if get_maintenance() else f'{e("check","🟢")} OFF'
    return (
        f'{e("crown","👑")} <b>Admin Panel</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("tools","🛠")} <b>Maintenance:</b> {maint}\n'
        f'{e("dev","👥")} <b>Users:</b> {s["total_users"]}\n'
        f'{e("cart","📦")} <b>Orders:</b> {s["total_orders"]}\n'
        f'{e("money","💰")} <b>Revenue:</b> ₹{s["total_revenue"]:.2f}\n'
        f'{e("cash","💳")} <b>Pending Deposits:</b> {s["pending_deps"]}\n'
        f'{e("shop","📦")} <b>Products:</b> {s["total_products"]}\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️'
    )

def txt_stock_management() -> str:
    return (
        f'{e("tools","📦")} <b>Stock Management</b>\n\n'
        f'{e("point","👇")} Tap a product button below to toggle its stock status:\n'
        f'• {e("check","✅")} = In Stock\n'
        f'• {e("cross","❌")} = Out of Stock'
    )

# ========================================
# QR SENDER HELPER
# ========================================

async def send_qr(chat_id: int, amount: float, dep_id: int):
    expires = (datetime.now() + timedelta(minutes=5)).strftime("%H:%M")
    caption = (
        f'{e("cash","💰")} <b>UPI Payment QR</b>\n\n'
        f'{e("card","💳")} <b>Amount:</b> ₹{amount:.2f}\n'
        f'{e("lock","🔒")} <b>UPI ID:</b> <code>{UPI_ID}</code>\n'
        f'{e("calendar","🗓")} <b>Expires:</b> {expires} (5 min)\n\n'
        f'Scan QR <b>or</b> pay via UPI ID above.\n'
        f'After paying tap {e("check","✅")} <b>Confirm Payment</b>\n\n'
        f'{e("warning","⚠️")} Window expires in 5 minutes!'
    )
    amt_paise = int(amount * 100)
    await bot.send_photo(
        chat_id, make_qr(amount),
        caption=caption, reply_markup=kb_qr(dep_id, amt_paise), parse_mode="HTML"
    )

# ========================================
# /start
# ========================================

@dp.message(Command("start"))
async def cmd_start(msg: types.Message):
    u = msg.from_user
    db_user = get_user(u.id, u.username, u.first_name)

    args = msg.text.split()
    if len(args) > 1 and args[1].startswith("ref") and db_user[6] is None:
        try:
            ref_id = int(args[1][3:])
            if ref_id != u.id:
                set_referred_by(u.id, ref_id)
                add_referral(ref_id, u.id)
                try:
                    await bot.send_message(
                        ref_id,
                        f'{e("gift","🎉")} <b>New Referral!</b>\n\n'
                        f'{e("check","✅")} <b>1 user joined with your referral link!</b>\n'
                        f'{e("dev","👤")} {u.first_name}\n'
                        f'{e("money","💰")} You will earn 1% commission on their purchases!',
                        parse_mode="HTML"
                    )
                except Exception:
                    pass
        except Exception:
            pass

    if get_maintenance():
        await msg.answer(
            f'{e("tools","🛠")} <b>Bot Under Maintenance</b>\n\n'
            f'{e("forward","⏩")} We\'ll be back soon!\n'
            f'{e("link","🔗")} Updates: <a href="{CHANNEL_LINK}">Channel</a>',
            parse_mode="HTML"
        )
        return

    bal = get_balance(u.id)
    await msg.answer(txt_main(bal), reply_markup=kb_main(), parse_mode="HTML")

# ========================================
# BACK TO MAIN
# ========================================

@dp.callback_query(F.data == "back_main")
async def cb_back_main(cb: types.CallbackQuery, state: FSMContext):
    await state.clear()
    bal = get_balance(cb.from_user.id)
    await safe_edit(cb.message, txt_main(bal), kb_main())
    await safe_answer(cb)

# ========================================
# BUY NOW
# ========================================

@dp.callback_query(F.data == "buy_now")
async def cb_buy_now(cb: types.CallbackQuery):
    if get_maintenance():
        await safe_answer(cb, f'{e("tools","🛠")} Bot is under maintenance!', show_alert=True)
        return
    await safe_edit(
        cb.message,
        f'〰️ <b>PRODUCT STORE — SHOP</b> 〰️\n\n'
        f'{e("shop","🛒")} Choose a category from the list below:',
        kb_products()
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("cat_"))
async def cb_category(cb: types.CallbackQuery):
    category = cb.data.split("_")[1]
    label = next((lbl for code, lbl, _ in PLATFORMS if code == category), category)
    await safe_edit(
        cb.message,
        f'{e("cart","📦")} <b>{label}</b>\n\n'
        f'{e("check","✅")} In Stock   {e("cross","❌")} Out of Stock\n\n'
        f'Select a product:',
        kb_category_products(category)
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("product_"))
async def cb_show_product(cb: types.CallbackQuery):
    pid = int(cb.data.split("_")[1])
    p   = get_product(pid)
    if not p:
        await safe_answer(cb, f'{e("cross","❌")} Product not found!', show_alert=True)
        return
    if p[6] == 0:
        await safe_answer(cb, f'{e("cross","❌")} Out of stock!', show_alert=True)
        return
    await safe_edit(
        cb.message,
        f'{e("shop","🛒")} <b>{p[1]}</b>\n\n'
        f'{e("text","📝")} {p[7] or "Premium product"}\n\n'
        f'{e("money","💰")} <b>Select a plan:</b>',
        kb_pricing(pid, get_plans(p))
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("buy_"))
async def cb_buy_plan(cb: types.CallbackQuery):
    _, pid_s, idx_s = cb.data.split("_")
    pid    = int(pid_s)
    idx    = int(idx_s)
    p      = get_product(pid)
    if not p:
        await safe_answer(cb, f'{e("cross","❌")} Product not found!', show_alert=True)
        return

    plans = get_plans(p)
    if idx < 0 or idx >= len(plans):
        await safe_answer(cb, f'{e("cross","❌")} Plan not available!', show_alert=True)
        return
    plan_lbl, amount = plans[idx]
    amount = float(amount)
    if amount <= 0:
        await safe_answer(cb, f'{e("cross","❌")} Plan not available!', show_alert=True)
        return

    uid     = cb.from_user.id
    balance = get_balance(uid)

    if balance >= amount:
        update_balance(uid, -amount)
        oid = add_order(uid, pid, plan_lbl, amount)
        add_tx(uid, -amount, "purchase", f"Purchased {p[1]} - {plan_lbl}")

        await safe_edit(
            cb.message,
            f'{e("check","✅")} <b>Order Successful!</b>\n\n'
            f'{e("cart","📦")} <b>Product:</b> <b>{p[1]}</b>\n'
            f'{e("calendar","📅")} <b>Plan:</b> {plan_lbl}\n'
            f'{e("money","💰")} <b>Paid:</b> ₹{amount:.2f}\n'
            f'{e("idcard","🆔")} <b>Order ID:</b> #{oid}\n\n'
            f'{e("point","📤")} Send payment QR to get your key and setup.\n'
            f'{e("dev","👤")} Contact: <b>@sii_3s</b>\n\n'
            f'{e("check","✅")} <i>Key delivered instantly!</i>',
            kb_back()
        )

        try:
            await bot.send_message(
                ADMIN_ID,
                f'{e("cart","🛒")} <b>New Order!</b>\n\n'
                f'{e("dev","👤")} {html.escape(cb.from_user.first_name)} (@{cb.from_user.username or "N/A"})\n'
                f'{e("idcard","🆔")} {uid}\n'
                f'{e("cart","📦")} {p[1]}  |  {plan_lbl}\n'
                f'{e("money","💰")} ₹{amount:.2f}  |  {e("idcard","#️⃣")}{oid}',
                parse_mode="HTML"
            )
        except Exception:
            pass

        ref = get_referred_by(uid)
        if ref:
            comm = round(amount * 0.01, 2)
            update_balance(ref, comm)
            add_tx(ref, comm, "referral", f"Commission from {html.escape(cb.from_user.first_name)}")
            try:
                await bot.send_message(
                    ref,
                    f'{e("gift","🎉")} <b>Referral Commission!</b>\n\n'
                    f'{e("money","💰")} ₹{comm:.2f} from {html.escape(cb.from_user.first_name)}\'s purchase!',
                    parse_mode="HTML"
                )
            except Exception:
                pass
    else:
        needed = amount - balance
        dep_id = add_deposit(uid, amount)
        try: await cb.message.delete()
        except Exception: pass

        expires = (datetime.now() + timedelta(minutes=5)).strftime("%H:%M")
        amt_paise = int(amount * 100)
        await bot.send_photo(
            uid, make_qr(amount),
            caption=(
                f'{e("cross","❌")} <b>Insufficient Balance</b>\n\n'
                f'{e("money","💰")} Required: ₹{amount:.2f}\n'
                f'{e("coin","🪙")} Your Balance: ₹{balance:.2f}\n'
                f'{e("chart","📊")} Need ₹{needed:.2f} more\n\n'
                f'━━━━━━━━━━━━━━━━━\n'
                f'{e("cash","💵")} <b>Amount:</b> ₹{amount:.2f}\n'
                f'{e("card","🏦")} <b>UPI ID:</b> <code>{UPI_ID}</code>\n'
                f'{e("hourglass","⏳")} <b>Expires:</b> {expires} (5 min)\n'
                f'━━━━━━━━━━━━━━━━━\n\n'
                f'{e("point","👇")} After paying tap {e("check","✅")} Confirm Payment'
            ),
            reply_markup=kb_qr(dep_id, amt_paise),
            parse_mode="HTML"
        )

    await safe_answer(cb)

# ========================================
# ADD BALANCE
# ========================================

@dp.callback_query(F.data == "add_balance")
async def cb_add_balance(cb: types.CallbackQuery):
    await safe_edit(
        cb.message,
        f'{e("cash","💰")} <b>Add Balance</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("card","💳")} <b>UPI ID:</b> <code>{UPI_ID}</code>\n'
        f'{e("lock","🔒")} Secure Auto-Add Payment System\n\n'
        f'{e("point","👇")} Choose an amount:',
        kb_deposit()
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("dep_amt_"))
async def cb_dep_amount(cb: types.CallbackQuery):
    amount = float(cb.data.split("_")[2])
    uid    = cb.from_user.id
    dep_id = add_deposit(uid, amount)
    try: await cb.message.delete()
    except Exception: pass
    await send_qr(uid, amount, dep_id)
    await safe_answer(cb)

@dp.callback_query(F.data == "dep_custom")
async def cb_dep_custom(cb: types.CallbackQuery, state: FSMContext):
    await safe_edit(
        cb.message,
        f'{e("cash","💰")} <b>Custom Amount</b>\n\n{e("text","🔤")} Enter amount (min ₹50):',
        kb_back()
    )
    await state.set_state(DS.custom_amount)
    await safe_answer(cb)

@dp.message(DS.custom_amount)
async def msg_custom_amount(msg: types.Message, state: FSMContext):
    try:
        amount = float(msg.text.strip())
        if amount < 50:
            await msg.answer(f'{e("cross","❌")} Minimum ₹50. Enter again:')
            return
        await state.clear()
        dep_id = add_deposit(msg.from_user.id, amount)
        await send_qr(msg.from_user.id, amount, dep_id)
    except ValueError:
        await msg.answer(f'{e("cross","❌")} Invalid amount. Enter a number:')

@dp.callback_query(F.data.startswith("new_qr_"))
async def cb_new_qr(cb: types.CallbackQuery):
    parts     = cb.data.split("_")
    old_dep   = int(parts[2])
    amount    = int(parts[3]) / 100.0
    uid       = cb.from_user.id
    update_deposit(old_dep, "expired")
    dep_id = add_deposit(uid, amount)
    try: await cb.message.delete()
    except Exception: pass
    await send_qr(uid, amount, dep_id)
    await safe_answer(cb, f'{e("hourglass","🔄")} Fresh QR generated!')

@dp.callback_query(F.data.startswith("confirm_pay_"))
async def cb_confirm_pay(cb: types.CallbackQuery, state: FSMContext):
    dep_id = int(cb.data.split("_")[2])
    await state.update_data(deposit_id=dep_id)
    await state.set_state(DS.screenshot)
    try: await cb.message.delete()
    except Exception: pass
    await bot.send_message(
        cb.from_user.id,
        f'{e("check","✅")} <b>Almost done!</b>\n\n'
        f'{e("camera","📸")} Send your <b>payment screenshot</b> now.\n\n'
        f'{e("hourglass","⏳")} Admin will verify and credit your balance within minutes.',
        reply_markup=kb_back(), parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.message(DS.screenshot)
async def msg_screenshot(msg: types.Message, state: FSMContext):
    if not (msg.photo or msg.document):
        await msg.answer(f'{e("cross","❌")} Please send a screenshot (image)!')
        return

    data   = await state.get_data()
    dep_id = data.get("deposit_id")
    dep    = get_deposit(dep_id)
    if not dep:
        await msg.answer(f'{e("cross","❌")} Session expired. Try again.')
        await state.clear()
        return

    ss_id = msg.photo[-1].file_id if msg.photo else msg.document.file_id
    update_deposit(dep_id, "pending", ss_id)
    await state.clear()

    await msg.answer(
        f'{e("check","✅")} <b>Screenshot received!</b>\n\n'
        f'{e("money","💰")} Amount: ₹{float(dep[2]):.2f}\n'
        f'{e("idcard","🆔")} Deposit ID: #{dep_id}\n'
        f'{e("hourglass","⏳")} Admin will verify and credit soon!',
        reply_markup=kb_back(), parse_mode="HTML"
    )

    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(
            text='Approve',
            callback_data=f"dep_ok_{dep_id}",
            icon_custom_emoji_id=_E["check"],
            style="success",
        ),
        InlineKeyboardButton(
            text='Deny',
            callback_data=f"dep_no_{dep_id}",
            icon_custom_emoji_id=_E["cross"],
            style="danger",
        ),
    )
    await bot.send_photo(
        ADMIN_ID, ss_id,
        caption=(
            f'{e("cash","💳")} <b>Deposit Request</b>\n\n'
            f'{e("dev","👤")} {html.escape(msg.from_user.first_name)} (@{msg.from_user.username or "N/A"})\n'
            f'{e("idcard","🆔")} {msg.from_user.id}\n'
            f'{e("money","💰")} ₹{float(dep[2]):.2f}  |  {e("idcard","#️⃣")}{dep_id}\n'
            f'{e("calendar","📅")} {datetime.now().strftime("%d/%m/%Y %H:%M")}'
        ),
        reply_markup=b.as_markup(), parse_mode="HTML"
    )

@dp.callback_query(F.data.startswith("dep_ok_"))
async def cb_dep_approve(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    dep_id = int(cb.data.split("_")[2])
    dep    = get_deposit(dep_id)
    if not dep:
        await safe_answer(cb, f'{e("cross","❌")} Not found!', show_alert=True)
        return
    update_deposit(dep_id, "approved")
    update_balance(dep[1], float(dep[2]))
    add_tx(dep[1], float(dep[2]), "deposit", f"Deposit #{dep_id} approved")
    try:
        await cb.message.edit_caption(
            (cb.message.caption or "") + f"\n\n{e('check','✅')} <b>APPROVED</b>", parse_mode="HTML"
        )
    except Exception: pass
    try:
        await bot.send_message(
            dep[1],
            f'{e("check","✅")} <b>Deposit Approved!</b>\n\n'
            f'{e("money","💰")} ₹{float(dep[2]):.2f} credited!\n'
            f'{e("coin","🪙")} New Balance: ₹{get_balance(dep[1]):.2f}',
            parse_mode="HTML"
        )
    except Exception: pass
    await safe_answer(cb, f'{e("check","✅")} Approved!', show_alert=True)

@dp.callback_query(F.data.startswith("dep_no_"))
async def cb_dep_deny(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    dep_id = int(cb.data.split("_")[2])
    dep    = get_deposit(dep_id)
    if not dep:
        await safe_answer(cb, f'{e("cross","❌")} Not found!', show_alert=True)
        return
    update_deposit(dep_id, "denied")
    try:
        await cb.message.edit_caption(
            (cb.message.caption or "") + f"\n\n{e('cross','❌')} <b>DENIED</b>", parse_mode="HTML"
        )
    except Exception: pass
    try:
        await bot.send_message(
            dep[1],
            f'{e("cross","❌")} <b>Deposit Denied</b>\n\n'
            f'{e("money","💰")} Amount: ₹{float(dep[2]):.2f} not approved.\n'
            f'{e("dev","👤")} Contact: {SUPPORT_USERNAME}',
            parse_mode="HTML"
        )
    except Exception: pass
    await safe_answer(cb, f'{e("cross","❌")} Denied!', show_alert=True)

# ========================================
# CHECK UPDATE
# ========================================

@dp.callback_query(F.data == "check_update")
async def cb_check_update(cb: types.CallbackQuery):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Join Channel',
        url=CHANNEL_LINK,
        icon_custom_emoji_id=_E["link"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("download","⬇️")} <b>Check Updates</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("forward","📢")} Join our official channel for:\n'
        f'┝ {e("tools","🧰")} Latest updates & patches\n'
        f'┝ {e("question","⁉️")} New setup videos\n'
        f'┝ {e("bulb","💡")} Announcements\n\n'
        f'{e("point","👇")} Click below to join:',
        b.as_markup()
    )
    await safe_answer(cb)

# ========================================
# MY PROFILE
# ========================================

@dp.callback_query(F.data == "my_profile")
async def cb_my_profile(cb: types.CallbackQuery):
    uid  = cb.from_user.id
    user = get_user(uid)
    bal  = get_balance(uid)
    ords = get_user_orders(uid)
    deps = get_user_deposits(uid)
    refs = get_referral_count(uid)

    text = (
        f'{e("gear","⚙️")} <b>My Profile</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("dev","👨‍💻")} <b>Name:</b> {html.escape(cb.from_user.first_name)}\n'
        f'{e("idcard","🆔")} <b>ID:</b> {uid}\n'
        f'{e("cash","💰")} <b>Balance:</b> ₹{bal:.2f}\n'
        f'{e("fire","🔥")} <b>Referrals:</b> {refs}\n'
        f'{e("calendar","📅")} <b>Joined:</b> {user[4][:10] if user[4] else "N/A"}\n\n'
    )
    if ords:
        text += f'{e("cart","📦")} <b>Recent Orders:</b>\n'
        for o in ords[:5]:
            text += f'  ┝ {e("idcard","#️⃣")}{o[0]} {o[8]} ({o[3]}) ₹{float(o[4]):.0f} — {o[5]}\n'
        text += '\n'
    else:
        text += f'{e("cart","📦")} <b>Orders:</b> No orders yet\n\n'
    if deps:
        text += f'{e("cash","💳")} <b>Recent Deposits:</b>\n'
        for d in deps[:5]:
            text += f'  ┝ {e("idcard","#️⃣")}{d[0]} ₹{float(d[2]):.0f} — {d[4]} ({d[5][:10] if d[5] else ""})\n'
    else:
        text += f'{e("cash","💳")} <b>Deposits:</b> No deposits yet'

    await safe_edit(cb.message, text, kb_back())
    await safe_answer(cb)

# ========================================
# REFER & EARN
# ========================================

@dp.callback_query(F.data == "refer_earn")
async def cb_refer_earn(cb: types.CallbackQuery):
    uid      = cb.from_user.id
    ref_link = f"https://t.me/{BOT_USERNAME}?start=ref{uid}"
    count    = get_referral_count(uid)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Share Referral Link',
        url=f"https://t.me/share/url?url={ref_link}&text=Join+Banti+Bhaiya+Store!",
        icon_custom_emoji_id=_E["link"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("fire","🔥")} <b>Refer & Earn</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("link","🔗")} Share your referral link:\n'
        f'<code>{ref_link}</code>\n\n'
        f'┝ {e("cash","💰")} You earn <b>1% Commission</b> on every purchase!\n'
        f'┝ {e("dev","👥")} <b>Total Referrals:</b> {count}\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("bulb","💡")} Share & earn passive income!',
        b.as_markup()
    )
    await safe_answer(cb)

# ========================================
# HOW TO USE
# ========================================

@dp.callback_query(F.data == "how_to_use")
async def cb_how_to_use(cb: types.CallbackQuery):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Watch Tutorial Video',
        url=YOUTUBE_LINK,
        icon_custom_emoji_id=_E["link"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("question","⁉️")} <b>How To Use This Bot</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("card","💳")} Add balance via Banti Bhaiya Secure QR System\n'
        f'{e("cart","🛒")} Tap <b>Buy Now</b> and pick your desired product\n'
        f'{e("check","✅")} Key is delivered instantly to this chat screen\n'
        f'{e("tools","🧰")} Browse plans and checkout seamlessly\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("bulb","💡")} Watch the tutorial for a step-by-step guide!',
        b.as_markup()
    )
    await safe_answer(cb)

# ========================================
# SUPPORT
# ========================================

@dp.callback_query(F.data == "support")
async def cb_support(cb: types.CallbackQuery):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Contact Support',
        url=f"https://t.me/{SUPPORT_USERNAME.lstrip('@')}",
        icon_custom_emoji_id=_E["dev"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("globe","🌐")} <b>Support</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("tools","🛟")} Contact our support admin:\n\n'
        f'{e("dev","👤")} <b>Username:</b> {SUPPORT_USERNAME}\n\n'
        f'We help with:\n'
        f'┝ {e("cash","💳")} Payment issues\n'
        f'┝ {e("tools","🔧")} Product problems\n'
        f'┝ {e("gear","⚙️")} Technical support\n'
        f'┝ {e("question","❓")} Any queries\n\n'
        f'{e("hourglass","⏳")} Response within a few hours',
        b.as_markup()
    )
    await safe_answer(cb)

# ========================================
# DAILY GIFT
# ========================================

@dp.callback_query(F.data == "daily_gift")
async def cb_daily_gift(cb: types.CallbackQuery):
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Spin Now!',
        callback_data="do_spin",
        icon_custom_emoji_id=_E["gift"],
        style="success",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("gift","🎁")} <b>Daily Lucky Spin Wheel</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'Spin the wheel once every 24 hours and win free balance credited instantly!\n\n'
        f'┝ {e("coin","🪙")} <b>Winning Range:</b> ₹0.01 to ₹1.00\n'
        f'┝ {e("hourglass","⏳")} <b>Spin Limit:</b> 1 spin per 24 hours\n\n'
        f'{e("point","👇")} Click the button below to try your luck:',
        b.as_markup()
    )
    await safe_answer(cb)

@dp.callback_query(F.data == "do_spin")
async def cb_do_spin(cb: types.CallbackQuery):
    uid  = cb.from_user.id
    gift = get_daily_gift(uid)

    if gift:
        last = datetime.fromisoformat(gift[1])
        diff = datetime.now() - last
        if diff < timedelta(hours=24):
            rem  = timedelta(hours=24) - diff
            h    = int(rem.total_seconds() // 3600)
            m    = int((rem.total_seconds() % 3600) // 60)
            await safe_answer(cb, f"{e('hourglass','⏳')} Come back in {h}h {m}m!", show_alert=True)
            return

    amount = round(random.uniform(0.01, 1.00), 2)
    update_daily_gift(uid, amount)
    update_balance(uid, amount)
    add_tx(uid, amount, "daily_gift", "Daily spin reward")
    new_bal = get_balance(uid)

    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_main",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("gift","🎁")} <b>Daily Gift Spin Winner!</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("point","🎯")} You won a randomized claim of:\n'
        f'{e("coin","🪙")} <b>₹{amount:.2f}</b>\n\n'
        f'{e("cash","💰")} Updated Wallet: {e("coin","🪙")} ₹{new_bal:.2f}\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("hourglass","⏳")} Come back in 24 hours for another spin!',
        b.as_markup()
    )
    await safe_answer(cb, f"{e('gift','🎉')} You won ₹{amount:.2f}!", show_alert=True)

# ========================================
# ADMIN PANEL
# ========================================

@dp.message(Command("admin"))
async def cmd_admin(msg: types.Message):
    if msg.from_user.id != ADMIN_ID: return
    await msg.answer(txt_admin_home(), reply_markup=kb_admin(), parse_mode="HTML")

@dp.callback_query(F.data == "back_admin")
async def cb_back_admin(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID: return
    await state.clear()
    await safe_edit(cb.message, txt_admin_home(), kb_admin())
    await safe_answer(cb)

@dp.callback_query(F.data == "adm_stats")
async def cb_adm_stats(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    s = get_stats()
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Refresh',
        callback_data='adm_stats',
        icon_custom_emoji_id=_E["hourglass"],
        style="primary",
    ))
    b.row(InlineKeyboardButton(
        text='Back',
        callback_data="back_admin",
        icon_custom_emoji_id=_E["arrow"],
        style="danger",
    ))
    await safe_edit(
        cb.message,
        f'{e("vote","📊")} <b>Bot Statistics</b>\n\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("dev","👥")} <b>Total Users:</b> {s["total_users"]}\n'
        f'{e("cart","📦")} <b>Total Orders:</b> {s["total_orders"]}\n'
        f'{e("money","💰")} <b>Total Revenue:</b> ₹{s["total_revenue"]:.2f}\n'
        f'{e("hourglass","⏳")} <b>Pending Orders:</b> {s["pending_orders"]}\n'
        f'{e("cash","💳")} <b>Pending Deposits:</b> {s["pending_deps"]}\n'
        f'{e("shop","📦")} <b>Total Products:</b> {s["total_products"]}\n'
        f'{e("calendar","📅")} <b>Today\'s Orders:</b> {s["today_orders"]}\n'
        f'{e("chart","📈")} <b>Today\'s Revenue:</b> ₹{s["today_revenue"]:.2f}\n'
        f'〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️\n'
        f'{e("clock","🕐")} {datetime.now().strftime("%d/%m %H:%M")}',
        b.as_markup()
    )
    await safe_answer(cb)

@dp.callback_query(F.data.in_({"adm_maint_on", "adm_maint_off"}))
async def cb_maintenance(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    on = cb.data == "adm_maint_on"
    set_maintenance(on)
    await safe_answer(cb, f"{e('warning','🔴') if on else e('check','🟢')} {'Maintenance ON' if on else 'Maintenance OFF'}", show_alert=True)
    await safe_edit(cb.message, txt_admin_home(), kb_admin())

# ========================================
# STOCK MANAGEMENT
# ========================================

@dp.callback_query(F.data == "adm_stock")
async def cb_adm_stock(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=txt_stock_management(),
        reply_markup=kb_stock_management(),
        parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("stock_toggle_"))
async def cb_toggle_stock(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    pid = int(cb.data.split("_")[2])
    p = get_product(pid)
    if not p:
        await safe_answer(cb, f'{e("cross","❌")} Product not found!', show_alert=True)
        return

    new_stock = 0 if p[6] == 1 else 1
    update_stock(pid, new_stock)

    status_text = f"{e('check','✅')} IN STOCK" if new_stock else f"{e('cross','❌')} OUT OF STOCK"
    await safe_answer(cb, f"{status_text}: {p[1]}", show_alert=True)

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=txt_stock_management(),
        reply_markup=kb_stock_management(),
        parse_mode="HTML"
    )

# ========================================
# PRODUCT MANAGEMENT - ADMIN
# ========================================

@dp.callback_query(F.data == "adm_products")
async def cb_adm_products(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("edit","📝")} <b>Product Management</b>\n\n'
        f'Manage your product catalog:\n'
        f'┝ {e("plus","➕")} Add new products\n'
        f'┝ {e("edit","✏️")} Edit existing products\n'
        f'┝ {e("trash","🗑️")} Delete products\n'
        f'┝ {e("tools","🔄")} Toggle stock (IN/OUT)',
        reply_markup=kb_product_manage(),
        parse_mode="HTML"
    )
    await safe_answer(cb)

# ── ADD PRODUCT ─────────────────────────────────────────────────────────────

@dp.callback_query(F.data == "adm_product_add")
async def cb_product_add(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("plus","➕")} <b>Add New Product</b>\n\n{e("text","📝")} Enter product name:',
        reply_markup=kb_back_admin(),
        parse_mode="HTML"
    )
    await state.set_state(PS.add_name)
    await safe_answer(cb)

@dp.message(PS.add_name)
async def msg_add_name(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    await state.update_data(name=msg.text)
    await msg.answer(
        f'{e("text","📂")} Choose a platform for this product:',
        reply_markup=kb_platform_select(pid=None, prefix="addcat")
    )
    await state.set_state(PS.add_platform)

@dp.callback_query(F.data.startswith("addcat_"), PS.add_platform)
async def cb_add_platform(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    code = cb.data.split("_", 1)[1]
    await state.update_data(category=code)
    try:
        await cb.message.delete()
    except Exception:
        pass
    await bot.send_message(
        chat_id=cb.from_user.id,
        text=(
            f'{e("money","💰")} <b>Enter pricing plans</b> — one per line, format:\n'
            f'<code>label - price</code>\n\n'
            f'Example:\n'
            f'<code>1 day - 90\n3 day - 180\n7 day - 340</code>\n\n'
            f'You can add as many lines/plans as you want.'
        ),
        reply_markup=kb_back_admin(),
        parse_mode="HTML"
    )
    await state.set_state(PS.add_plans)
    await safe_answer(cb)

@dp.message(PS.add_plans)
async def msg_add_plans(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        plans = parse_plans_text(msg.text)
    except ValueError as err:
        await msg.answer(
            f'{e("cross","❌")} Could not read that: {html.escape(str(err))}\n'
            f'Use one plan per line, format "label - price". Try again:'
        )
        return
    await state.update_data(plans=plans)
    await msg.answer(f'{e("tools","🔧")} Enter stock (1 = IN STOCK, 0 = OUT OF STOCK):')
    await state.set_state(PS.add_stock)

@dp.message(PS.add_stock)
async def msg_add_stock(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        stock = int(msg.text)
        if stock not in [0, 1]:
            await msg.answer(f'{e("cross","❌")} Enter 0 or 1 only:')
            return
        await state.update_data(stock=stock)
        await msg.answer(f'{e("text","📝")} Enter a short description (or send "-" for none):')
        await state.set_state(PS.add_desc)
    except ValueError:
        await msg.answer(f'{e("cross","❌")} Invalid number. Enter 0 or 1:')

@dp.message(PS.add_desc)
async def msg_add_desc(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    desc = "" if msg.text.strip() == "-" else msg.text
    pid = add_product(
        data['name'], data['category'], data['plans'],
        data['stock'], desc
    )
    await state.clear()
    plans_lines = "\n".join(f'   {label} — ₹{price:.0f}' for label, price in data["plans"])
    await msg.answer(
        f'{e("check","✅")} <b>Product Added!</b>\n\n'
        f'{e("cart","📦")} <b>Name:</b> {html.escape(data["name"])}\n'
        f'{e("text","📂")} <b>Platform:</b> {data["category"]}\n'
        f'{e("money","💰")} <b>Plans:</b>\n{html.escape(plans_lines)}\n'
        f'{e("tools","📊")} <b>Stock:</b> {e("check","✅") if data["stock"] else e("cross","❌")}\n'
        f'{e("idcard","🆔")} <b>Product ID:</b> #{pid}',
        reply_markup=kb_back_admin(), parse_mode="HTML"
    )

# ── EDIT PRODUCT ─────────────────────────────────────────────────────────────

@dp.callback_query(F.data == "adm_product_edit")
async def cb_product_edit(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("edit","✏️")} <b>Edit Product</b>\n\n{e("point","👇")} Select a product to edit:',
        reply_markup=kb_product_list("edit"),
        parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("prod_edit_"))
async def cb_select_edit(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    pid = int(cb.data.split("_")[2])
    p = get_product(pid)
    plans = get_plans(p)
    plans_lines = "\n".join(f'   {label} — ₹{price:.0f}' for label, price in plans) or "   (none set)"

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("edit","✏️")} <b>Edit Product</b>\n\n'
        f'{e("cart","📦")} <b>Current:</b>\n'
        f'{e("pen","📝")} Name: <b>{html.escape(p[1])}</b>\n'
        f'{e("text","📂")} Platform: {p[2]}\n'
        f'{e("money","💰")} Plans:\n{html.escape(plans_lines)}\n'
        f'{e("tools","🔧")} Stock: {e("check","✅") if p[6] else e("cross","❌")}\n'
        f'{e("text","📝")} Desc: {html.escape(p[7] or "(none)")}\n\n'
        f'{e("point","👇")} Select what to edit:',
        reply_markup=kb_product_edit_options(pid),
        parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("pedit_"))
async def cb_edit_field(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    _, field, pid_s = cb.data.split("_")
    pid = int(pid_s)
    p = get_product(pid)
    await state.update_data(pid=pid, field=field)

    try:
        await cb.message.delete()
    except Exception:
        pass

    if field == "cat":
        await bot.send_message(
            chat_id=cb.from_user.id,
            text=f'{e("pen","✏️")} <b>Editing: {html.escape(p[1])}</b>\nChoose the new platform:',
            reply_markup=kb_platform_select(pid=pid, prefix="setcat"),
            parse_mode="HTML"
        )
        await state.set_state(PS.edit_platform)
        await safe_answer(cb)
        return

    header = f'{e("pen","✏️")} <b>Editing: {html.escape(p[1])}</b>\n\n'
    prompts = {
        "name":  header + 'Enter new name:',
        "plans": header + (
            'Enter the new pricing plans — one per line, format:\n'
            '<code>label - price</code>\n\n'
            'Example:\n<code>1 day - 90\n3 day - 180\n7 day - 340</code>'
        ),
        "stock": header + 'Enter new stock (0 or 1):',
        "desc":  header + 'Enter new description (or "-" for none):',
    }
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(
        text='Cancel',
        callback_data=f"prod_edit_{pid}",
        icon_custom_emoji_id=_E["cross"],
        style="danger",
    ))
    await bot.send_message(
        chat_id=cb.from_user.id,
        text=prompts.get(field, header + 'Enter new value:'),
        reply_markup=b.as_markup(),
        parse_mode="HTML"
    )

    state_map = {
        "name":  PS.edit_name,
        "plans": PS.edit_plans,
        "stock": PS.edit_stock,
        "desc":  PS.edit_desc,
    }
    await state.set_state(state_map.get(field, PS.edit_name))
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("setcat_"), PS.edit_platform)
async def cb_edit_platform_pick(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return
    _, code, pid_s = cb.data.split("_")
    pid = int(pid_s)
    p = get_product(pid)
    update_product(pid, p[1], code, get_plans(p), p[6], p[7])
    await state.clear()
    try:
        await cb.message.delete()
    except Exception:
        pass
    await bot.send_message(
        cb.from_user.id,
        f"{e('check','✅')} Platform updated to: {code}",
        reply_markup=kb_after_field_edit(pid)
    )
    await safe_answer(cb)

@dp.message(PS.edit_name)
async def msg_edit_name(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    p = get_product(data['pid'])
    update_product(data['pid'], msg.text, p[2], get_plans(p), p[6], p[7])
    await state.clear()
    await msg.answer(f"{e('check','✅')} Name updated to: {html.escape(msg.text)}", reply_markup=kb_after_field_edit(data['pid']))

@dp.message(PS.edit_plans)
async def msg_edit_plans(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        plans = parse_plans_text(msg.text)
    except ValueError as err:
        await msg.answer(
            f'{e("cross","❌")} Could not read that: {html.escape(str(err))}\n'
            f'Use one plan per line, format "label - price". Try again:'
        )
        return
    data = await state.get_data()
    p = get_product(data['pid'])
    update_product(data['pid'], p[1], p[2], plans, p[6], p[7])
    await state.clear()
    plans_lines = "\n".join(f'   {label} — ₹{price:.0f}' for label, price in plans)
    await msg.answer(
        f"{e('check','✅')} Plans updated:\n{html.escape(plans_lines)}",
        reply_markup=kb_after_field_edit(data['pid'])
    )

@dp.message(PS.edit_stock)
async def msg_edit_stock(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        stock = int(msg.text)
        if stock not in [0, 1]:
            await msg.answer(f"{e('cross','❌')} Enter 0 or 1 only:")
            return
        data = await state.get_data()
        p = get_product(data['pid'])
        update_product(data['pid'], p[1], p[2], get_plans(p), stock, p[7])
        await state.clear()
        status = e('check','✅') if stock else e('cross','❌')
        await msg.answer(f"{e('check','✅')} Stock updated to: {status}", reply_markup=kb_after_field_edit(data['pid']))
    except ValueError:
        await msg.answer(f"{e('cross','❌')} Invalid number. Enter 0 or 1:")

@dp.message(PS.edit_desc)
async def msg_edit_desc(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    data = await state.get_data()
    p = get_product(data['pid'])
    desc = "" if msg.text.strip() == "-" else msg.text
    update_product(data['pid'], p[1], p[2], get_plans(p), p[6], desc)
    await state.clear()
    await msg.answer(f"{e('check','✅')} Description updated!", reply_markup=kb_after_field_edit(data['pid']))

# ── DELETE PRODUCT ─────────────────────────────────────────────────────────────

@dp.callback_query(F.data == "adm_product_delete")
async def cb_product_delete(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("trash","🗑️")} <b>Delete Product</b>\n\n{e("point","👇")} Select a product to delete:',
        reply_markup=kb_product_list("delete"),
        parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("prod_delete_"))
async def cb_confirm_delete(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    pid = int(cb.data.split("_")[2])
    p = get_product(pid)
    await state.update_data(delete_pid=pid)

    b = InlineKeyboardBuilder()
    b.row(
        InlineKeyboardButton(
            text='Yes, Delete',
            callback_data=f"del_confirm_{pid}",
            icon_custom_emoji_id=_E["check"],
            style="danger",
        ),
        InlineKeyboardButton(
            text='Cancel',
            callback_data="adm_products",
            icon_custom_emoji_id=_E["cross"],
            style="danger",
        ),
    )

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=f'{e("warning","⚠️")} <b>Confirm Delete</b>\n\n'
        f'Are you sure you want to delete:\n'
        f'{e("cart","📦")} <b>{p[1]}</b>\n'
        f'{e("text","📂")} Category: {p[2]}\n'
        f'{e("money","💰")} Prices: 1D:₹{float(p[3]):.0f} 7D:₹{float(p[4]):.0f} 31D:₹{float(p[5]):.0f}\n\n'
        f'{e("warning","⚠️")} This action <b>CANNOT</b> be undone!',
        reply_markup=b.as_markup(),
        parse_mode="HTML"
    )
    await safe_answer(cb)

@dp.callback_query(F.data.startswith("del_confirm_"))
async def cb_delete_product(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    pid = int(cb.data.split("_")[2])
    p = get_product(pid)
    delete_product(pid)
    await safe_answer(cb, f"{e('check','✅')} Deleted: {p[1]}", show_alert=True)

    try:
        await cb.message.delete()
    except Exception:
        pass

    await bot.send_message(
        chat_id=cb.from_user.id,
        text=txt_admin_home(),
        reply_markup=kb_admin(),
        parse_mode="HTML"
    )

@dp.callback_query(F.data == "adm_deps")
async def cb_adm_deps(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    deps = get_pending_deposits()
    if not deps:
        await safe_edit(cb.message, f'{e("cash","💳")} <b>No pending deposits.</b>', kb_back_admin())
        await safe_answer(cb)
        return

    text = f'{e("cash","💳")} <b>Pending Deposits</b>\n\n'
    for d in deps[:10]:
        uname = d[6] or d[7] or str(d[1])
        text += f'{e("idcard","#️⃣")}{d[0]} — {uname} — ₹{float(d[2]):.2f} — {d[5][:10] if d[5] else "N/A"}\n'
    await safe_edit(cb.message, text, kb_back_admin())
    await safe_answer(cb)

@dp.callback_query(F.data == "adm_broadcast")
async def cb_adm_broadcast(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    await safe_edit(
        cb.message,
        f'{e("forward","📢")} <b>Broadcast</b>\n\nSend message to ALL users.\n<i>/cancel to abort.</i>',
        kb_back_admin()
    )
    await state.set_state(AS.broadcast)
    await safe_answer(cb)

@dp.message(AS.broadcast)
async def msg_broadcast(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    if msg.text == "/cancel":
        await state.clear()
        await msg.answer(f'{e("cross","❌")} Cancelled.')
        return

    users  = get_all_users()
    sent   = failed = 0
    status = await msg.answer(f"{e('forward','📢')} Broadcasting to {len(users)} users…")

    for uid in users:
        try:
            await bot.send_message(uid, f'{e("forward","📢")} <b>Announcement</b>\n\n{msg.text}', parse_mode="HTML")
            sent += 1
            await asyncio.sleep(0.05)
        except Exception:
            failed += 1

    await state.clear()
    await status.edit_text(
        f'{e("check","✅")} <b>Broadcast Done</b>\n{e("point","📤")} Sent: {sent}\n{e("cross","❌")} Failed: {failed}\n{e("dev","👥")} Total: {len(users)}',
        parse_mode="HTML"
    )

@dp.callback_query(F.data == "adm_balance")
async def cb_adm_balance(cb: types.CallbackQuery, state: FSMContext):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    await safe_edit(
        cb.message,
        f'{e("money","💰")} <b>Adjust Balance</b>\n\n'
        f'{e("text","📝")} Format: <code>USER_ID AMOUNT</code>\n\n'
        f'{e("plus","➕")} Add ₹100: <code>123456 100</code>\n'
        f'{e("minus","➖")} Deduct ₹50: <code>123456 -50</code>',
        kb_back_admin()
    )
    await state.set_state(AS.balance_adjust)
    await safe_answer(cb)

@dp.message(AS.balance_adjust)
async def msg_balance_adjust(msg: types.Message, state: FSMContext):
    if msg.from_user.id != ADMIN_ID: return
    try:
        parts = msg.text.split()
        if len(parts) != 2:
            await msg.answer(f"{e('cross','❌')} Invalid format. Use: USER_ID AMOUNT")
            return

        uid = int(parts[0])
        amount = float(parts[1])

        update_balance(uid, amount)
        add_tx(uid, amount, "admin_adj", "Admin balance adjustment")
        await state.clear()

        await msg.answer(
            f'{e("check","✅")} Done!\n{e("dev","👤")} {uid}\n{e("money","💰")} {amount:+.2f}\n{e("coin","🪙")} New Balance: ₹{get_balance(uid):.2f}',
            reply_markup=kb_back_admin(), parse_mode="HTML"
        )

        try:
            await bot.send_message(
                uid,
                f'{e("money","💰")} <b>Balance Updated</b>\n\n{e("plus","➕")} Adjusted by {amount:+.2f}\n{e("coin","🪙")} New Balance: ₹{get_balance(uid):.2f}',
                parse_mode="HTML"
            )
        except Exception:
            pass
    except ValueError:
        await msg.answer(f"{e('cross','❌')} Invalid format. Use: USER_ID AMOUNT")

@dp.callback_query(F.data == "adm_users")
async def cb_adm_users(cb: types.CallbackQuery):
    if cb.from_user.id != ADMIN_ID:
        await safe_answer(cb, f'{e("cross","❌")} Unauthorized!', show_alert=True)
        return

    await safe_edit(cb.message, f'{e("dev","👥")} <b>Total Users:</b> {len(get_all_users())}', kb_back_admin())
    await safe_answer(cb)

# ========================================
# CATCH-ALL
# ========================================

@dp.message()
async def handle_unknown(_: types.Message): pass

# ========================================
# MAIN
# ========================================

async def main():
    init_db()
    logging.info("🤖 Bot starting…")
    info = await bot.get_me()
    logging.info(f"✅ Bot: @{info.username}")
    logging.info(f"👨‍💼 Admin ID: {ADMIN_ID}")
    logging.info("📡 Press Ctrl+C to stop")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("❌ Bot stopped.")