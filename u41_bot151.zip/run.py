"""
run.py — Master Service Runner for Tg store
Starts both the Web Admin Panel (FastAPI/Uvicorn) and the Telegram Bot concurrently with a single command!
Usage: python run.py
"""
import multiprocessing
import time
import sys

def run_panel():
    import uvicorn
    from account_panel import app
    print("🌐 Starting Admin Web Panel on port 8001...")
    uvicorn.run(app, host="0.0.0.0", port=8001, log_level="warning")

def run_bot():
    print("🤖 Starting Tg store Telegram Bot...")
    from bot import main
    main()

if __name__ == "__main__":
    p1 = multiprocessing.Process(target=run_panel)
    p2 = multiprocessing.Process(target=run_bot)

    p1.start()
    time.sleep(1)
    p2.start()

    try:
        p1.join()
        p2.join()
    except KeyboardInterrupt:
        print("\nStopping all services...")
        p1.terminate()
        p2.terminate()
        sys.exit(0)
